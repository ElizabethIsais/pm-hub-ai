/**
 * content.js — PM Hub AI Competency Content
 *
 * COMPETENCY_PACKAGES: single source of truth for all learning content.
 * Each package owns Learn + Practice + Interview content for one competency area.
 * CERT_QUESTIONS: unified exam pool (packageId on each for competency-aware results).
 *
 * Content reinforces the same skills from four perspectives:
 *   Learn → understand it · Practice → apply it · Interview → articulate it · Cert → validate it
 *
 * To add a new competency: add one entry to COMPETENCY_PACKAGES following the existing pattern.
 * No changes to module renderers needed.
 */

const COMPETENCY_PACKAGES = [

  // ══════════════════════════════════════════════════════════════════════════
  // PACKAGE 1 — Project Fundamentals
  // Competencies: Decision Making · Scope Management · Product Thinking
  // ══════════════════════════════════════════════════════════════════════════
  {
    id: 'PKG-FUNDAMENTALS',
    name: 'Project Fundamentals',
    icon: '🏗️',
    level: 'Beginner',
    description: 'Build the foundation every PM career depends on.',
    competencies: { 'Decision Making': 10, 'Scope Management': 10, 'Product Thinking': 8 },

    learn: {
      id: 'T1',
      title: 'Project Fundamentals',
      icon: '🏗️',
      description: 'Build the foundation every PM career depends on.',
      level: 'Beginner',
      experiences: [

        // ── T1-01: What Is a Project? ───────────────────────────────────────
        {
          id: 'T1-01',
          title: 'What Is a Project?',
          objective: 'Distinguish projects from ongoing IT operations.',
          duration: '7 min',
          status: 'available',
          competencies: { 'Decision Making': 8, 'Product Thinking': 5 },
          phases: [
            {
              type: 'classify',
              label: 'Challenge',
              title: 'Project or IT Operation?',
              instruction: 'Trust your instincts. Each scenario is something a Technical PM might encounter. Is it a project or an ongoing operation?',
              mentorIntro: 'Start with the challenge. You\'ll learn more from making decisions under uncertainty than from reading theory first.',
              categories: [
                { id: 'project',   label: 'Project',   icon: '🚀' },
                { id: 'operation', label: 'Operation', icon: '⚙️' }
              ],
              items: [
                { text: 'Migrating a company\'s on-premise data center to AWS, with a planned cutover by end of Q2', correct: 'project', feedbackCorrect: 'Correct. There\'s a clear goal (migrate to AWS), a deadline (end of Q2), and a unique outcome. Once the cutover is done, this work ends.', feedbackWrong: 'Look at the deadline — "end of Q2." Once the migration is complete, this work ends. Temporary + unique goal = project.' },
                { text: 'Monitoring production system uptime and responding to incidents as they occur, every day', correct: 'operation', feedbackCorrect: 'Right. Incident response and uptime monitoring run indefinitely — no defined end date and no unique deliverable. This is IT operations.', feedbackWrong: 'Ask yourself: when does this end? It doesn\'t. No defined end, repetitive process = operation.' },
                { text: 'Building and launching a new mobile banking app for retail customers, targeting a September release', correct: 'project', feedbackCorrect: 'Exactly. A unique product, a defined goal (September release), and a clear end state. Once it ships, the project closes.', feedbackWrong: 'Consider the September release date. Once the app launches, the development project ends. Building it the first time is a project.' },
                { text: 'Deploying security patches to all company servers every Tuesday during the scheduled maintenance window', correct: 'operation', feedbackCorrect: 'Correct. Patch Tuesday runs every week, indefinitely, following the same process. Repetitive, ongoing, no end date — classic IT operations.', feedbackWrong: 'Every Tuesday, indefinitely. This process repeats on a fixed schedule with no planned end — that\'s an operation.' },
                { text: 'Implementing Salesforce CRM across a 400-person sales organization, replacing spreadsheet-based tracking', correct: 'project', feedbackCorrect: 'Right. A CRM implementation has a defined scope, a go-live date, and a unique outcome. Once users are live and trained, the project closes.', feedbackWrong: 'A CRM implementation has a defined end: the go-live date. After that, Salesforce becomes part of daily operations.' },
                { text: 'Processing and provisioning new user access requests submitted through the IT helpdesk ticketing system', correct: 'operation', feedbackCorrect: 'Correct. User provisioning is a recurring operational process — employees join, change roles, and leave continuously. No end date = operation.', feedbackWrong: 'New employees will always need accounts. This process runs indefinitely following a standard workflow. No defined end = operation.' }
              ]
            },
            {
              type: 'reading',
              label: 'Concepts',
              title: 'What Is a Project?',
              mentorIntro: 'You\'ve already seen the patterns in real IT scenarios. Now here\'s the theory behind them.',
              sections: [
                { heading: 'The Definition', body: 'A project is a <em>temporary</em> endeavor undertaken to create a <em>unique</em> product, service, or result. Those two words carry all the weight. Temporary means there is a defined beginning and a defined end. Unique means the result is different from anything before it, even if similar work has been done.<br><br>For a Technical PM, this plays out constantly: building a new CI/CD pipeline is a project. Running that pipeline every day afterward is an operation.' },
                { heading: 'Three Defining Characteristics', body: '<strong>Temporary</strong> — There is a start date and an end date. A cloud migration ends when the cutover is complete.<br><br><strong>Unique</strong> — Even if your team has built APIs before, <em>this</em> API, for <em>this</em> system, at <em>this</em> time, is new.<br><br><strong>Progressive</strong> — Requirements evolve as the team learns. In a legacy modernization, scope is refined sprint by sprint.' },
                { heading: 'Projects vs. IT Operations', body: 'IT operations are the ongoing activities that keep systems running: monitoring infrastructure, deploying patches, managing user accounts, responding to incidents. They continue indefinitely.<br><br>Projects exist to <em>change or create something</em>. Once a project delivers its outcome, that outcome often becomes part of operations. Implementing a data platform is a project. Querying that platform daily is an operation.' }
              ]
            },
            {
              type: 'quiz',
              label: 'Quiz',
              title: 'Quick Check',
              mentorIntro: 'Three questions. These are distinctions a Technical PM needs to make quickly and confidently.',
              questions: [
                { question: 'An engineering team is redesigning and relaunching the company\'s developer portal, with a target launch in Q4. How should a TPM classify this?', options: [ { text: 'An operation — the portal already exists', correct: false, feedback: 'A full redesign and relaunch has a defined goal, a deadline, and produces something distinct from what exists today. That makes it a project.' }, { text: 'A project — temporary, unique, defined end date', correct: true, feedback: 'Correct. A full redesign with a Q4 launch is temporary, unique, and has a clear end state. After launch, maintenance is a separate operation.' }, { text: 'Depends on whether the team uses Agile or Waterfall', correct: false, feedback: 'Delivery methodology doesn\'t determine whether something is a project. The distinguishing factor is whether the work is temporary and unique.' }, { text: 'A program, because it involves multiple workstreams', correct: false, feedback: 'Having multiple workstreams doesn\'t create a program. A single initiative with multiple tracks is still one project.' } ] },
                { question: 'Which of the following is NOT one of the three defining characteristics of a project?', options: [ { text: 'Temporary — has a defined start and end', correct: false, feedback: 'Temporary is one of the three core characteristics. Every project has a beginning and an end.' }, { text: 'Unique — produces a distinct deliverable', correct: false, feedback: 'Uniqueness is one of the three. Each project produces a distinct result even when similar work has been done before.' }, { text: 'Repetitive — follows the same process every time', correct: true, feedback: 'Repetitive processes describe operations, not projects. Running the same deployment script every Tuesday is operational.' }, { text: 'Progressive — understanding evolves over time', correct: false, feedback: 'Progressive elaboration is the third characteristic. In most IT projects, requirements sharpen sprint by sprint.' } ] },
                { question: 'A DevOps team runs a fully automated CI/CD pipeline that deploys code every time a developer merges to main — with no planned end date. What type of activity is this?', options: [ { text: 'A project, because each deployment produces a new software version', correct: false, feedback: 'Each deployment is the same automated process repeating. Building the pipeline was a project. Running it is an operation.' }, { text: 'An ongoing operation', correct: true, feedback: 'Correct. The pipeline runs indefinitely, following the same workflow. No defined end date, same process every time — DevOps operations.' }, { text: 'A project, because it requires ongoing engineering effort', correct: false, feedback: 'Maintenance effort doesn\'t make something a project. Operations require continuous effort too.' }, { text: 'A program, because it covers build, test, and deploy phases', correct: false, feedback: 'Having multiple phases doesn\'t create a program. An automated pipeline is a repeating operational process.' } ] }
              ]
            },
            {
              type: 'keyTakeaway',
              label: 'Takeaway',
              text: 'If it has a start date, an end date, and a unique goal — it\'s a project. Everything else is keeping the systems running.',
              mentorNote: 'You\'ll use this distinction every day as a Technical PM. Scope conversations, budget requests, team assignments — they all start with this question.',
              xp: 25
            }
          ]
        },

        // ── T1-02: The Project Lifecycle ────────────────────────────────────
        {
          id: 'T1-02',
          title: 'The Project Lifecycle',
          objective: 'Navigate the five phases of any IT project with confidence.',
          duration: '8 min',
          status: 'available',
          competencies: { 'Scope Management': 10, 'Decision Making': 6, 'Product Thinking': 7 },
          phases: [
            {
              type: 'classify',
              label: 'Challenge',
              title: 'Which Lifecycle Phase?',
              instruction: 'Each activity is something a TPM would do on a real IT project. Which lifecycle phase does it belong to?',
              mentorIntro: 'Before reading the theory, test your instincts. Think about where each activity sits in the life of a project.',
              categories: [
                { id: 'initiating',  label: 'Initiating',   icon: '🌱' },
                { id: 'executing',   label: 'Executing',    icon: '⚙️' },
                { id: 'closing',     label: 'Closing',      icon: '✅' }
              ],
              items: [
                { text: 'Meeting with the executive sponsor to define project goals, success criteria, and initial budget', correct: 'initiating', feedbackCorrect: 'Correct. Aligning with sponsors on goals and budget happens during Initiation — before any planning or delivery work begins.', feedbackWrong: 'Aligning on goals and budget with sponsors happens at the very start of a project, in the Initiation phase. No code, no planning yet — just alignment.' },
                { text: 'Deploying the authentication service to the staging environment and running integration tests', correct: 'executing', feedbackCorrect: 'Right. Actual delivery — deploying code, running tests — happens in the Execution phase. The team is building and validating.', feedbackWrong: 'Deploying and testing is the heart of Execution. The team is building and validating the actual deliverable here.' },
                { text: 'Obtaining formal sign-off from the client on the completed CRM integration', correct: 'closing', feedbackCorrect: 'Correct. Formal client acceptance is a Closing activity. Once stakeholders sign off, the project formally ends.', feedbackWrong: 'Getting formal sign-off from the client marks the end of the project. That\'s Closing — the work is done, and delivery is accepted.' },
                { text: 'Identifying key stakeholders for the cloud migration and documenting their communication needs', correct: 'initiating', feedbackCorrect: 'Right. Stakeholder identification happens during Initiation, before the project plan is built. You need to know your stakeholders to plan effectively.', feedbackWrong: 'Knowing who your stakeholders are — and what they need — is foundational. This happens during Initiation, before planning begins.' },
                { text: 'Reviewing sprint velocity weekly and updating the release forecast based on team output', correct: 'executing', feedbackCorrect: 'Correct. Tracking velocity and updating forecasts is an Execution activity — specifically the Monitoring & Controlling aspect that runs throughout delivery.', feedbackWrong: 'Tracking team output and adjusting forecasts happens during Execution, as the team delivers sprint by sprint.' },
                { text: 'Conducting a lessons-learned retrospective and archiving all project documentation', correct: 'closing', feedbackCorrect: 'Exactly. Lessons learned and archiving happen during Closing — the final step in every well-run project.', feedbackWrong: 'Retrospectives and documentation archiving mark the end of a project. This is Closing — the phase where the team reflects and wraps up formally.' }
              ]
            },
            {
              type: 'reading',
              label: 'Concepts',
              title: 'The Project Lifecycle',
              mentorIntro: 'You\'ve already placed real activities into lifecycle phases. Now here\'s how each phase connects to the next.',
              sections: [
                { heading: 'Five Phases, One Journey', body: 'Every project — whether it\'s a mobile app launch, a cloud migration, or an ERP implementation — passes through the same five phases: <strong>Initiating, Planning, Executing, Monitoring & Controlling, and Closing</strong>.<br><br>These phases aren\'t just theoretical boxes. They define what decisions are available to a PM, what documents get produced, and where the most risk lives. Skipping or rushing a phase almost always creates a crisis in a later one.' },
                { heading: 'Initiating & Planning', body: '<strong>Initiating</strong> is where a project is formally authorized. The TPM works with sponsors to define goals, identify stakeholders, estimate high-level scope, and produce the project charter. Nothing gets built here — but every decision made here shapes everything that follows.<br><br><strong>Planning</strong> is where the delivery approach is designed. The TPM defines the WBS, creates the schedule, assigns owners, plans risk responses, and establishes communication channels. For Agile teams, this includes building the initial backlog and setting sprint cadences. Good planning doesn\'t eliminate change — it makes change manageable.' },
                { heading: 'Executing & Monitoring', body: '<strong>Executing</strong> is where the team builds. Engineers write code, QA runs tests, infrastructure is provisioned, and integrations are configured. The TPM\'s job during execution is to remove blockers, protect scope, and keep stakeholders informed.<br><br><strong>Monitoring & Controlling</strong> runs parallel to execution — tracking velocity, reviewing risk, managing changes through a formal change control process, and forecasting the remaining work. A good TPM monitors continuously, not just at the end of sprints.' },
                { heading: 'Closing', body: '<strong>Closing</strong> is the most skipped phase in IT projects — and the most important one to do properly.<br><br>Closing includes: obtaining formal stakeholder acceptance, transitioning deliverables to the operations team, documenting lessons learned, releasing team members, and archiving project records. A project that doesn\'t formally close leaves ambiguity about what was delivered, who owns what, and what the team learned. For Technical PMs, a clean close is a professional signature.' }
              ]
            },
            {
              type: 'quiz',
              label: 'Quiz',
              title: 'Lifecycle Check',
              mentorIntro: 'Three questions about where decisions get made in the project lifecycle.',
              questions: [
                { question: 'A TPM is evaluating a project proposal to determine whether it aligns with company strategy and whether to invest. Which lifecycle phase is this?', options: [ { text: 'Planning', correct: false, feedback: 'Planning happens after a project is approved. During Initiating, the project is being evaluated — not yet planned.' }, { text: 'Initiating', correct: true, feedback: 'Correct. Evaluating feasibility, aligning with strategy, and deciding whether to proceed all happen during Initiation — before a single plan is created.' }, { text: 'Executing', correct: false, feedback: 'Executing is where the team builds the deliverable. The project has already been approved and planned before execution begins.' }, { text: 'Closing', correct: false, feedback: 'Closing wraps up a completed project. At this point the project hasn\'t even been approved yet.' } ] },
                { question: 'The development team is resolving defects flagged in the latest test cycle while the TPM updates the risk register. Which phase best describes this?', options: [ { text: 'Planning', correct: false, feedback: 'Planning produces the project plan before delivery begins. Resolving defects and tracking risk happens during delivery.' }, { text: 'Initiating', correct: false, feedback: 'Initiation is before planning and delivery. Defect resolution requires that code has already been built and tested.' }, { text: 'Executing with Monitoring & Controlling', correct: true, feedback: 'Correct. Fixing defects is Executing. Updating the risk register is Monitoring & Controlling. These two phases run in parallel throughout delivery.' }, { text: 'Closing', correct: false, feedback: 'Closing happens after delivery is complete and accepted. Defect resolution means the team is still delivering.' } ] },
                { question: 'The cloud migration is complete. The TPM is conducting a post-implementation review, writing lessons learned, and releasing the team. Which phase is this?', options: [ { text: 'Executing', correct: false, feedback: 'Execution is where the migration was performed. After the work is done and accepted, the project moves to Closing.' }, { text: 'Monitoring & Controlling', correct: false, feedback: 'M&C tracks in-flight delivery. When the migration is complete, monitoring gives way to formal close-out activities.' }, { text: 'Planning', correct: false, feedback: 'Planning happens at the beginning of the project, long before delivery and certainly before lessons learned.' }, { text: 'Closing', correct: true, feedback: 'Correct. Post-implementation review, lessons learned, and releasing the team are all Closing activities. A project that doesn\'t formally close is a project that isn\'t really finished.' } ] }
              ]
            },
            {
              type: 'keyTakeaway',
              label: 'Takeaway',
              text: 'Every project phase has a purpose. Rushing Initiation creates scope confusion. Skipping Closure leaves the team with no lessons and the business with no formal handoff.',
              mentorNote: 'The best TPMs treat every phase seriously — especially the ones stakeholders want to skip. Initiation and Closure are where professional PMs earn their reputation.',
              xp: 30
            }
          ]
        },

        // ── T1-03: The Triple Constraint ────────────────────────────────────
        {
          id: 'T1-03',
          title: 'The Triple Constraint',
          objective: 'Make scope, time, and cost trade-offs with confidence.',
          duration: '8 min',
          status: 'available',
          competencies: { 'Scope Management': 12, 'Negotiation': 8, 'Decision Making': 7 },
          phases: [
            {
              type: 'classify',
              label: 'Challenge',
              title: 'Which Constraint Is Impacted?',
              instruction: 'A change has just arrived on your IT project. Which constraint does it primarily impact — Scope, Time, or Cost?',
              mentorIntro: 'Change requests arrive every week on a real IT project. The faster you can identify which constraint is threatened, the faster you can have the right conversation.',
              categories: [
                { id: 'scope', label: 'Scope',  icon: '📋' },
                { id: 'time',  label: 'Time',   icon: '🕐' },
                { id: 'cost',  label: 'Cost',   icon: '💰' }
              ],
              items: [
                { text: 'The client requests adding a real-time analytics dashboard to the platform — no budget or timeline adjustment is offered', correct: 'scope', feedbackCorrect: 'Correct. Adding a new feature expands scope. Without adjusting time or cost, something has to give — usually quality.', feedbackWrong: 'Adding a new feature to the deliverable is a scope change. The client is asking you to deliver more than originally agreed.' },
                { text: 'A critical vendor delays API documentation delivery by three weeks, blocking your integration team', correct: 'time', feedbackCorrect: 'Right. An external dependency blocking your team directly threatens the schedule — a time constraint impact.', feedbackWrong: 'A vendor delay blocks your team\'s progress. That\'s a schedule threat — the Time constraint is at risk.' },
                { text: 'Cloud infrastructure costs exceed projections because data transfer volumes are 40% higher than estimated', correct: 'cost', feedbackCorrect: 'Correct. Higher-than-expected infrastructure costs are a Cost constraint issue. The budget needs revision.', feedbackWrong: 'Infrastructure overspend hits the budget, not the schedule or scope. That\'s the Cost constraint.' },
                { text: 'The product owner adds two new user stories to the sprint, claiming they are "small" and "critical for launch"', correct: 'scope', feedbackCorrect: 'Right. Adding work items mid-sprint is scope creep — even small stories expand what the team has committed to delivering.', feedbackWrong: 'Adding new work, even "small" items, expands scope. Scope creep doesn\'t need to be large to be a problem.' },
                { text: 'A critical bug discovered in production testing requires an emergency sprint before go-live, pushing the release by two weeks', correct: 'time', feedbackCorrect: 'Correct. An unplanned sprint that delays the release date is a Time constraint impact — the schedule is directly affected.', feedbackWrong: 'An emergency sprint that delays the go-live date is a schedule impact. Time is the constraint under pressure here.' },
                { text: 'Implementing a GDPR compliance requirement requires hiring a specialized security consultant not in the original plan', correct: 'cost', feedbackCorrect: 'Right. Unplanned contractor spend directly impacts the Cost constraint. The budget needs to absorb an unexpected resource.', feedbackWrong: 'An unplanned contractor is an unplanned expense. That\'s a Cost constraint impact — the budget grows.' }
              ]
            },
            {
              type: 'reading',
              label: 'Concepts',
              title: 'The Triple Constraint',
              mentorIntro: 'You\'ve been making trade-off decisions. Here\'s the framework that explains why those decisions are inevitable.',
              sections: [
                { heading: 'Scope, Time, and Cost', body: 'The Triple Constraint is one of the most important frameworks in project management — and the most misunderstood.<br><br>Every project is bounded by three constraints: <strong>Scope</strong> (what is being built), <strong>Time</strong> (by when), and <strong>Cost</strong> (with what budget). These three are interconnected: change one, and at least one other must change too — or quality suffers.<br><br>A Technical PM\'s core skill is making these trade-offs explicit before stakeholders make decisions invisibly.' },
                { heading: 'The Iron Triangle in IT Projects', body: 'In practice, the Triple Constraint shows up in every sprint review and every change request:<br><br>• "Can we add the reporting module?" → Scope change → needs time or cost adjustment<br>• "Can we still hit the March deadline?" → Time change → needs scope reduction or more resources (cost)<br>• "The budget was cut by 20%" → Cost change → needs scope reduction or timeline extension<br><br>The danger isn\'t the change itself — it\'s when stakeholders ask for scope changes without acknowledging the corresponding impact on time or cost. A TPM\'s job is to surface that trade-off immediately.' },
                { heading: 'Quality: The Hidden Fourth Variable', body: 'Some frameworks add <strong>Quality</strong> as a fourth constraint — or place it at the center of the triangle. When time, cost, and scope are all fixed, quality is what gets sacrificed.<br><br>This is the "fast, good, cheap — pick two" principle: you can deliver quickly and cheaply, but not at full quality. You can deliver quality and speed, but it costs more. You can deliver quality cheaply, but it takes longer.<br><br>Understanding this framework transforms change request conversations. Instead of arguing about whether to accept a change, a TPM asks: "Given this change, which of our constraints do we adjust — and who makes that call?"' }
              ]
            },
            {
              type: 'quiz',
              label: 'Quiz',
              title: 'Constraint Trade-offs',
              mentorIntro: 'Three scenarios where you\'ll need to apply the Triple Constraint framework.',
              questions: [
                { question: 'Your project is on schedule and on budget when the client requests a new reporting module. This change directly impacts which constraint first?', options: [ { text: 'Time — it will delay the project', correct: false, feedback: 'Scope is impacted first. Whether time is also affected depends on whether the team has capacity to absorb the new work.' }, { text: 'Scope — more deliverables than originally agreed', correct: true, feedback: 'Correct. Adding a new module expands scope. Time and cost may also be affected, but scope is the primary constraint hit.' }, { text: 'Cost — it will require more resources', correct: false, feedback: 'Cost may be affected, but scope is the primary constraint. The deliverable is changing — that\'s scope first.' }, { text: 'Quality — the team will rush the existing work', correct: false, feedback: 'Quality may suffer if scope is added without adjustment — but the primary constraint impact is scope expansion.' } ] },
                { question: 'If a team adds scope to a project without adjusting time or cost, what is the most predictable outcome?', options: [ { text: 'The project succeeds because the team will adapt', correct: false, feedback: 'Teams rarely absorb scope additions without consequence. Added work with the same time and budget typically means quality drops or something else gets cut.' }, { text: 'Quality and deliverables will suffer', correct: true, feedback: 'Correct. The Iron Triangle is iron for a reason. More scope with the same time and money means something has to give — usually quality, testing, or documentation.' }, { text: 'The timeline automatically extends', correct: false, feedback: 'Timelines don\'t automatically extend — they have to be formally renegotiated. Without adjustment, the team delivers less or delivers poorly.' }, { text: 'The budget automatically increases', correct: false, feedback: 'Budgets are fixed unless formally changed. Adding scope without budget adjustment means the team works with the same resources to do more.' } ] },
                { question: 'A key engineer resigns mid-project and the replacement won\'t start for three weeks. As the TPM, which constraint should you immediately assess?', options: [ { text: 'Cost only — you\'ll need to pay the new hire', correct: false, feedback: 'Replacement cost may be relevant, but the immediate risk is to the schedule — work that was planned for the next three weeks will be delayed.' }, { text: 'Scope only — reduce the backlog', correct: false, feedback: 'Scope adjustment may be one option, but the first step is assessing which constraint is most threatened — and that\'s Time given the three-week gap.' }, { text: 'Time — assess which tasks are blocked and how the schedule is affected', correct: true, feedback: 'Correct. A three-week resource gap directly threatens the schedule. Assess the impact on the critical path first, then discuss scope and cost options with stakeholders.' }, { text: 'Quality — the remaining team will be overloaded', correct: false, feedback: 'Quality risk is real but secondary. The first step is assessing the schedule impact of losing a key resource — then you can make informed trade-off decisions.' } ] }
              ]
            },
            {
              type: 'keyTakeaway',
              label: 'Takeaway',
              text: 'Change one constraint and at least one other must move — or quality pays the price. A Technical PM\'s job is to make that trade-off explicit before the decision is made.',
              mentorNote: 'Never let a stakeholder add scope without acknowledging the consequence. "Yes, and here\'s what adjusts" is one of the most valuable sentences a TPM can say.',
              xp: 30
            }
          ]
        },

        { id: 'T1-04', title: 'The Project Charter',     objective: 'Build and explain a project charter from scratch.',      duration: '7 min',  status: 'coming-soon' },
        { id: 'T1-05', title: 'The PM Role in Practice', objective: 'Describe what Technical PMs actually do, day by day.',   duration: '9 min',  status: 'coming-soon' }
      ]
    },

    practice: [
      {
    id: 'ch-03',
    title: 'Late Scope Expansion Request',
    difficulty: 'Intermediate',
    tags: ['Scope', 'Stakeholders', 'Communication'],
    projectContext: {
      project: 'AWS Cloud Migration',
      status: '60% Complete · Testing Phase',
      priority: 'High',
      team: 'CTO, Tech Lead, 3 Engineers, QA'
    },
    context: 'Your cloud migration project is 60% complete and on schedule. The CTO requests adding a real-time cost monitoring dashboard to the scope. The go-live date is fixed due to a contract with a new enterprise client.',
    question: 'How do you respond?',
    skills: ['Scope Management', 'Stakeholder Communication', 'Trade-off Analysis'],
    competencies: { 'Scope Management': 10, 'Stakeholder Communication': 8, 'Negotiation': 6 },
    options: [
      {
        text: 'Accept the request — the CTO is the executive sponsor and their decisions are final.',
        correct: false,
        feedback: 'Accepting scope additions without impact analysis sets the project up for failure. Even the sponsor needs to understand trade-offs before making an informed decision.',
        mentorComment: 'Saying yes without analysis isn\'t deference — it\'s abdication. Your value as a TPM is surfacing the real cost of decisions before they\'re made.'
      },
      {
        text: 'Decline — the scope is locked and changes aren\'t possible at this stage.',
        correct: false,
        feedback: 'Refusing without analysis is inflexible and misses a legitimate business need. The PM\'s job is to assess options and present trade-offs, not simply say no.',
        mentorComment: 'Scope control doesn\'t mean scope rigidity. It means making change decisions deliberately and with full information.'
      },
      {
        text: 'Assess the impact on timeline and resources, present trade-offs, and let the CTO decide with full information.',
        correct: true,
        feedback: 'This gives the CTO what they need to make an informed decision while protecting the fixed go-live constraint. You remain responsive to leadership without absorbing hidden risk.',
        mentorComment: 'Excellent. This is exactly the TPM role: translate a business request into a clear set of options with costs attached, then give the decision to the right person.'
      },
      {
        text: 'Add it to a future backlog without telling the CTO it won\'t make this release.',
        correct: false,
        feedback: 'Silent deferral is a transparency failure. The CTO will find out at go-live — damaging trust far more than an honest conversation would have.',
        mentorComment: 'Transparency is non-negotiable. The short-term discomfort of a difficult conversation is always better than the long-term damage of a surprise.'
      }
    ]
  },
    {
    id: 'ch-04',
    title: 'Stakeholder Prioritization Conflict',
    difficulty: 'Intermediate',
    tags: ['Stakeholders', 'Facilitation', 'Prioritization'],
    projectContext: {
      project: 'Internal Developer Platform',
      status: 'Q3 Planning',
      priority: 'Medium',
      team: 'Portal PO, Admin PO, Backend Lead, 4 Engineers'
    },
    context: 'Two product owners both claim their API integration is the highest priority for your backend team. The engineering lead says they are technically equivalent in complexity. The team is blocked waiting for a decision.',
    question: 'What is the most effective approach?',
    skills: ['Facilitation', 'Prioritization Frameworks', 'Stakeholder Management'],
    competencies: { 'Stakeholder Communication': 10, 'Decision Making': 6, 'Leadership': 7 },
    options: [
      {
        text: 'Let the two product owners work it out between themselves.',
        correct: false,
        feedback: 'Leaving competing stakeholders without structure rarely leads to resolution. As the TPM, you are responsible for driving alignment, not stepping back from it.',
        mentorComment: 'Avoiding conflict isn\'t neutrality — it\'s negligence. Your job is to create the conditions for a good decision, not to wait for one to happen.'
      },
      {
        text: 'Pick the integration that serves more users and announce your decision.',
        correct: false,
        feedback: 'Unilateral PM decisions on business priority skip the business context you may not fully have and erode stakeholder trust in the process.',
        mentorComment: 'You can have a point of view, but business prioritization decisions belong with the people who own the business outcomes. Facilitate, don\'t decide.'
      },
      {
        text: 'Escalate immediately to the VP Engineering to make the call.',
        correct: false,
        feedback: 'Escalation before facilitation wastes leadership time and signals the TPM cannot resolve normal alignment challenges independently.',
        mentorComment: 'Escalation is a last resort, not a first move. Strong TPMs solve alignment problems at the lowest possible level. Try structured facilitation first.'
      },
      {
        text: 'Facilitate a structured session using business impact and effort criteria, document the agreed priority, and get sign-off from both owners.',
        correct: true,
        feedback: 'A facilitated session with clear criteria depersonalizes the decision and creates shared ownership of the outcome. Documenting the agreement prevents future re-litigation.',
        mentorComment: 'Perfect approach. Frameworks turn subjective arguments into objective discussions. The documentation is equally important — it\'s your protection against revisionism later.'
      }
    ]
  }
    ],

    interview: [
          {
      id: 'int-tpm-01',
      packageId: 'PKG-FUNDAMENTALS',
      question: 'How do you manage technical dependencies in a large-scale software project?',
      difficulty: 'Intermediate',
      context: 'The interviewer wants to see a systematic process — not just awareness that dependencies exist. They will probe whether you have used real tools and run real coordination cadences.',
      evaluatorFocus: 'Systematic cross-team thinking, proactive communication, and evidence of real tools and processes over theoretical awareness.',
      star: {
        situation: 'We were kicking off a 6-month enterprise SaaS platform build with 3 Scrum teams. In the first planning session, each team had their own dependency list but there was no shared view of cross-team dependencies.',
        task: 'I needed to create a dependency management process that would scale across teams and surface risks before they reached the critical path.',
        action: 'I ran a two-hour dependency mapping session with all three team leads. We built a shared Jira board with a dedicated dependency type, assigned an owner to every cross-team dependency, and instituted a weekly Scrum of Scrums to surface blockers and track resolution. I also added a dependency health metric to the program dashboard: green (on track), yellow (at risk), red (blocked).',
        result: 'Three weeks in, we caught a circular dependency between the Auth and Data teams that would have caused a 3-week delay. Because the process was already running, we resolved it in one cross-team session. The project delivered on schedule with zero unresolved dependencies at release.',
        keyMessage: 'Cross-team dependencies don\'t manage themselves. Systematic mapping plus structured communication cadences is what keeps them from becoming critical-path crises at the worst moment.'
      }
    },
    {
      id: 'int-tpm-02',
      packageId: 'PKG-FUNDAMENTALS',
      question: 'How do you approach a build vs. buy decision for a technical component?',
      difficulty: 'Intermediate',
      context: 'The interviewer expects a structured decision framework — not a gut preference. They want to see cross-functional stakeholder involvement and awareness of long-term consequences.',
      evaluatorFocus: 'Structured thinking, multi-criteria evaluation, cross-functional collaboration, and long-term cost awareness beyond initial price comparison.',
      star: {
        situation: 'We were architecting an Identity and Access Management system for a new enterprise product. Engineering advocated for a custom build. Our product deadline was 4 months away.',
        task: 'I needed to drive a structured build vs. buy decision that included the right stakeholders and produced a defensible, documented recommendation.',
        action: 'I created a decision framework with five criteria: total cost of ownership over 3 years, time-to-market impact, integration complexity, alignment with our core differentiators, and vendor lock-in risk. I ran structured sessions with Security, Engineering, and Finance — each scoring independently. The result overwhelmingly favored a vendor solution on cost and time-to-market. I documented the decision matrix, the rationale, and the top three risks of the vendor path with mitigations.',
        result: 'We delivered the IAM system in 3.5 months using the vendor solution — nearly 3 times faster than the custom build estimate. When the CTO revisited the decision a year later, the documentation made the reasoning transparent. The decision stood.',
        keyMessage: 'Build vs. buy is a strategic decision, not a technical preference. A structured framework that includes cost, time, risk, and core competency gives you a defensible answer — not just an opinion.'
      }
    },
    {
      id: 'int-tpm-03',
      packageId: 'PKG-FUNDAMENTALS',
      question: 'How do you communicate technical risk to non-technical stakeholders?',
      difficulty: 'Advanced',
      context: 'The interviewer is evaluating whether you can bridge the technical-business divide — making complex risk legible without dumbing it down or creating unnecessary alarm.',
      evaluatorFocus: 'Business-impact framing, audience calibration, presenting options rather than just problems, and avoiding technical jargon.',
      star: {
        situation: 'During a real-time data pipeline build, our engineering lead identified a data consistency issue in sprint 7 that posed a significant risk to the Q3 board reporting outputs — a critical deliverable for the VP of Operations and Finance Director, neither of whom had a technical background.',
        task: 'I needed to communicate this risk clearly and quickly, without causing panic, and with a concrete recommendation they could act on.',
        action: 'I prepared a two-paragraph brief before the call. First sentence stated the business impact: Our Q3 board report may contain inconsistent data if we don\'t address this by next sprint. Second: Fixing it now costs one sprint; deferring it risks a report that needs to be retracted. I presented two options, my recommendation, and the team\'s confidence level. I deliberately avoided terms like race condition or eventual consistency.',
        result: 'The VP of Operations aligned with the recommendation immediately. Remediation took exactly one sprint, and the Q3 report was delivered clean. The Finance Director told me afterward it was the clearest risk communication she had received on any technical project.',
        keyMessage: 'Non-technical stakeholders don\'t need to understand the mechanism of a risk — they need to understand the business consequence and the cost of acting vs. not acting. Lead with that every time.'
      }
    },
    {
      id: 'int-tpm-04',
      packageId: 'PKG-FUNDAMENTALS',
      question: 'How do you handle technical debt in a project that is already behind schedule?',
      difficulty: 'Advanced',
      context: 'The interviewer wants to see that you treat technical debt as a real project risk — not a developer complaint to dismiss or a business pressure to ignore.',
      evaluatorFocus: 'Honest trade-off analysis, formal debt documentation, stakeholder alignment, and a concrete remediation commitment — not vague promises to fix it later.',
      star: {
        situation: 'On a mobile banking app v3, we were 3 weeks behind schedule but feature-complete. The engineering team had flagged significant debt accumulated during the sprint crunch — primarily in the authentication layer and API error handling.',
        task: 'I needed to make a transparent recommendation to the CTO and Product Owner about how to handle the debt, with the release window approaching and pressure to ship.',
        action: 'I inventoried the debt with the engineering lead: type (security-adjacent vs. code quality), risk profile if we shipped with it, and estimated remediation cost post-launch. I presented the CTO with three options: ship and formally accept the debt with a remediation plan in the next quarter; delay 2 weeks to address the highest-risk items; or ship with a feature flag disabling the riskiest code path. We documented the debt items in a dedicated Jira epic with owners and a committed remediation date.',
        result: 'The CTO chose the feature flag option. The release shipped on the compressed timeline. Six months later, the debt was resolved on schedule because it was tracked and owned — not swept under a rug.',
        keyMessage: 'Technical debt you don\'t document doesn\'t disappear — it compounds. The job isn\'t to pretend debt doesn\'t exist. It\'s to make it visible, assign an owner, and get a commitment. Invisible debt is the dangerous kind.'
      }
    },
    {
      id: 'int-beh-01',
      packageId: 'PKG-FUNDAMENTALS',
      question: 'Tell me about a time you had to push back on a feature request from senior leadership.',
      difficulty: 'Advanced',
      context: 'The interviewer is assessing courage, communication skills, and whether you can influence upward without being confrontational or simply compliant. They want a real story.',
      evaluatorFocus: 'Ability to hold a position respectfully under pressure, backed by data and trade-off analysis, with a solution rather than just a refusal.',
      star: {
        situation: 'We were 4 weeks into a sprint when the CHRO requested a new analytics feature for the HR platform — needed for a board presentation in 3 weeks. Adding it would require displacing 2 committed sprint deliverables that 2 other teams were waiting on.',
        task: 'I needed to push back in a way that addressed the genuine urgency while being transparent about the consequences — without simply saying yes to avoid conflict.',
        action: 'I requested 30 minutes with the CHRO and VP Product before any commitment was made. I came prepared: exactly which 2 deliverables would be displaced, what downstream effects that would cause for the waiting teams, and the cost of displacement in timeline and dependencies. I also brought a middle option: a simplified version of the analytics feature buildable in 1 sprint slot, with the full version following in the next sprint.',
        result: 'The CHRO chose the simplified version. The board presentation used it successfully. The full feature shipped in the following sprint as committed. None of the originally displaced deliverables were delayed. The CHRO later said the impact analysis made the trade-off clear in a way they hadn\'t expected — and appreciated the honesty.',
        keyMessage: 'Pushing back on leadership isn\'t about saying no. It\'s about showing them the real cost of yes — with data, not opinion — and offering a path that works for everyone. Leaders don\'t want to be told no. They want to make informed choices.'
      }
    },
    {
      id: 'int-beh-02',
      packageId: 'PKG-FUNDAMENTALS',
      question: 'Describe a time a project was failing. What did you do?',
      difficulty: 'Advanced',
      context: 'The interviewer wants self-awareness and leadership under pressure. They expect honesty about the failure and a structured account of your response — including what you learned.',
      evaluatorFocus: 'Diagnosis before reaction, transparent stakeholder communication, structured recovery options, and genuine reflection on lessons learned.',
      star: {
        situation: 'Eight weeks into a data warehouse migration, we were 4 weeks behind schedule: 3 data pipelines untested, the executive sponsor increasingly disengaged, and team morale visibly declining. I had taken over the project 6 weeks in when the original PM departed.',
        task: 'I needed to stabilize the project, restore stakeholder confidence, and give leadership an honest assessment — even though the truth was not what they wanted to hear.',
        action: 'I ran a proper diagnosis first. Two structural root causes: the original scope had been underestimated by 40%, and the team was working across 3 environments with no automated testing. I called a stakeholder meeting within 48 hours and presented 3 recovery scenarios with honest ranges — not a single recovery promise. I recommended a 6-week extension with a 20% scope reduction. I also restructured the work into 2-week milestones with demo checkpoints for the sponsor, which restored their engagement within 2 weeks.',
        result: 'The project delivered 8 weeks late with the agreed scope reduction. The executive sponsor said the transparency in the recovery plan was what rebuilt their confidence — not the original delivery promise. Team morale recovered in week 3 once there was a credible plan.',
        keyMessage: 'When a project is failing, false optimism makes everything worse. Leadership needs an honest picture faster than they need a recovery promise. Diagnose first, communicate early, and bring options — not a better version of false hope.'
      }
    },
    {
      id: 'int-beh-03',
      packageId: 'PKG-FUNDAMENTALS',
      question: 'How do you build trust with engineering teams as a Technical Project Manager?',
      difficulty: 'Intermediate',
      context: 'The interviewer wants to see that you understand the specific dynamics of PM-engineering relationships. Trust is earned through behavior, not authority or title.',
      evaluatorFocus: 'Concrete behaviors over vague principles, awareness that engineers trust through demonstrated reliability, and understanding that process can harm as easily as it helps.',
      star: {
        situation: 'I joined a new engineering organization as the first Technical Project Manager. The team had experienced 2 previous PMs who added overhead without removing friction. There was visible skepticism from the senior engineers and engineering manager in my first week.',
        task: 'I needed to build trust quickly — fast enough that Q3 roadmap planning I was supposed to run wouldn\'t be compromised by the lack of buy-in.',
        action: 'For the first 3 weeks, I focused exclusively on listening and removing blockers — not creating new processes. I attended every standup but spoke only when asked a direct question. I asked each engineer: What\'s the one thing that slows you down most? I turned those answers into a prioritized blockers list and resolved 5 items in my first 2 weeks — including a recurring meeting that was universally hated and a tooling access bottleneck that had existed for 4 months. I made no process changes in month 1.',
        result: 'By the time Q3 roadmap planning started in week 5, the engineering manager proactively asked me to run it. The senior engineers were engaged participants — not skeptical observers. The team-sourced blockers list became a regular artifact that\'s still in use.',
        keyMessage: 'Engineers trust TPMs who make their lives easier, not harder. Show up with a fixed blocker before you introduce any structure. That\'s the fastest credibility-building path in a technical team.'
      }
    },
    {
      id: 'int-sit-01',
      packageId: 'PKG-FUNDAMENTALS',
      question: 'Your release is scheduled in 48 hours but QA just found a critical bug. What do you do?',
      difficulty: 'Advanced',
      context: 'The interviewer wants structured thinking under pressure, a clear decision process, and evidence that you involve the right people rather than acting unilaterally.',
      evaluatorFocus: 'Speed of response, quality of options surfaced, alignment process, and stakeholder communication — all under time pressure.',
      star: {
        situation: '48 hours before the go-live of a payment gateway update, our QA lead escalated a critical bug: under load testing, 12% of transactions were timing out after 30 seconds — well above the 2-second SLA.',
        task: 'I needed to assess severity, convene the right people fast, evaluate options, and drive a go/no-go recommendation — without making the call unilaterally.',
        action: 'Within 30 minutes of the escalation, I pulled the engineering lead, QA lead, and product owner into a decision call. I came with the facts assembled: impact scope (12% of high-load transactions), reproduction rate (consistent under load), and root cause hypothesis (payment processor API rate limiting). I presented three options: ship with a fallback payment method enabled, delay 5 days for a full fix, or ship behind a feature flag with the payment flow temporarily disabled. I gave my recommendation with the rationale.',
        result: 'We chose the feature flag approach. The fix deployed 4 days later. The payment flow was restored with zero timeout incidents in the first 2 weeks post-release. The release manager said it was the fastest structured go/no-go process they had experienced on a critical path issue.',
        keyMessage: 'In a release crisis, speed and alignment are both required. The TPM\'s job is to convene the right people fast, present structured options, and drive a decision — not make the call alone. How quickly you convene the room determines how many options you still have.'
      }
    },
    {
      id: 'int-sit-02',
      packageId: 'PKG-FUNDAMENTALS',
      question: 'Two senior engineers disagree on the technical architecture for a critical component. How do you resolve it?',
      difficulty: 'Advanced',
      context: 'The interviewer wants to see that you can drive to a decision without overstepping technical authority. Your role is facilitator, not judge.',
      evaluatorFocus: 'Facilitation over authority, ability to structure a fair evidence-based process, and getting to a decision with a deadline without damaging relationships.',
      star: {
        situation: 'During the design phase of a microservices refactor, two senior architects reached an impasse: one advocated for event-driven messaging (Kafka), the other for synchronous REST with circuit breakers. Both had strong technical arguments. The disagreement was blocking design finalization for 3 other teams.',
        task: 'I needed to resolve the deadlock without making a technical ruling myself, and without letting it drag beyond 72 hours.',
        action: 'I structured a 2-hour facilitated session. Each architect presented their position for 20 minutes — including risks and failure modes, not just benefits. I then brought in the Staff Engineer as a neutral technical tiebreaker with no prior briefing from either camp. We evaluated both options against 3 criteria: team skill set, operational complexity at scale, and expected request volume in year 2. The Staff Engineer\'s assessment aligned with the event-driven approach, with 2 guardrails that addressed the latency concerns of the other architect.',
        result: 'The decision was made in the 2-hour session. The 3 waiting teams were unblocked by end of day. Both architects contributed to the guardrail design. There was no lingering tension because the process was fair and the evidence drove the outcome.',
        keyMessage: 'When engineers disagree on architecture, your job is to create a fair, evidence-based process for reaching a decision — not to pick the better option. Bring in the right technical voice, structure the evaluation criteria, and set a deadline. The decision will follow.'
      }
    },
    {
      id: 'int-sit-03',
      packageId: 'PKG-FUNDAMENTALS',
      question: 'Your project is 3 weeks behind schedule. Leadership expects the original deadline. What do you do?',
      difficulty: 'Advanced',
      context: 'The interviewer wants resilience, honesty, and structured thinking. Presenting options rather than excuses is a key TPM differentiator.',
      evaluatorFocus: 'Diagnostic discipline before reacting, honest stakeholder communication, presenting real options with trade-offs, and avoiding false optimism.',
      star: {
        situation: 'The Compliance Reporting System was 3 weeks behind schedule due to spec changes from Legal and underestimated integration complexity. The regulatory deadline was immovable, and the CTO had already communicated it to the Legal and QA teams.',
        task: 'I needed to present leadership with an honest assessment and realistic options — not the we\'ll work harder response that had been the default from the previous PM.',
        action: 'I spent 2 hours with the engineering lead doing a proper diagnosis: what was recoverable and what wasn\'t. I built a 3-option brief: add 2 engineers from another team (estimate: recovers 2 of 3 weeks, 40% confidence); reduce scope by deferring the dashboard component (estimate: hits the deadline with 75% confidence); or formally reset the deadline by 2 weeks with a revised milestone plan. I presented the brief in a 20-minute session with the CTO and Legal, with my recommendation stated clearly.',
        result: 'The CTO chose option 2. The dashboard deferral was communicated that day. We hit the regulatory deadline with all core compliance features delivered. The dashboard shipped 3 weeks later as a supplementary release. The CTO said having 3 real options presented clearly was the most useful briefing they had received on the project.',
        keyMessage: 'A project 3 weeks behind needs a TPM who tells leadership the truth with options attached. Trying harder is not a plan. A clear trade-off analysis with a recommendation is.'
      }
    }
    ]
  },

  // ══════════════════════════════════════════════════════════════════════════
  // PACKAGE 2 — Agile & Scrum
  // Competencies: Agile & Scrum · Sprint Planning
  // ══════════════════════════════════════════════════════════════════════════
  {
    id: 'PKG-AGILE',
    name: 'Agile & Scrum',
    icon: '🔄',
    level: 'Beginner',
    description: 'Master iterative delivery, sprint dynamics, and Agile leadership.',
    competencies: { 'Agile & Scrum': 10, 'Sprint Planning': 8 },

    learn: {
      id: 'T2',
      title: 'Agile & Scrum',
      icon: '⚡',
      description: 'Master Agile delivery for software teams — from sprint planning to retrospectives.',
      level: 'Beginner – Intermediate',
      experiences: [

        // ── T2-01: Scrum Ceremonies ─────────────────────────────────────────
        {
          id: 'T2-01',
          title: 'Scrum Ceremonies',
          objective: 'Understand the purpose of each Scrum ceremony and when to use them.',
          duration: '8 min',
          status: 'available',
          competencies: { 'Agile & Scrum': 12, 'Sprint Planning': 8, 'Decision Making': 4 },
          phases: [
            {
              type: 'classify',
              label: 'Challenge',
              title: 'Which Scrum Ceremony?',
              instruction: 'Each activity happens on a real Agile team. Which Scrum ceremony does it belong to?',
              mentorIntro: 'Ceremonies are where Agile teams inspect, adapt, and align. Let\'s see how well you can place these real activities before reading the theory.',
              categories: [
                { id: 'planning',     label: 'Sprint Planning',  icon: '📋' },
                { id: 'standup',      label: 'Daily Standup',    icon: '🔄' },
                { id: 'review',       label: 'Sprint Review',    icon: '🎯' },
                { id: 'retro',        label: 'Retrospective',    icon: '💬' }
              ],
              items: [
                { text: 'The team demos the completed search feature to the Product Owner and stakeholders', correct: 'review', feedbackCorrect: 'Correct. Demonstrating completed work to stakeholders happens in the Sprint Review — the inspection of the product increment.', feedbackWrong: 'Demoing completed work to stakeholders is the Sprint Review. It\'s where the team shows what they built and gets feedback.' },
                { text: 'An engineer shares that a third-party API is blocking their authentication work', correct: 'standup', feedbackCorrect: 'Right. Surfacing blockers is the core purpose of the Daily Standup — keep it short, flag what\'s blocked, move it to the right people.', feedbackWrong: 'Sharing blockers during a short daily sync is the Daily Standup. It\'s the team\'s daily pulse check.' },
                { text: 'The team estimates story points and commits to a sprint goal focused on the login API', correct: 'planning', feedbackCorrect: 'Correct. Sprint Planning is where the team selects backlog items, estimates effort, and commits to a sprint goal.', feedbackWrong: 'Selecting backlog items, estimating, and agreeing on a sprint goal happens in Sprint Planning — at the start of each sprint.' },
                { text: 'The team agrees that code reviews are taking too long and commits to a 24-hour review SLA', correct: 'retro', feedbackCorrect: 'Right. Identifying process improvements and committing to specific changes is the Retrospective — the team\'s continuous improvement ceremony.', feedbackWrong: 'Identifying a process problem and committing to fix it is the Retrospective. It\'s where the team improves how they work, not what they build.' },
                { text: 'A product owner accepts the completed payment integration into the product increment', correct: 'review', feedbackCorrect: 'Correct. The Product Owner\'s acceptance of completed work happens in the Sprint Review — the moment of formal inspection.', feedbackWrong: 'PO acceptance of completed features is a Sprint Review activity. The PO decides what passes and what goes back to the backlog.' },
                { text: 'The team identifies that unclear acceptance criteria caused three rework cycles and proposes a Definition of Ready', correct: 'retro', feedbackCorrect: 'Exactly. Diagnosing a process problem and proposing a systemic fix is exactly what Retrospectives are for.', feedbackWrong: 'When the team analyzes a recurring problem and proposes a process change, that\'s the Retrospective — where continuous improvement happens.' }
              ]
            },
            {
              type: 'reading',
              label: 'Concepts',
              title: 'Scrum Ceremonies',
              mentorIntro: 'You\'ve placed real team activities into ceremonies. Now let\'s understand what each one is designed to do — and why it matters.',
              sections: [
                { heading: 'Why Ceremonies Exist', body: 'Scrum ceremonies aren\'t meetings for the sake of meetings. Each one is an <em>inspect and adapt</em> loop — a structured moment for the team to examine where they are and decide what to do next.<br><br>Without ceremonies, Agile teams drift. The ceremonies create regular feedback cycles that keep product and delivery aligned. A team that skips ceremonies doesn\'t become more efficient — it becomes less visible and more prone to surprises.' },
                { heading: 'Sprint Planning & Daily Standup', body: '<strong>Sprint Planning</strong> opens each sprint. The Product Owner presents the highest-priority backlog items, the team estimates effort (usually in story points), and together they agree on a sprint goal — the "why" behind the sprint\'s work. Good sprint planning produces a realistic commitment, not an optimistic one.<br><br><strong>Daily Standup</strong> keeps the team synchronized. Each member answers: what did I do yesterday, what will I do today, what\'s blocking me? It\'s a 15-minute sync, not a status report to management. The TPM\'s role is to surface blockers and move them off the team — not to direct the work.' },
                { heading: 'Sprint Review & Retrospective', body: '<strong>Sprint Review</strong> closes the sprint on the product side. The team demonstrates completed work to stakeholders, the Product Owner accepts or rejects items, and the backlog is refined based on feedback. It\'s an inspection of the product increment — and a dialogue about what comes next.<br><br><strong>Retrospective</strong> closes the sprint on the process side. The team reflects on how they worked together: what went well, what didn\'t, and what one thing they\'ll improve. Retrospectives that don\'t produce a concrete commitment are Retrospectives that won\'t change anything.' }
              ]
            },
            {
              type: 'quiz',
              label: 'Quiz',
              title: 'Ceremony Check',
              mentorIntro: 'Three scenarios testing your understanding of what each ceremony is designed to accomplish.',
              questions: [
                { question: 'The purpose of the Daily Standup is to:', options: [ { text: 'Report project status to the project manager', correct: false, feedback: 'The standup is a team sync, not a status report to management. The TPM attends to support the team — not to receive reports.' }, { text: 'Surface blockers and synchronize daily work across the team', correct: true, feedback: 'Correct. The standup keeps the team aligned and makes blockers visible so they can be resolved quickly. It\'s a coordination tool, not a reporting mechanism.' }, { text: 'Review sprint velocity and update the roadmap', correct: false, feedback: 'Velocity review and roadmap updates happen in Sprint Review and Planning. The standup is a daily 15-minute sync about today\'s work.' }, { text: 'Allow team members to escalate issues to leadership', correct: false, feedback: 'Escalation happens outside the standup if needed. The standup is an internal team coordination ceremony.' } ] },
                { question: 'Who is responsible for accepting or rejecting sprint deliverables in the Sprint Review?', options: [ { text: 'The Scrum Master', correct: false, feedback: 'The Scrum Master facilitates ceremonies but doesn\'t own product decisions. Acceptance is a product decision.' }, { text: 'The Product Owner', correct: true, feedback: 'Correct. The Product Owner represents business needs and decides whether completed work meets the acceptance criteria. They own the product backlog and the acceptance decision.' }, { text: 'The engineering team lead', correct: false, feedback: 'The engineering lead may advocate for technical decisions, but product acceptance belongs to the Product Owner.' }, { text: 'The entire stakeholder group by vote', correct: false, feedback: 'Stakeholders attend the Sprint Review and provide feedback, but the formal acceptance decision belongs to the Product Owner.' } ] },
                { question: 'A team committed to improving API documentation in their last Retrospective, but nothing changed. As the TPM, what\'s the right approach in the next Retrospective?', options: [ { text: 'Skip it — the team already agreed and re-discussing won\'t help', correct: false, feedback: 'Skipping an unresolved commitment guarantees it stays unresolved. Retrospectives require follow-up, not avoidance.' }, { text: 'Diagnose why the commitment didn\'t stick and agree on a more specific, accountable action', correct: true, feedback: 'Correct. A commitment without follow-through means the commitment wasn\'t specific or accountable enough. The next retro should diagnose the barrier and produce a more concrete improvement action.' }, { text: 'Add it to the engineering backlog', correct: false, feedback: 'Process improvements belong in the team\'s working agreements, not the product backlog. Backlogging it deprioritizes it indefinitely.' }, { text: 'Escalate to the engineering manager', correct: false, feedback: 'Escalation before attempting to solve the problem in the team is premature. Retrospectives are designed to resolve these issues at the team level.' } ] }
              ]
            },
            {
              type: 'keyTakeaway',
              label: 'Takeaway',
              text: 'Ceremonies are not overhead — they are the feedback loops that keep Agile teams aligned, focused, and continuously improving.',
              mentorNote: 'A common TPM mistake is treating ceremonies as check-boxes. The Retrospective especially deserves your full attention — it\'s where teams grow or stagnate.',
              xp: 30
            }
          ]
        },

        // ── T2-02: Sprint Planning ──────────────────────────────────────────
        {
          id: 'T2-02',
          title: 'Sprint Planning for Technical Teams',
          objective: 'Run effective sprint planning sessions that result in realistic commitments.',
          duration: '9 min',
          status: 'available',
          competencies: { 'Sprint Planning': 15, 'Agile & Scrum': 8, 'Decision Making': 5, 'Leadership': 4 },
          phases: [
            {
              type: 'classify',
              label: 'Challenge',
              title: 'Good Planning or Anti-Pattern?',
              instruction: 'Each scenario describes something that happens during sprint planning. Is it a healthy practice or an anti-pattern to avoid?',
              mentorIntro: 'Bad sprint planning habits are very common — and very costly. Let\'s see if you can spot the difference before the theory.',
              categories: [
                { id: 'healthy',      label: 'Healthy Practice', icon: '✅' },
                { id: 'antipattern',  label: 'Anti-Pattern',    icon: '⚠️' }
              ],
              items: [
                { text: 'The team breaks down a large "authentication system" story into smaller tasks and estimates them individually', correct: 'healthy', feedbackCorrect: 'Correct. Breaking large stories into smaller tasks creates visibility, reduces risk, and leads to more accurate estimates. This is a core sprint planning skill.', feedbackWrong: 'Breaking large stories down is a healthy practice. It creates better estimates, reduces surprises, and makes work easier to distribute.' },
                { text: 'The manager tells the team they must commit to 50 story points because "last sprint they did 48"', correct: 'antipattern', feedbackCorrect: 'Right. Imposed velocity targets destroy Agile. The team should commit based on their own judgment of capacity — not on pressure from management.', feedbackWrong: 'Imposed velocity targets are a classic Agile anti-pattern. The team owns their commitment — management imposing it breaks trust and leads to poor-quality "commitments".' },
                { text: 'The Product Owner explains the business context behind each backlog item before estimation', correct: 'healthy', feedbackCorrect: 'Correct. Engineers make better estimates when they understand the "why" behind a story. Context from the PO reduces assumptions and rework.', feedbackWrong: 'PO context before estimation is a healthy practice. It helps engineers ask the right questions and produce more accurate estimates.' },
                { text: 'The team pulls in new stories during the sprint because some tickets are estimated as "too small"', correct: 'antipattern', feedbackCorrect: 'Right. Adding work mid-sprint disrupts focus and violates the sprint commitment. If the team finishes early, there are better ways to handle it than pulling unplanned work.', feedbackWrong: 'Mid-sprint scope additions — even well-intentioned ones — destabilize the sprint. The sprint commitment should be protected.' },
                { text: 'The team sets a clear sprint goal that ties all selected backlog items to a shared outcome', correct: 'healthy', feedbackCorrect: 'Correct. A sprint goal gives the team a north star — a shared reason for the sprint\'s existence beyond just completing tasks. It enables better decision-making during delivery.', feedbackWrong: 'A sprint goal is one of the most important outputs of sprint planning. Without it, the team is just working a task list with no shared direction.' },
                { text: 'The TPM adds tickets to the sprint after planning ends because a stakeholder flagged them as urgent', correct: 'antipattern', feedbackCorrect: 'Right. The sprint commitment is a team agreement — adding work after planning without team consent undermines that agreement and the trust that makes Agile work.', feedbackWrong: 'Post-planning additions — even from urgent stakeholders — are an anti-pattern. The right process is to bring urgency to the Product Owner, who may swap backlog items — but always with team agreement.' }
              ]
            },
            {
              type: 'reading',
              label: 'Concepts',
              title: 'Sprint Planning',
              mentorIntro: 'You\'ve identified what good and bad planning looks like. Here\'s how to run sprint planning that produces real commitments.',
              sections: [
                { heading: 'What Sprint Planning Produces', body: 'A successful sprint planning session produces two things: a <strong>sprint goal</strong> and a <strong>sprint backlog</strong>.<br><br>The sprint goal is the "why" — a single sentence that describes the value the team will deliver this sprint. It keeps the team focused when trade-offs arise mid-sprint. The sprint backlog is the "what and how" — the selected stories, broken down into tasks, with effort estimated by the team.<br><br>If a team leaves planning without a clear sprint goal, they have a task list — not a commitment.' },
                { heading: 'Capacity-Based Commitment', body: 'Velocity is a historical average — a planning input, not a target. The team\'s actual capacity each sprint depends on holidays, planned absences, technical debt, and the type of work being done.<br><br>A healthy planning session starts with capacity: how many developer-days do we have this sprint? Then the team selects work that fits that capacity. The TPM\'s role is to protect the capacity calculation from optimism and external pressure.<br><br>Teams that consistently over-commit have learned that their estimates don\'t matter — because they\'re adjusted by management anyway. Protect realistic commitment to protect team trust.' },
                { heading: 'The TPM\'s Role in Planning', body: 'The TPM is not the sprint planner — the team plans together. The TPM\'s role during sprint planning is:<br><br>• Ensure the <strong>sprint goal is clear</strong> and ties to the product roadmap<br>• <strong>Protect the team\'s capacity</strong> from external pressure and last-minute additions<br>• Surface <strong>dependencies and risks</strong> that could affect the sprint (team member availability, external APIs, pending decisions)<br>• Ensure <strong>acceptance criteria are clear</strong> before the team commits to a story<br><br>A TPM who dominates sprint planning prevents the team from owning their commitment. A TPM who disappears from sprint planning misses critical risk signals.' }
              ]
            },
            {
              type: 'quiz',
              label: 'Quiz',
              title: 'Planning Check',
              mentorIntro: 'Three planning scenarios that test your judgment on capacity, commitment, and the TPM\'s role.',
              questions: [
                { question: 'A team\'s historical velocity is 36 story points per sprint. Two engineers will be on leave for 3 days this sprint. What should happen to the sprint commitment?', options: [ { text: 'Keep it at 36 — the team will compensate', correct: false, feedback: 'Hoping the team will compensate ignores real capacity loss. Forcing the same commitment with reduced resources typically means lower quality or unfinished stories.' }, { text: 'Reduce the commitment proportionally to reflect actual capacity', correct: true, feedback: 'Correct. Velocity is based on full-team capacity. Planned absences reduce available developer-days, so the commitment should be adjusted to match actual capacity.' }, { text: 'Add more engineers to maintain velocity', correct: false, feedback: 'Adding engineers mid-sprint creates ramp-up overhead that usually reduces velocity further. Brooks\'s Law applies here.' }, { text: 'Extend the sprint by 3 days', correct: false, feedback: 'Sprint length is fixed to maintain predictability. The right adjustment is reducing scope, not extending the timebox.' } ] },
                { question: 'During sprint planning, an engineer says a story\'s acceptance criteria are unclear. What should happen?', options: [ { text: 'The engineer should make their best guess and proceed', correct: false, feedback: 'Proceeding with unclear acceptance criteria almost always produces rework. The whole point of planning is to clarify before committing.' }, { text: 'The story should be deferred until the Product Owner clarifies the acceptance criteria', correct: true, feedback: 'Correct. A story without clear acceptance criteria can\'t be reliably estimated or delivered. Deferring it protects the sprint from ambiguity-driven rework.' }, { text: 'The Product Owner should estimate the story on behalf of the team', correct: false, feedback: 'The Product Owner defines requirements, not effort estimates. Estimation is always a team activity.' }, { text: 'The Scrum Master should add the story to the next sprint automatically', correct: false, feedback: 'Automatic deferral without clarification just pushes the problem forward. The story needs its acceptance criteria resolved before it\'s pulled into any sprint.' } ] },
                { question: 'A stakeholder contacts the TPM during a sprint and requests adding a "critical" feature immediately. What is the right response?', options: [ { text: 'Add the feature to the sprint — stakeholder urgency takes priority', correct: false, feedback: 'Adding work after sprint planning without team consent undermines the sprint commitment and signals that commitments don\'t matter.' }, { text: 'Reject it — no changes are allowed during a sprint under any circumstances', correct: false, feedback: 'Absolute inflexibility isn\'t Agile either. In genuine emergencies, the Product Owner and team can decide to swap stories — but with full team consent.' }, { text: 'Escalate immediately to the Scrum Master', correct: false, feedback: 'The Scrum Master facilitates but doesn\'t own product prioritization. This conversation belongs with the Product Owner.' }, { text: 'Bring the request to the Product Owner, who evaluates priority and — if urgent enough — facilitates a scope swap with team agreement', correct: true, feedback: 'Correct. This respects both the stakeholder\'s urgency and the team\'s commitment. The Product Owner decides priority; the team decides if a swap is feasible. Nothing gets added without their agreement.' } ] }
              ]
            },
            {
              type: 'keyTakeaway',
              label: 'Takeaway',
              text: 'Sprint planning produces a commitment, not a wish list. Protect the team\'s capacity, clarify acceptance criteria before committing, and never let urgency bypass the planning process.',
              mentorNote: 'The most common sprint planning failure is committing to more than the team can deliver. Protect realistic commitments — it builds the trust that makes the team\'s next commitment credible.',
              xp: 35
            }
          ]
        },

        { id: 'T2-03', title: 'Managing Sprint Risks',      objective: 'Identify and respond to risks that emerge inside a sprint.', duration: '8 min', status: 'coming-soon' },
        { id: 'T2-04', title: 'Agile at Scale',             objective: 'Coordinate multiple Agile teams working on the same product.', duration: '10 min', status: 'coming-soon' }
      ]
    },

    practice: [
      {
    id: 'ch-01',
    title: 'Sprint Re-scope Decision',
    difficulty: 'Intermediate',
    tags: ['Agile', 'Risk', 'Planning'],
    projectContext: {
      project: 'Customer Portal Rebuild',
      status: 'Sprint 2 of 6',
      priority: 'High',
      team: 'Product Owner, Tech Lead, 2 Backend Devs'
    },
    context: 'On day 2 of your current sprint, your senior backend engineer calls in sick and will be out for at least two weeks. Your team committed to 38 story points, including three high-priority API features tied to a stakeholder demo.',
    question: 'What is your best next move?',
    skills: ['Agile Planning', 'Stakeholder Communication', 'Team Leadership'],
    competencies: { 'Agile & Scrum': 8, 'Stakeholder Communication': 8, 'Leadership': 6 },
    options: [
      {
        text: 'Keep the sprint plan as-is. The team can compensate.',
        correct: false,
        feedback: 'Forcing an unchanged plan onto a reduced team leads to rushed work, technical debt, and missed commitments — all worse outcomes than a transparent re-scope.',
        mentorComment: 'This is a common instinct for new TPMs who want to protect the schedule at all costs. The schedule is a tool, not a promise.'
      },
      {
        text: 'Cancel the sprint entirely and restart next week.',
        correct: false,
        feedback: 'Sprint cancellation is reserved for situations where the goal itself is no longer valid — not for capacity changes. This creates unnecessary disruption and wastes work already done.',
        mentorComment: 'Cancelling a sprint signals a bigger problem. Save it for when the sprint goal has fundamentally changed, not when capacity dips.'
      },
      {
        text: 'Meet with the team, re-scope to the highest-priority items, and communicate updated expectations to stakeholders.',
        correct: true,
        feedback: 'This balances delivery realism with stakeholder trust. Re-scoping protects quality while keeping stakeholders informed — a core TPM responsibility.',
        mentorComment: 'Excellent prioritization. Proactive, honest, and focused on what matters most. This is the move that builds long-term credibility with stakeholders.'
      },
      {
        text: 'Ask the Product Owner to bring in additional developers immediately.',
        correct: false,
        feedback: 'Adding people mid-sprint typically reduces velocity rather than increasing it. Brooks\'s Law: adding manpower to a late software project makes it later.',
        mentorComment: 'Brooks\'s Law is worth memorizing for your next TPM interview. Knowing when NOT to add resources is as important as knowing when to.'
      }
    ]
  },
    {
    id: 'ch-06',
    title: 'Velocity Drop Mid-Roadmap',
    difficulty: 'Intermediate',
    tags: ['Agile', 'Metrics', 'Planning'],
    projectContext: {
      project: 'Fintech Data Platform',
      status: 'Sprint 5 of 12',
      priority: 'High',
      team: 'Scrum Master, 6 Engineers (2 new), Product Owner'
    },
    context: 'After a team restructure and two new engineer onboardings, your Scrum team\'s velocity dropped from 42 to 24 story points over three consecutive sprints. The product roadmap was built on the original velocity. A major release is planned in 8 weeks.',
    question: 'What do you do first?',
    skills: ['Agile Metrics', 'Forecasting', 'Team Dynamics'],
    competencies: { 'Agile & Scrum': 8, 'Sprint Planning': 7, 'Leadership': 5 },
    options: [
      {
        text: 'Pressure the team to return to 42 points — the roadmap depends on it.',
        correct: false,
        feedback: 'Pressuring teams to inflate velocity produces lower-quality work and burned-out engineers. Velocity is a planning input, not a performance target to impose.',
        mentorComment: 'Velocity pressure is one of the fastest ways to destroy a team\'s trust in their TPM. The data is telling you something — listen to it instead of fighting it.'
      },
      {
        text: 'Immediately cut the release scope and revise the roadmap.',
        correct: false,
        feedback: 'Cutting scope before understanding the root cause may be premature. If the velocity drop is temporary (onboarding overhead), the original roadmap may still be achievable.',
        mentorComment: 'Diagnose before you prescribe. Cutting scope is sometimes the right call, but only after you understand what caused the drop and whether it will self-correct.'
      },
      {
        text: 'Run a structured retrospective to identify the root cause, then reforecast and adjust accordingly.',
        correct: true,
        feedback: 'Understanding the cause — onboarding overhead, unclear requirements, team dynamics — tells you whether the drop is temporary or structural. Only then can you reforecast and make sound decisions.',
        mentorComment: 'Exactly right. New members take 2-3 sprints to reach full productivity. That context changes everything. Diagnose first, decide second.'
      },
      {
        text: 'Replace the two slowest engineers before the release.',
        correct: false,
        feedback: 'Team changes mid-project almost always reduce velocity further. New members take sprints to ramp up. This would make the 8-week deadline significantly harder to meet.',
        mentorComment: 'This is a harmful instinct to override. People changes mid-project add weeks of ramp-up time. Stability is almost always more valuable than the marginal gain of a personnel swap.'
      }
    ]
  }
    ],

    interview: [
          {
      id: 'int-agile-01',
      packageId: 'PKG-AGILE',
      question: 'Your team\'s velocity drops significantly mid-project. How do you respond?',
      difficulty: 'Intermediate',
      context: 'The interviewer wants data-driven thinking, transparent communication, and understanding that velocity is a planning tool — not a performance metric to be pressured up.',
      evaluatorFocus: 'Diagnostic discipline before prescription, transparent stakeholder communication with real options, and not pressuring the team to artificially recover velocity.',
      star: {
        situation: 'In sprint 6 of a 10-sprint Customer Data Platform build, our team\'s velocity dropped from 42 to 23 story points — a 45% decline that put the release date at risk.',
        task: 'I needed to diagnose the root cause, communicate the forecast impact to stakeholders, and recommend a path forward — without creating panic or pressuring the team.',
        action: 'I ran an emergency retrospective before the next sprint planning. Two root causes: a new third-party API integration had hidden complexity, and two senior engineers had been pulled for unplanned work on another project. I prepared a revised forecast with two release scenarios — reduced scope hitting the original date, or full scope requiring 2 additional sprints — and presented both to the product owner and stakeholders with my recommendation.',
        result: 'Stakeholders chose the full-scope extension. Velocity recovered to 38 points in sprint 8 once the API integration was complete. We launched on the revised date with all planned features. Critically, no one was surprised by the delay — they had seen the data and made the call themselves.',
        keyMessage: 'Velocity is a planning tool, not a performance metric. When it drops, the right question is what changed — not who is underperforming? Diagnose before reacting, and bring stakeholders real options instead of false optimism.'
      }
    },
    {
      id: 'int-agile-02',
      packageId: 'PKG-AGILE',
      question: 'How do you handle a situation where key requirements keep changing mid-sprint?',
      difficulty: 'Intermediate',
      context: 'The interviewer wants to see that you can protect team focus without being rigidly inflexible, and that you address root causes rather than just symptoms.',
      evaluatorFocus: 'Protecting sprint commitments without eliminating legitimate flexibility, and addressing root cause (poor backlog management, unclear vision) rather than just managing symptoms.',
      star: {
        situation: 'During an e-commerce checkout redesign, our Product Owner began revising requirements mid-sprint 3, responding to A/B test data that arrived after sprint planning. By midweek, 3 of 8 committed stories had been touched with new acceptance criteria.',
        task: 'I needed to stop the disruption while making sure genuine, high-value changes weren\'t blocked entirely by process rigidity.',
        action: 'I had a direct conversation with the Product Owner — not in front of the team. I showed them data: mid-sprint changes had already cost us 9 story points of rework in this sprint alone. I proposed a structured intake process: new requirements could be added to a sprint buffer during the sprint, reviewed in the last 2 days for promotion to the next sprint or emergency-promotion with team agreement. I also helped establish a sprint freeze policy: no changes to committed stories after day 3, except critical bugs.',
        result: 'The following sprint was the cleanest in the project. The Product Owner adapted quickly once they had a clear fast-track channel. Team velocity recovered to planning baseline within 2 sprints.',
        keyMessage: 'Protecting the sprint doesn\'t mean saying no to important business needs — it means creating a fair, explicit process for evaluating which changes are worth the disruption and which can wait without real cost.'
      }
    },
    {
      id: 'int-agile-03',
      packageId: 'PKG-AGILE',
      question: 'How would you scale Agile across three teams working on the same product?',
      difficulty: 'Advanced',
      context: 'The interviewer wants to see that you understand the coordination overhead of multi-team Agile and have thought practically about alignment, dependencies, and integration.',
      evaluatorFocus: 'Practical coordination layer design, dependency management at scale, team autonomy within constraints, and integration milestone planning.',
      star: {
        situation: 'A Unified Data Platform had grown from 1 Scrum team to 3, with 18 engineers, 3 Product Owners, and a growing set of cross-team dependencies forming around a shared data layer. There was no coordination model yet.',
        task: 'I was asked to design the scaling model — including how teams would coordinate, how dependencies would be managed, and how we would deliver integrated milestones.',
        action: 'I implemented a lightweight coordination layer. We ran quarterly PI Planning sessions where all three teams aligned on a shared 10-week program roadmap. Between PI cycles, I ran a weekly ART sync — 30 minutes, team leads only — to surface cross-team dependencies and blockers. Each team maintained their own sprint cadence and backlog. Integration milestones were added to all three team calendars as hard commitments.',
        result: 'In the first quarter under this model, we delivered 94% of planned program-level features on time — up from 71% in the single-team model. PI Planning surfaced 12 cross-team dependencies that had been completely invisible before.',
        keyMessage: 'Multi-team Agile lives or dies on dependency management and integration planning. A lightweight coordination layer — not a full SAFe org chart — is what most programs actually need. Define the rhythm, surface dependencies early, and protect team autonomy within clear constraints.'
      }
    }
    ]
  },

  // ══════════════════════════════════════════════════════════════════════════
  // PACKAGE 3 — Risk Management
  // Competencies: Risk Management · Decision Making
  // ══════════════════════════════════════════════════════════════════════════
  {
    id: 'PKG-RISK',
    name: 'Risk Management',
    icon: '⚠️',
    level: 'Intermediate',
    description: 'Identify, assess, and respond to project risks before they become problems.',
    competencies: { 'Risk Management': 12, 'Decision Making': 8 },

    learn: {
      id: 'T4',
      title: 'Risk Management', icon: '⚠️',
      description: 'Identify, assess, and respond to IT project risk before it becomes an incident.',
      level: 'Intermediate',
      experiences: [
        {
          id: 'T4-01',
          title: 'Risk or Issue?',
          subtitle: 'Learn to tell the difference — before it costs your project.',
          duration: '15 min', xp: 100,
          competencies: { 'Risk Management': 12, 'Decision Making': 6, 'Technical Communication': 4 },
          phases: [
            {
              type: 'classify',
              label: 'Risk or Issue?',
              title: 'Classify Each Item',
              instruction: 'Is this a Risk (something that might happen) or an Issue (something already happening)?',
              mentorIntro: 'Most new TPMs treat risks and issues as the same thing. They\'re not. This distinction determines whether you write a risk response plan or an incident action plan.',
              categories: [
                { id: 'risk',  icon: '⚠️', label: 'Risk' },
                { id: 'issue', icon: '🔥', label: 'Issue' }
              ],
              items: [
                { text: 'The third-party payment API may introduce breaking changes in their next release.',
                  correct: 'risk',
                  feedbackCorrect: '"May introduce" is future and uncertain — that\'s a risk. Add it to your register and plan a response.',
                  feedbackWrong: 'This is a risk — it hasn\'t happened yet. "May introduce" signals future uncertainty. Log it in the risk register.' },
                { text: 'The staging environment is down and the team can\'t deploy today\'s build.',
                  correct: 'issue',
                  feedbackCorrect: 'Right. The environment is down now. This is an active issue requiring immediate action.',
                  feedbackWrong: 'This is an issue — it\'s happening right now. Issues need immediate action plans, not risk responses.' },
                { text: 'The new QA engineer might not be ready to test independently by week 3.',
                  correct: 'risk',
                  feedbackCorrect: '"Might not be ready" is future uncertainty. Plan a contingency — perhaps pair them with a senior QA.',
                  feedbackWrong: 'This is a risk. It hasn\'t happened yet. The word "might" is your signal. Plan for both scenarios.' },
                { text: 'A key backend developer just handed in their resignation.',
                  correct: 'issue',
                  feedbackCorrect: 'The resignation is confirmed — this is an active issue affecting your delivery plan right now.',
                  feedbackWrong: 'This is an issue. The resignation is real. You\'re already impacted and need to respond today.' },
                { text: 'The client may request a scope change after the MVP demo next week.',
                  correct: 'risk',
                  feedbackCorrect: '"May request" is uncertain and future — a risk worth documenting with a change control plan ready.',
                  feedbackWrong: 'This is a risk. The request hasn\'t happened yet. Document it and prepare your change control process in advance.' },
                { text: 'QA discovered a critical security vulnerability in production this morning.',
                  correct: 'issue',
                  feedbackCorrect: 'A discovered vulnerability in production is an active issue. Escalate and activate your incident response process.',
                  feedbackWrong: 'This is an issue — the vulnerability is already in production. You\'re past risk management. Act now.' }
              ]
            },
            {
              type: 'reading',
              label: 'The Risk Framework',
              mentorIntro: 'You\'ve seen the difference in practice. Now let\'s build the framework that makes risk thinking automatic.',
              sections: [
                { heading: 'Risk vs. Issue — Why It Matters',
                  body: '<p>A <strong>risk</strong> is a future uncertainty. It might happen. It hasn\'t yet.</p><p>An <strong>issue</strong> is a current problem. It\'s already affecting your project.</p><p>This distinction drives completely different responses:</p><ul><li><strong>Risks</strong> → Identify, assess, plan a response, monitor</li><li><strong>Issues</strong> → Escalate, assign an owner, resolve, communicate</li></ul><p>Treating an issue as a risk — and doing nothing yet — is one of the most common and costly PM mistakes in IT projects.</p>',
                  explainSimply: 'Think of a risk like rain in the forecast. It might happen — so you bring an umbrella. An issue is when it\'s already raining and you forgot the umbrella. Two different problems. Two different responses.' },
                { heading: 'IT Risk Categories',
                  body: '<p>In IT projects, risks cluster into five categories:</p><ul><li><strong>Technical</strong> — new technology, integration complexity, unknown APIs, infrastructure instability</li><li><strong>Schedule</strong> — aggressive timelines, underestimated tasks, dependencies on other teams</li><li><strong>Resource</strong> — key person dependencies, onboarding delays, team turnover</li><li><strong>Dependency</strong> — third-party vendors, external APIs, other teams\' deliverables blocking yours</li><li><strong>Scope</strong> — unclear requirements, stakeholder changes, scope creep</li></ul><p>Good TPMs proactively scan all five categories before every sprint.</p>',
                  explainSimply: 'Five buckets: tech problems, timing problems, people problems, waiting-on-others problems, and the "what are we actually building?" problem. Scan all five at the start of every sprint.' },
                { heading: 'The Risk Register',
                  body: '<p>A risk register is a living document tracking every identified risk. Each entry needs:</p><ul><li><strong>Risk description</strong> — what might happen and why</li><li><strong>Probability</strong> — High / Medium / Low</li><li><strong>Impact</strong> — if it happens, how bad? High / Medium / Low</li><li><strong>Risk owner</strong> — one person responsible for monitoring and responding</li><li><strong>Response plan</strong> — what will you do if it occurs?</li><li><strong>Status</strong> — Open, Mitigated, Closed, Triggered</li></ul><p>Updated weekly, the risk register becomes your early warning system for every sprint and release.</p>',
                  explainSimply: 'A risk register is a list of things that might go wrong, with a plan for each one. The goal: no surprises. When something happens, you already know what to do.' }
              ]
            },
            {
              type: 'quiz',
              label: 'Apply the Framework',
              mentorIntro: 'Three scenarios. Apply what you\'ve just learned. The goal is judgment, not memorization.',
              questions: [
                { question: 'Your cloud provider announces a maintenance window that overlaps with your production release. What is the most appropriate first action?',
                  options: [
                    { text: 'Log it as an issue and escalate immediately to leadership.', correct: false, feedback: 'This is not yet an issue — the maintenance hasn\'t happened and your release hasn\'t been blocked. Escalating without a plan wastes time and credibility.' },
                    { text: 'Log it as a risk, assess the impact, and plan a response — either reschedule or coordinate with the cloud provider.', correct: true, feedback: 'Correct. This is a risk: the overlap might cause a problem. Assess the impact and prepare a response before it becomes an issue.' },
                    { text: 'Ignore it — maintenance windows rarely cause problems.', correct: false, feedback: 'Ignoring a known risk is not risk management — it\'s wishful thinking. Even low-probability risks with high impact deserve a response plan.' },
                    { text: 'Cancel the release and reschedule without investigating further.', correct: false, feedback: 'Premature. Assess the actual overlap and impact first. Cancelling without analysis wastes delivery time.' }
                  ]
                },
                { question: 'Your developer says: "I\'m not sure the integration with the legacy system will work. We\'ve never done it before." How should you handle this?',
                  options: [
                    { text: 'Trust the developer\'s expertise and assume it will be fine.', correct: false, feedback: 'Assumption is not risk management. Unknown integrations with legacy systems are a classic source of technical risk.' },
                    { text: 'Log it as a technical risk, assign the developer as owner, and add a spike to validate the integration next sprint.', correct: true, feedback: 'Excellent. A technical unknown is a risk. A spike validates the assumption early — before it becomes a sprint-blocking issue.' },
                    { text: 'Add buffer days to the schedule and move on.', correct: false, feedback: 'Buffer alone doesn\'t address the risk. What happens if the integration fails completely? Buffer doesn\'t answer that.' },
                    { text: 'Log it as an issue and pause the sprint until resolved.', correct: false, feedback: 'It\'s a risk, not an issue. Pausing the sprint for something that might not happen is an overreaction. Investigate in parallel.' }
                  ]
                },
                { question: 'Which of these belongs in a risk register?',
                  options: [
                    { text: 'The production database went down at 3pm and is affecting 500 users.', correct: false, feedback: 'This is an active issue. It belongs in an incident log. Respond immediately.' },
                    { text: 'The senior architect who designed the payment module may leave the company next quarter.', correct: true, feedback: 'Correct. "May leave" is future and uncertain with high impact. Document it and plan a knowledge transfer.' },
                    { text: 'The team missed last sprint\'s velocity target by 20%.', correct: false, feedback: 'This is already happening — a performance issue, not a risk. Diagnose the root cause and adjust the plan.' },
                    { text: 'A critical bug was found in the payment flow during QA.', correct: false, feedback: 'A found bug is an issue — it exists now. Log it in the bug tracker, assign an owner, track resolution.' }
                  ]
                }
              ]
            },
            {
              type: 'keyTakeaway',
              label: 'Key Takeaway',
              text: 'A risk is a future uncertainty. An issue is a current problem. Managing them the same way is a mistake TPMs cannot afford. Build the habit of scanning for risks weekly — before they become the fire you\'re fighting on Friday afternoon.',
              xp: 100,
              mentorNote: 'The best TPMs aren\'t the ones who solve the most crises. They\'re the ones who prevent them. That starts with a risk register you actually maintain.'
            }
          ]
        },
        {
          id: 'T4-02',
          title: 'Assessing and Responding to Risk',
          subtitle: 'Not all risks are equal — learn to prioritize and act with precision.',
          duration: '18 min', xp: 110,
          competencies: { 'Risk Management': 15, 'Decision Making': 10, 'Negotiation': 5 },
          phases: [
            {
              type: 'classify',
              label: 'High, Medium, or Low?',
              title: 'Prioritize These Risks',
              instruction: 'Based on probability and potential impact, classify each risk as HIGH, MEDIUM, or LOW priority.',
              mentorIntro: 'Not every risk deserves the same attention. Your job is to prioritize so you spend energy where it matters.',
              categories: [
                { id: 'high',   icon: '🔴', label: 'High' },
                { id: 'medium', icon: '🟡', label: 'Medium' },
                { id: 'low',    icon: '🟢', label: 'Low' }
              ],
              items: [
                { text: 'The payment gateway has had 3 outages in the last 6 months. Your go-live depends on it being available during a 2-hour migration window.',
                  correct: 'high',
                  feedbackCorrect: 'Correct. High probability (pattern of outages) × High impact (go-live dependency) = HIGH priority. This needs an active mitigation plan.',
                  feedbackWrong: 'This is HIGH priority. The history of outages and go-live dependency make this a critical risk. It demands a contingency plan.' },
                { text: 'A junior developer is learning a new framework. There\'s a small chance they\'ll need more time than estimated on one task.',
                  correct: 'low',
                  feedbackCorrect: 'Good. Low probability × Low impact (one task) = LOW priority. Monitor it, but don\'t over-invest.',
                  feedbackWrong: 'This is LOW priority. Impact is limited to one task, probability is low. Log it and check in weekly.' },
                { text: 'A key vendor hasn\'t confirmed their delivery date for a component your team depends on in 3 weeks.',
                  correct: 'high',
                  feedbackCorrect: 'Right. Uncertain delivery + 3-week timeline + blocking dependency = HIGH priority. Follow up immediately and prepare an alternative.',
                  feedbackWrong: 'This is HIGH priority. An unconfirmed delivery blocking your timeline in 3 weeks is urgent. Escalate and prepare a backup plan now.' },
                { text: 'Your retrospective might go 15 minutes over if the team has a lot to discuss.',
                  correct: 'low',
                  feedbackCorrect: 'Correct. Low probability, minimal impact on delivery. This is LOW priority — no risk response plan needed.',
                  feedbackWrong: 'This is LOW priority. A slightly longer retrospective has negligible impact on delivery. Some things don\'t deserve a formal response.' },
                { text: 'New data privacy regulations are expected to take effect next month and may require changes to your data handling architecture.',
                  correct: 'high',
                  feedbackCorrect: 'Correct. Near-certain regulatory changes with architecture impact = HIGH priority. Act immediately.',
                  feedbackWrong: 'This is HIGH priority. Near-certain regulatory changes with large scope impact demand immediate attention and escalation.' }
              ]
            },
            {
              type: 'reading',
              label: 'Assess and Respond',
              mentorIntro: 'You have good instincts. Now here\'s the framework that makes your prioritization consistent and defensible to stakeholders.',
              sections: [
                { heading: 'The Probability × Impact Matrix',
                  body: '<p>Every risk has two dimensions:</p><ul><li><strong>Probability</strong> — how likely is this to happen?</li><li><strong>Impact</strong> — if it happens, how much does it affect cost, schedule, or quality?</li></ul><p>Combining these gives you a priority level:</p><ul><li><strong>High × High</strong> → Critical. Immediate response required.</li><li><strong>High × Low or Low × High</strong> → Monitor actively. Have a contingency ready.</li><li><strong>Low × Low</strong> → Log it. Review weekly. No heavy investment needed.</li></ul><p>This matrix stops you from ignoring real risks — or wasting energy on unlikely ones.</p>',
                  explainSimply: 'Multiply how likely it is by how bad it would be. High × High = deal with it now. Low × Low = keep an eye on it. Everything else falls somewhere in between.' },
                { heading: 'The Four Response Strategies',
                  body: '<p>Once you\'ve assessed a risk, you have four options:</p><ul><li><strong>Avoid</strong> — change the plan to eliminate the risk. (Replace an unstable API with a stable alternative.)</li><li><strong>Mitigate</strong> — reduce the probability or impact. (Add integration tests to catch failures early.)</li><li><strong>Transfer</strong> — shift the risk to another party. (SLA clauses in vendor contracts, insurance, outsourcing.)</li><li><strong>Accept</strong> — acknowledge it and prepare a contingency. (Log it, monitor it, have a rollback plan ready.)</li></ul><p>The right strategy depends on the risk\'s nature, your leverage, and the cost of each response.</p>',
                  explainSimply: 'Four moves: don\'t take the risk (Avoid), make it less likely or less damaging (Mitigate), make it someone else\'s problem (Transfer), or live with it but have a Plan B (Accept). Every risk deserves one of these four.' },
                { heading: 'Risk Owners and Trigger Points',
                  body: '<p>A risk with no owner is just a worry. Every risk needs:</p><ul><li><strong>An owner</strong> — one person responsible for monitoring and responding. Not "the team."</li><li><strong>A trigger point</strong> — the specific condition that activates the response plan.</li><li><strong>A review cadence</strong> — review risks at every sprint review or weekly at minimum.</li></ul><p>Well-managed risks don\'t surprise you. They have an owner watching them and a response ready to execute the moment a trigger fires.</p>',
                  explainSimply: 'Every risk needs a name on it — one person who watches it and acts when it triggers. A risk with no owner is invisible. And invisible risks become Friday afternoon crises.' }
              ]
            },
            {
              type: 'quiz',
              label: 'Choose the Right Response',
              mentorIntro: 'Three real scenarios. Pick the response strategy that fits. Think like a TPM, not a textbook.',
              questions: [
                { question: 'Your mobile app depends on a third-party maps API. The vendor announced it will deprecate a key endpoint in 90 days. Best response strategy?',
                  options: [
                    { text: 'Accept — the endpoint might still work past the deprecation date.', correct: false, feedback: 'Accepting a confirmed deprecation with a 90-day deadline is denial, not acceptance. The risk is almost certain to trigger.' },
                    { text: 'Mitigate — build a fallback to a secondary maps provider and test both in staging.', correct: true, feedback: 'Good thinking. Mitigation reduces impact by preparing a fallback. If the endpoint fails, you switch without downtime.' },
                    { text: 'Transfer — add a clause making the vendor responsible for continuity.', correct: false, feedback: 'The vendor already announced the deprecation — renegotiating now is unlikely to help. Transfer works best before you\'re locked in.' },
                    { text: 'Avoid — cancel the mapping feature entirely.', correct: false, feedback: 'Avoiding the feature removes value for users. Mitigation is more proportionate — it addresses the risk without sacrificing the feature.' }
                  ]
                },
                { question: 'There\'s a 10% chance a legacy database migration will fail and require a rollback, delaying go-live by one day. Right response?',
                  options: [
                    { text: 'Avoid — rewrite the database architecture to eliminate the migration.', correct: false, feedback: 'Avoiding a 10% risk by rewriting the entire architecture is massively disproportionate. The cost far exceeds the risk.' },
                    { text: 'Transfer — include a clause making the contractor liable for migration failure.', correct: false, feedback: 'Transfer might reduce financial exposure, but it doesn\'t protect your go-live date. You still need an operational plan.' },
                    { text: 'Accept — document the rollback plan, test it in staging, and brief the team. One day\'s delay is manageable.', correct: true, feedback: 'Correct. Low probability × manageable impact = Accept. The key is a tested rollback plan so the response is fast and controlled if it triggers.' },
                    { text: 'Mitigate — delay go-live by two weeks to allow more testing.', correct: false, feedback: 'Delaying by two weeks to address a one-day risk at 10% probability is over-engineering. Accept with a tested contingency.' }
                  ]
                },
                { question: 'When is the Transfer risk response strategy most appropriate?',
                  options: [
                    { text: 'When you want to reduce the probability of the risk occurring.', correct: false, feedback: 'Reducing probability is Mitigation, not Transfer. Transfer shifts responsibility — it doesn\'t inherently reduce probability.' },
                    { text: 'When you eliminate the risk by changing your approach entirely.', correct: false, feedback: 'Changing your approach to eliminate the risk is Avoidance. Transfer keeps the risk but moves who is responsible for it.' },
                    { text: 'When you shift the financial or operational consequence to another party — vendor, insurer, or contractor.', correct: true, feedback: 'Correct. Transfer moves consequences, not the risk itself. SLAs, contracts, insurance, and outsourcing are all Transfer mechanisms.' },
                    { text: 'When you decide the risk is small enough to live with.', correct: false, feedback: 'Living with a risk is Acceptance — and even then, you need a contingency plan. Transfer always involves another party.' }
                  ]
                }
              ]
            },
            {
              type: 'keyTakeaway',
              label: 'Key Takeaway',
              text: 'Not all risks deserve the same response. Use Probability × Impact to prioritize. Then choose your strategy: Avoid, Mitigate, Transfer, or Accept. Every risk needs an owner and a trigger point — otherwise it\'s just a worry waiting to become a crisis.',
              xp: 110,
              mentorNote: 'Stakeholders will ask about risks before every major milestone. The TPMs who answer with a P×I score and a response strategy earn credibility. The ones who say "we\'re monitoring it" lose it.'
            }
          ]
        }
      ]
    },

    practice: [
      {
    id: 'ch-02',
    title: 'Production Incident During Deployment',
    difficulty: 'Advanced',
    tags: ['Incidents', 'Risk', 'Decision-making'],
    projectContext: {
      project: 'Salesforce CRM Integration',
      status: 'Deployment Day',
      priority: 'Critical',
      team: 'DevOps Engineer, 2 Backend Devs, QA Lead'
    },
    context: 'Your team is 40% through deploying a Salesforce CRM integration when a P1 incident hits an unrelated production service. The on-call team requests your two senior engineers to help diagnose. Stopping the deployment requires a rollback.',
    question: 'What do you do?',
    skills: ['Incident Management', 'Risk Assessment', 'Technical Judgment'],
    competencies: { 'Risk Management': 10, 'Decision Making': 8, 'Technical Communication': 5 },
    options: [
      {
        text: 'Push the deployment through — stopping now is riskier than finishing.',
        correct: false,
        feedback: 'Continuing a deployment while engineers context-switch to a P1 incident compounds risk on both fronts. Focused attention on the highest severity issue is always safer.',
        mentorComment: 'Two parallel crises with split attention is one of the most dangerous situations in IT operations. Always address the highest severity issue first.'
      },
      {
        text: 'Pause the deployment, initiate rollback, redirect engineers to the incident, and reschedule.',
        correct: true,
        feedback: 'P1 incidents affect real users now. A clean rollback and rescheduled deployment is far better than two parallel failures. Communicate the new timeline immediately.',
        mentorComment: 'Good call. Knowing when to stop and regroup is a mark of a mature TPM. Communicate the decision within minutes — silence during a P1 is its own problem.'
      },
      {
        text: 'Let the on-call team handle the incident alone — your deployment takes priority.',
        correct: false,
        feedback: 'If your engineers have the expertise the on-call team needs, deprioritizing a P1 incident puts the business at greater risk than delaying a planned deployment.',
        mentorComment: 'P1s override planned work. The organizational expectation is that everyone who can help, helps. Defending your deployment schedule during a P1 will damage your credibility.'
      },
      {
        text: 'Split your engineers: one finishes the deployment, one joins the incident.',
        correct: false,
        feedback: 'Splitting attention across a deployment and a P1 incident means both get handled poorly. Neither task gets the focused expertise it needs.',
        mentorComment: 'Division of focus during high-stakes situations is a recipe for compounded failures. Pick the higher priority and commit fully.'
      }
    ]
  },
    {
    id: 'ch-05',
    title: 'Vendor API Deprecation',
    difficulty: 'Advanced',
    tags: ['Risk', 'Vendor Management', 'Communication'],
    projectContext: {
      project: 'Mobile Banking App',
      status: 'Live · Production',
      priority: 'Critical',
      team: 'CTO, Backend Lead, Mobile Team, Security'
    },
    context: 'Your mobile banking app\'s core transaction feature relies on a third-party payment vendor\'s API. The vendor just announced the API will be sunset in 90 days. This risk was on your register but marked as low-probability.',
    question: 'What is your first step?',
    skills: ['Risk Management', 'Crisis Communication', 'Vendor Management'],
    competencies: { 'Risk Management': 12, 'Stakeholder Communication': 7, 'Decision Making': 6 },
    options: [
      {
        text: 'Immediately start rewriting the integration to a new provider.',
        correct: false,
        feedback: 'Starting technical work without stakeholder alignment creates a shadow project. Scope, cost, and timeline must be understood and approved before any migration begins.',
        mentorComment: 'Moving fast feels productive but without alignment you\'re just adding chaos to a crisis. Communicate first, then execute.'
      },
      {
        text: 'Notify key stakeholders, assess business and technical impact, and initiate an emergency response plan.',
        correct: true,
        feedback: 'Notification and impact assessment come first. 90 days is tight for a core banking integration. Getting stakeholder alignment on a response plan quickly is what makes the difference.',
        mentorComment: 'Well handled. When a risk materializes, the TPM\'s first move is always: communicate, assess, plan. Speed matters — every day without a plan is a day lost.'
      },
      {
        text: 'Contact the vendor and request an API extension.',
        correct: false,
        feedback: 'Requesting an extension is worth trying, but it\'s not a plan and shouldn\'t be your only action. Internal alignment and contingency planning must happen in parallel, not after.',
        mentorComment: 'Good instinct, but insufficient as a sole response. Always pursue vendor negotiation in parallel with internal planning — never as a substitute for it.'
      },
      {
        text: 'Update the risk register to reflect the new probability and continue monitoring.',
        correct: false,
        feedback: 'The risk has materialized — it is now an active issue, not a risk. Risk register updates are appropriate but completely insufficient as a sole response.',
        mentorComment: 'This is a classic mistake. Once a risk becomes an issue, monitoring is over — response begins. The register update is the last thing you do, not the first.'
      }
    ]
  },
    {
    id: 'ch-07',
    title: 'Risk Register Decision',
    difficulty: 'Intermediate',
    tags: ['Risk', 'Prioritization', 'Planning'],
    projectContext: {
      project: 'Mobile Banking App — v3.0 Release',
      status: 'Sprint 4 of 8 · 4 weeks to go-live',
      priority: 'Critical',
      team: 'Product Owner, 3 Backend Devs, 1 Security Engineer, QA Lead'
    },
    context: 'Four risks are currently open in your register. You have bandwidth to actively work on only two this sprint. You need to decide which two deserve immediate attention: (1) A third-party KYC provider may go offline during peak hours — HIGH probability, HIGH impact on onboarding flow. (2) A junior developer is learning the new caching layer — LOW probability of delay, LOW impact (one non-critical feature). (3) New financial regulations may require changes to the transaction reporting module before go-live — MEDIUM probability, HIGH impact. (4) The QA environment has had minor intermittent latency — LOW probability of affecting testing, LOW impact.',
    question: 'Which two risks should you actively work on this sprint?',
    skills: ['Risk Management', 'Prioritization', 'Decision Making'],
    competencies: { 'Risk Management': 12, 'Decision Making': 10, 'Sprint Planning': 5 },
    options: [
      {
        text: 'Risk 1 (KYC provider) and Risk 2 (junior developer caching)',
        correct: false,
        feedback: 'Risk 1 is correct — High × High priority demands action. But Risk 2 is Low × Low: one non-critical feature with low delay probability. Spending sprint capacity here is a poor trade-off when Risk 3 (regulatory) is waiting.',
        mentorComment: 'Probability × Impact is your sorting algorithm. Don\'t let visible risks distract from impactful ones.'
      },
      {
        text: 'Risk 1 (KYC provider) and Risk 3 (regulatory changes)',
        correct: true,
        feedback: 'Correct. Risk 1 is High × High — critical, needs mitigation now. Risk 3 is Medium probability × High impact, with a hard regulatory deadline. Both have go-live implications. These are your top two priorities.',
        mentorComment: 'Regulatory risks are often underestimated. A Medium probability combined with High impact and a hard deadline makes this urgent — regardless of how "medium" sounds.'
      },
      {
        text: 'Risk 3 (regulatory) and Risk 4 (QA latency)',
        correct: false,
        feedback: 'Risk 3 is correct. But QA latency is Low × Low — it hasn\'t meaningfully affected testing. Meanwhile Risk 1 (KYC outages) is High × High and directly threatens your go-live. That\'s a significant miss.',
        mentorComment: 'Risk 4 feels visible because QA flags it. But visible doesn\'t mean high priority. Keep your P×I matrix as your guide, not your Slack notifications.'
      },
      {
        text: 'All four risks equally — risk management means treating every risk the same.',
        correct: false,
        feedback: 'This misunderstands risk management. Treating all risks equally guarantees you\'ll over-invest in low-value items and under-invest in critical ones. Prioritization is the core skill.',
        mentorComment: 'Risk management is not a checkbox exercise. Your job is to allocate limited attention to maximum effect. That requires explicit prioritization every sprint.'
      }
    ]
  },
    {
    id: 'ch-08',
    title: 'Risk Response Under Pressure',
    difficulty: 'Advanced',
    tags: ['Risk', 'Decision-making', 'Stakeholder Communication'],
    projectContext: {
      project: 'Cloud Migration — Legacy ERP to Azure',
      status: 'Week 6 of 12 · Testing Phase',
      priority: 'High',
      team: 'Cloud Architect, 4 Engineers, DBA, Enterprise Stakeholder'
    },
    context: 'During integration testing, your DBA discovers that the data migration script takes 6.5 hours to run on a production-size dataset. Your maintenance window is 4 hours. Go-live is in 6 weeks. The cloud architect says she can optimize the script, but needs 10 business days of focused work. The enterprise stakeholder is expecting the original go-live date and has already communicated it to their executive team.',
    question: 'What is your most effective response to this risk?',
    skills: ['Risk Management', 'Stakeholder Communication', 'Technical Communication'],
    competencies: { 'Risk Management': 10, 'Stakeholder Communication': 10, 'Technical Communication': 8 },
    options: [
      {
        text: 'Escalate immediately to the stakeholder and tell them the project is at risk of delay.',
        correct: false,
        feedback: 'Escalating without a solution — or even a set of options — puts the stakeholder in a difficult position and damages your credibility. You\'re the TPM. Come with a plan, not just a problem.',
        mentorComment: 'Never escalate a problem without at least one proposed solution. "Here\'s the problem" is a junior move. "Here\'s the problem and here are our options" is TPM.'
      },
      {
        text: 'Do nothing for now. The architect will probably find a solution faster than estimated.',
        correct: false,
        feedback: 'Hoping for a faster solution is not risk management — it\'s wishful thinking. With 6 weeks to go-live and a 10-day optimization task, this risk must be actively managed now.',
        mentorComment: 'Six weeks is not a lot of runway when you\'ve already identified a blocking issue. The sooner you act, the more options you have.'
      },
      {
        text: 'Give the architect 10 days to optimize, run parallel workstreams to minimize other delays, and prepare a stakeholder update with two scenarios: on-time (if optimization succeeds) and adjusted timeline (if it doesn\'t), with mitigation steps for each.',
        correct: true,
        feedback: 'This is the right approach. You\'re addressing the technical risk (optimization), protecting delivery momentum (parallel work), and managing stakeholder expectations proactively with options — not surprises.',
        mentorComment: 'Presenting two scenarios is a senior move. It shows you\'re in control, you\'ve thought it through, and you\'re giving the stakeholder agency — not dropping a bomb on them.'
      },
      {
        text: 'Request a longer maintenance window from the infrastructure team to accommodate the 6.5-hour script.',
        correct: false,
        feedback: 'This treats the symptom, not the risk. A 6.5-hour window may not be achievable — and even if it is, it doesn\'t address whether the migration will cause acceptable downtime for the business. Explore all options first.',
        mentorComment: 'Extending the window might be part of the solution, but it shouldn\'t be your only move. Always validate the business impact of extended downtime before proposing it.'
      }
    ]
  },
    {
    id: 'ch-09',
    title: 'Key Person Dependency',
    difficulty: 'Intermediate',
    tags: ['Risk', 'Team', 'Planning'],
    projectContext: {
      project: 'API Platform Redesign',
      status: 'Sprint 6 of 10 · Development Phase',
      priority: 'High',
      team: 'Tech Lead (sole architecture owner), 3 Backend Devs, Product Owner'
    },
    context: 'Your tech lead is the only person who fully understands the new API architecture. She is planning a 3-week vacation starting in two weeks. The team has not documented the architecture decisions, and two critical integration points have not yet been designed. Go-live is in 8 weeks.',
    question: 'How should you respond to this key-person dependency risk?',
    skills: ['Risk Management', 'Technical Communication', 'Leadership'],
    competencies: { 'Risk Management': 10, 'Leadership': 8, 'Technical Communication': 7 },
    options: [
      {
        text: 'Ask the tech lead to cancel her vacation to protect the project.',
        correct: false,
        feedback: 'Asking someone to cancel a planned vacation is a last resort, not a first response. It damages trust, morale, and your reputation as a leader — especially when better alternatives exist.',
        mentorComment: 'Great TPMs protect their team\'s personal time as a default. Sustainable delivery depends on trust, and trust is built in moments like these.'
      },
      {
        text: 'Accept the risk — you\'ll manage without the tech lead for 3 weeks.',
        correct: false,
        feedback: 'Accepting this risk without mitigation is reckless. You have two undesigned integration points and no documentation. Three weeks of blocked decisions mid-project will compound quickly.',
        mentorComment: 'Acceptance is a valid strategy for low-impact risks. For a single-point-of-failure with go-live in 8 weeks, it\'s not a strategy — it\'s avoidance.'
      },
      {
        text: 'In the next two weeks: schedule architecture documentation sessions with the full team, complete the two remaining integration designs, identify a backup decision-maker, and agree on an async escalation path for her vacation period.',
        correct: true,
        feedback: 'This is the right response. You\'re mitigating the risk through knowledge transfer, completing critical design decisions before she leaves, and ensuring continuity through a backup path — all without blocking her vacation.',
        mentorComment: 'This is what risk mitigation looks like in practice. You reduce both probability and impact by acting before the risk triggers — not after.'
      },
      {
        text: 'Hire a consultant to fill in while the tech lead is away.',
        correct: false,
        feedback: 'A consultant onboarding to an undocumented architecture in 3 weeks will consume more time than they save. This option ignores the root cause: no documentation and no knowledge transfer.',
        mentorComment: 'Adding people to a knowledge gap doesn\'t close it. Document first, then decide if external support is even needed.'
      }
    ]
  }
    ],

    interview: [
          {
      id: 'int-risk-01',
      packageId: 'PKG-RISK',
      question: 'How do you identify and manage risks in a fast-moving Agile environment?',
      difficulty: 'Intermediate',
      context: 'The interviewer wants a systematic approach that fits sprint cadence — not a heavyweight Waterfall-style risk process.',
      evaluatorFocus: 'A practical, embedded risk process adapted to Agile. Consistency, lightweight tooling, and evidence of real risk prevention.',
      star: {
        situation: 'While managing a cloud-native API platform build in sprints, I noticed the team was logging blockers but had no formal way to track risks before they became issues.',
        task: 'I needed to introduce lightweight risk management that fit our sprint cadence without adding bureaucratic overhead.',
        action: 'I implemented a simple risk register in our sprint board as a dedicated column. At each sprint planning session, we spent 10 minutes identifying new risks and reviewing open ones using a Probability x Impact assessment. I assigned an owner to every risk above a threshold and reviewed triggers weekly.',
        result: 'We caught a third-party API deprecation 6 weeks before it would have become a critical issue. The mitigation plan was already in place when the deprecation triggered, and we switched providers with zero downtime. The team adopted the process naturally because it was embedded in work they were already doing.',
        keyMessage: 'Risk management in Agile should be embedded in the sprint rhythm — not a separate process. Lightweight, consistent, and actionable is the formula that actually works.'
      }
    },
    {
      id: 'int-risk-02',
      packageId: 'PKG-RISK',
      question: 'Tell me about a time a risk you identified turned into an actual issue. How did you handle it?',
      difficulty: 'Advanced',
      context: 'The interviewer expects a real example — including what happened when it went wrong. TPMs who claim risks never trigger aren\'t credible.',
      evaluatorFocus: 'Structured incident response, evidence of prior contingency planning, honest communication under pressure, and composure when the plan activates.',
      star: {
        situation: 'During a mobile app release, we had a logged risk: our payment gateway had intermittent latency during high traffic. Probability: medium. Impact: high.',
        task: 'The risk triggered 2 hours before our launch window. Checkout latency spiked to 8 seconds, making the flow unusable.',
        action: 'We activated our contingency plan — which I had prepared two weeks earlier: a rollback to the previous payment flow, a stakeholder communication template, and a post-mortem schedule. I sent a stakeholder update within 15 minutes, postponed the launch by 4 hours, and worked with engineering to implement the circuit breaker pattern we had already designed as our mitigation.',
        result: 'We launched 4 hours late with zero customer impact. The circuit breaker has been in place ever since and has handled 3 similar latency events without triggering a launch delay.',
        keyMessage: 'A risk that triggers is only a crisis if you weren\'t ready for it. The contingency plan you write before the risk fires is what makes you look calm when everyone else is panicking.'
      }
    },
    {
      id: 'int-risk-03',
      packageId: 'PKG-RISK',
      question: 'How do you decide between Avoid, Mitigate, Transfer, and Accept as a risk response strategy?',
      difficulty: 'Intermediate',
      context: 'The interviewer wants a concrete decision framework with examples — not textbook definitions of the four strategies.',
      evaluatorFocus: 'Systematic strategy selection based on nature and leverage, not just probability-impact score. Ability to communicate trade-offs to non-technical stakeholders.',
      star: {
        situation: 'As a TPM on a SaaS platform migration, I regularly faced risks requiring different response strategies depending on their nature and my leverage over them.',
        task: 'I needed a consistent framework for choosing the right strategy without over- or under-reacting to each risk.',
        action: 'I use Probability x Impact as a starting point. For High x High risks, I evaluate whether I can eliminate the cause entirely (Avoid) if the cost of avoidance is proportionate. If not, I mitigate by reducing probability or impact. For financial or vendor-driven risks, I explore Transfer through SLAs or contract clauses. Accept is reserved for Low x Low risks with a documented contingency. I assign an owner and a trigger point regardless of which strategy is chosen.',
        result: 'This framework helped the team make consistent decisions and communicate risk posture clearly to leadership in quarterly reviews. We reduced high-priority open risks by 60% in one quarter through targeted mitigation and transfer actions.',
        keyMessage: 'The strategy should match the risk\'s nature and your leverage — not just its score. Avoid when proportionate. Mitigate when you have control. Transfer when you don\'t. Accept only when the impact is genuinely manageable.'
      }
    },
    {
      id: 'int-risk-04',
      packageId: 'PKG-RISK',
      question: 'How do you communicate risks to non-technical stakeholders without alarming them unnecessarily?',
      difficulty: 'Advanced',
      context: 'The interviewer is testing stakeholder management through the lens of risk. They want to see business-impact translation and solutions — not just technical storytelling.',
      evaluatorFocus: 'Business-impact translation, presenting problems with solutions, and maintaining stakeholder confidence while being fully transparent about risk severity.',
      star: {
        situation: 'We discovered a data migration risk two weeks before a major client go-live. The technical details were complex, but the business impact was simple: the go-live date might slip by up to 5 days.',
        task: 'I needed to inform the client\'s executive sponsor and our internal VP without creating alarm — and without hiding the severity.',
        action: 'I scheduled a 20-minute call and framed the conversation around impact and options: We\'ve identified a risk that could affect the go-live date — here are the two scenarios we\'re preparing for, and what each means for your team. I avoided technical jargon entirely. I presented the mitigation plan already in execution and gave them a decision point: maintain the original date with a contingency plan, or build in a buffer proactively.',
        result: 'The executive sponsor chose the proactive buffer. Go-live moved by 3 days. The client remained confident throughout — and extended the contract 6 months later.',
        keyMessage: 'Non-technical stakeholders don\'t need to understand the risk technically. They need to understand the impact on their business and the options they have. Lead with that. Always come with a plan, never just a problem.'
      }
    }
    ]
  },

  // ══════════════════════════════════════════════════════════════════════════
  // PACKAGE 4 — Stakeholder Communication
  // Competencies: Stakeholder Communication · Leadership · Negotiation
  // ══════════════════════════════════════════════════════════════════════════
  {
    id: 'PKG-STAKEHOLDER',
    name: 'Stakeholder Communication',
    icon: '🤝',
    level: 'Intermediate',
    description: 'Map, engage, and communicate effectively with every type of stakeholder.',
    competencies: { 'Stakeholder Communication': 12, 'Leadership': 8, 'Negotiation': 6 },

    learn: {
      id: 'T3',
      title: 'Stakeholder Communication', icon: '🤝',
      description: 'Build the influence and communication skills Technical PMs depend on.',
      level: 'Intermediate',
      experiences: [
        {
          id: 'T3-01',
          title: 'Who Are Your Stakeholders?',
          subtitle: 'Map your stakeholders before they map you.',
          duration: '16 min', xp: 100,
          competencies: { 'Stakeholder Communication': 12, 'Decision Making': 6, 'Leadership': 4 },
          phases: [
            {
              type: 'classify',
              label: 'Map the Grid',
              title: 'Place Each Stakeholder',
              instruction: 'Where does each stakeholder sit on the Power/Interest grid? Choose the quadrant that best fits.',
              mentorIntro: 'Before you can communicate effectively, you need to know who you\'re dealing with. The Power/Interest grid is the tool every TPM needs to internalize. Let\'s see how you read a room.',
              categories: [
                { id: 'hh', icon: '🔴', label: 'High Power · High Interest' },
                { id: 'hl', icon: '🟡', label: 'High Power · Low Interest' },
                { id: 'lh', icon: '🔵', label: 'Low Power · High Interest' },
                { id: 'll', icon: '⚪', label: 'Low Power · Low Interest' }
              ],
              items: [
                { text: 'The CTO approved the budget, will present outcomes to the board, and checks in on progress every week.', correct: 'hh', feedbackCorrect: 'Correct. High authority + high engagement = Manage Closely. This person needs regular, substantive updates and involvement in key decisions.', feedbackWrong: 'The CTO has budget authority (High Power) and is actively engaged in outcomes (High Interest). This is your Manage Closely stakeholder.' },
                { text: 'The CFO must approve any budget change above $50k but has no interest in sprint progress or daily decisions.', correct: 'hl', feedbackCorrect: 'Right. High Power but Low Interest — Keep Satisfied. Give them what they need when they need it, but don\'t burden them with operational detail.', feedbackWrong: 'Budget authority = High Power. No interest in daily operations = Low Interest. Keep Satisfied: meet their needs without drowning them in detail.' },
                { text: 'The QA Lead works on the project every day, is highly motivated, and flags every issue immediately — but has no authority over scope or budget.', correct: 'lh', feedbackCorrect: 'Correct. Low Power but High Interest — Keep Informed. This person is invested and engaged. Regular updates keep them aligned and motivated.', feedbackWrong: 'No budget or scope authority = Low Power. Daily involvement and high motivation = High Interest. Keep Informed — they deserve regular, detailed updates.' },
                { text: 'An external compliance auditor will review the system once per year. They have no role in delivery and no interest in how the team works.', correct: 'll', feedbackCorrect: 'Correct. Low Power and Low Interest — Monitor. Acknowledge them, share the minimum required, and don\'t invest heavy communication effort.', feedbackWrong: 'No decision authority = Low Power. Annual review with no delivery interest = Low Interest. Monitor — minimal engagement needed.' },
                { text: 'The Product Owner has full authority to accept or reject deliverables and participates in every sprint review and planning session.', correct: 'hh', feedbackCorrect: 'Right. This is your primary Manage Closely stakeholder. High delivery authority + deep daily engagement = needs your most active, consistent communication.', feedbackWrong: 'Acceptance authority = High Power. Sprint-level engagement = High Interest. Manage Closely — this person is central to your delivery success.' },
                { text: 'A marketing manager will be affected by the new platform but hasn\'t been included in requirements and doesn\'t attend project meetings.', correct: 'lh', feedbackCorrect: 'Correct — for now. Low Power but High Interest (they have a stake in the outcome). Keep Informed before they become resistant. Unengaged stakeholders who are affected by outcomes can surprise you late.', feedbackWrong: 'No delivery authority = Low Power. Affected by outcomes but not engaged = High Interest. Keep Informed — and consider bringing them in earlier to prevent late-stage resistance.' }
              ]
            },
            {
              type: 'reading',
              label: 'Stakeholder Mapping',
              mentorIntro: 'Now let\'s make sense of the grid and why it matters for every TPM conversation and decision.',
              sections: [
                { heading: 'The Power/Interest Grid', body: '<p>The grid divides stakeholders into four quadrants based on two dimensions:</p><ul><li><strong>Power</strong> — their authority to impact project decisions, budget, or scope</li><li><strong>Interest</strong> — how much the project affects them and how involved they want to be</li></ul><p>The four quadrants map to four engagement strategies:</p><ul><li><strong>High Power + High Interest</strong> → Manage Closely. Frequent contact, decision involvement, proactive updates.</li><li><strong>High Power + Low Interest</strong> → Keep Satisfied. Meet their needs on their terms. Don\'t overwhelm them.</li><li><strong>Low Power + High Interest</strong> → Keep Informed. Regular updates, no decision burden.</li><li><strong>Low Power + Low Interest</strong> → Monitor. Minimum viable engagement.</li></ul>', explainSimply: 'Think of it like a VIP list. High Power + High Interest people get your personal attention every week. High Power + Low Interest get a clean summary when they ask. Everyone else gets what they need, nothing more.' },
                { heading: 'The Stakeholder Register', body: '<p>A stakeholder register is the TPM\'s single source of truth for who matters and how to engage them. Each entry should capture:</p><ul><li><strong>Name and role</strong></li><li><strong>Power level</strong> — High / Medium / Low</li><li><strong>Interest level</strong> — High / Medium / Low</li><li><strong>Current engagement</strong> — Unaware, Resistant, Neutral, Supportive, or Leading</li><li><strong>Communication preference</strong> — email, Slack, weekly call, executive report</li><li><strong>Key concern or goal</strong> — what does this person actually care about?</li></ul><p>The register is a living document. Stakeholder positions shift throughout the project. Review it at every sprint review.</p>', explainSimply: 'A stakeholder register is a contact list with context. For each person: how much power do they have, how much do they care, and what do they actually want from this project? That context changes how you talk to them.' },
                { heading: 'Engagement Levels: Where Is Each Stakeholder Today?', body: '<p>Stakeholders exist on an engagement spectrum. Knowing where they are tells you what to do next:</p><ul><li><strong>Unaware</strong> — they don\'t know about the project yet. First step: introduce and inform.</li><li><strong>Resistant</strong> — they know about it and don\'t support it. Find their concern and address it directly.</li><li><strong>Neutral</strong> — they\'re aware but indifferent. Not a threat, but not an ally either.</li><li><strong>Supportive</strong> — they want the project to succeed. Maintain the relationship and leverage their support.</li><li><strong>Leading</strong> — they actively champion the project. Protect them and amplify their voice.</li></ul><p>Your goal is always to move stakeholders from Resistant or Neutral toward Supportive — without pushing them so hard they revert.</p>', explainSimply: 'Five stages: don\'t know, disagree, don\'t care, support, champion. Your job is to move people toward the right side of that list — especially the resistant ones, who are your biggest delivery risk.' }
              ]
            },
            {
              type: 'quiz',
              label: 'Apply the Grid',
              mentorIntro: 'Three real scenarios. Use the grid to guide your thinking.',
              questions: [
                { question: 'A VP of Engineering has veto power over the technical architecture but has been completely disengaged for 6 weeks. Which strategy should you apply?', options: [ { text: 'Monitor — they have shown no interest, so treat them as Low Interest.', correct: false, feedback: 'Their current behavior is Low Interest, but their power level hasn\'t changed. A VP with veto authority over architecture is not a Monitor stakeholder — their disengagement is itself a risk.' }, { text: 'Keep Satisfied — send them a monthly executive summary and don\'t push for more involvement.', correct: true, feedback: 'Closer, but not quite. Six weeks of silence from a high-power stakeholder is a warning sign. Passive updates are not enough — you need to understand why they\'ve disengaged.' }, { text: 'Manage Closely — schedule a direct conversation to re-engage and understand their current concerns before the next major decision.', correct: false, feedback: 'Correct. High Power always requires active management, regardless of current engagement level. Six weeks of silence is a signal — not permission to downgrade their priority. Re-engage before a key decision surfaces.' }, { text: 'Keep Informed — send weekly status emails until they respond.', correct: false, feedback: 'Email volume without a direct conversation won\'t re-engage a disengaged VP. You need a real exchange.' } ] },
                { question: 'A marketing manager was classified as Low Power / High Interest. Midway through the project, they are promoted to Head of Digital and given budget authority over the platform you\'re building. What should you do?', options: [ { text: 'Keep Informed — their interest level hasn\'t changed.', correct: false, feedback: 'Interest alone doesn\'t determine the strategy. Power has changed significantly — the stakeholder register must reflect the new reality.' }, { text: 'Monitor — they were already engaged so no additional effort is needed.', correct: false, feedback: 'Monitor is for Low Power / Low Interest. This stakeholder now has budget authority over your platform. That\'s a major shift.' }, { text: 'Manage Closely — update the stakeholder register and schedule a meeting to reset the communication plan.', correct: true, feedback: 'Correct. A promotion that adds budget authority moves a stakeholder from Low Power to High Power. The register must be updated immediately and the engagement strategy reset to Manage Closely.' }, { text: 'Keep Satisfied — they are now senior, so reduce operational communication and share executive summaries only.', correct: false, feedback: 'Their High Interest hasn\'t disappeared with the promotion. Dropping to Keep Satisfied ignores their continued operational engagement.' } ] },
                { question: 'You identify a stakeholder who is currently Resistant. They believe the new platform will make their team\'s workflow more complex. What is the right first step?', options: [ { text: 'Schedule a one-on-one to understand their specific concern and involve them in the solution design.', correct: true, feedback: 'Correct. Resistance usually has a specific root cause. Listening first — not persuading first — is the most effective way to move a resistant stakeholder toward neutral or supportive.' }, { text: 'Escalate to their manager and ask them to align the stakeholder with the project.', correct: false, feedback: 'Escalation before understanding the concern usually makes resistance worse. It signals that you\'re not listening — and it damages the relationship you need later.' }, { text: 'Send them detailed documentation explaining why the new platform is better than the current one.', correct: false, feedback: 'Documentation rarely converts a resistant stakeholder. People resist for emotional and political reasons, not informational ones. Listen before you explain.' }, { text: 'Exclude them from project updates to reduce friction until the platform is ready to launch.', correct: false, feedback: 'Excluding a resistant stakeholder guarantees they become a blocker at launch. Engage early, not late.' } ] }
              ]
            },
            {
              type: 'keyTakeaway',
              label: 'Key Takeaway',
              text: 'Stakeholder identification is not a one-time exercise. People gain or lose power. Engagement levels shift. The project changes what stakeholders care about. Review your stakeholder register every sprint — and act on what you find.',
              xp: 100,
              mentorNote: 'Your most dangerous stakeholder is not the loudest one. It\'s the one you forgot to map.'
            }
          ]
        },
        {
          id: 'T3-02',
          title: 'Communicating With Stakeholders',
          subtitle: 'The right message, to the right person, at the right time.',
          duration: '18 min', xp: 110,
          competencies: { 'Stakeholder Communication': 15, 'Leadership': 8, 'Negotiation': 6 },
          phases: [
            {
              type: 'classify',
              label: 'Pick the Right Move',
              title: 'What Would You Do?',
              instruction: 'Given each stakeholder situation, what is the most effective communication action?',
              mentorIntro: 'Knowing who your stakeholders are is only half the job. Knowing how to reach them — when something matters — is where TPMs win or lose trust. Let\'s test your judgment.',
              categories: [
                { id: 'direct', icon: '📞', label: 'Direct Outreach' },
                { id: 'update', icon: '📊', label: 'Structured Update' },
                { id: 'meeting', icon: '🤝', label: 'Dedicated Meeting' },
                { id: 'escalate', icon: '⬆️', label: 'Escalate' }
              ],
              items: [
                { text: 'A key decision-maker hasn\'t responded to your last 3 status emails. Their approval is needed by Friday or the sprint goal is at risk.', correct: 'direct', feedbackCorrect: 'Correct. Email silence from a critical stakeholder requires direct outreach — phone, Slack, or walking to their desk. Waiting for email response when Friday is close is not a communication strategy.', feedbackWrong: 'Three unanswered emails signals the channel isn\'t working. Direct outreach — a call, a Slack message, or an in-person conversation — is the right move when urgency is high and email has failed.' },
                { text: 'Your program governance committee meets monthly and expects a project status update at their next session in 10 days.', correct: 'update', feedbackCorrect: 'Right. A scheduled governance meeting is exactly the right context for a structured update — not an ad-hoc call. Prepare a clear status report: progress, risks, decisions needed.', feedbackWrong: 'Governance bodies expect structured, prepared updates at scheduled intervals. This is a Structured Update situation — not an escalation or a one-on-one conversation.' },
                { text: 'A senior stakeholder has been pushing scope changes informally in hallway conversations, and the team is starting to implement them without formal approval.', correct: 'meeting', feedbackCorrect: 'Correct. Informal scope changes need a dedicated meeting to surface, document, and formally address through your change control process. This can\'t be fixed with an email or a status update.', feedbackWrong: 'Informal scope creep requires a direct conversation — not a report. A dedicated meeting with the stakeholder (and ideally the Product Owner) puts the change on the table formally and stops the pattern.' },
                { text: 'A stakeholder is threatening to go around you to the CTO and demand a scope expansion that would derail the Q3 release commitment.', correct: 'escalate', feedbackCorrect: 'Correct. When a stakeholder is about to escalate unilaterally, your best move is to escalate proactively — brief your sponsor before they get blindsided. Control the narrative, don\'t react to it.', feedbackWrong: 'This situation is past the point of direct conversation or structured updates. When escalation is coming regardless, proactive escalation to your sponsor puts you in control of the narrative.' },
                { text: 'Your Product Owner asks for a quick sync to discuss two user stories that are technically more complex than estimated before sprint planning tomorrow.', correct: 'meeting', feedbackCorrect: 'Right. A focused technical discussion before a critical event (sprint planning) warrants a dedicated meeting — not a formal update or an escalation. Quick, purposeful, in context.', feedbackWrong: 'A pre-planning sync on technical complexity is a classic dedicated meeting scenario — short, focused, and directly connected to the next decision. Not a report, not an escalation.' }
              ]
            },
            {
              type: 'reading',
              label: 'Communication That Works',
              mentorIntro: 'Great instincts. Now let\'s give you the framework that makes every stakeholder conversation purposeful.',
              sections: [
                { heading: 'Match Your Message to Your Audience', body: '<p>Not every stakeholder needs the same information. Before any communication, ask two questions:</p><ol><li><strong>What does this person need to know?</strong> — Focus on impact, not process. Executives need decisions and outcomes. Technical leads need context and constraints.</li><li><strong>What do I need from them?</strong> — Are you informing, aligning, deciding, or escalating? Your purpose shapes your message.</li></ol><p>The most common TPM communication mistake is giving everyone the same update. A status report written for a QA Lead will confuse a CFO. A message written for a CFO will frustrate an engineering team. Tailor every time.</p>', explainSimply: 'Different audiences need different lenses. The CFO cares about budget and timeline. The tech lead cares about constraints and dependencies. The QA lead cares about testing windows. Write the same project update three different ways — or you\'re really writing it for no one.' },
                { heading: 'The Communication Plan', body: '<p>A communication plan answers four questions for every stakeholder group:</p><ul><li><strong>What</strong> — what information do they need? (status, risks, decisions, milestones)</li><li><strong>When</strong> — how often? (weekly, sprint review, on-demand)</li><li><strong>How</strong> — through which channel? (email, Slack, dashboard, meeting)</li><li><strong>Who</strong> — who owns the communication? (you, the sponsor, the Product Owner)</li></ul><p>A communication plan is not bureaucracy. It is a contract with your stakeholders about how you will keep them informed. When it exists and you follow it, stakeholders stop asking for ad-hoc updates because they already know when the next one is coming.</p>', explainSimply: 'A communication plan answers: who gets what, when, and how. The goal is to make your updates predictable — so stakeholders stop sending you \'quick status check\' emails every Monday morning.' },
                { heading: 'Navigating Difficult Conversations', body: '<p>Every TPM will eventually need to deliver bad news or push back on a powerful stakeholder. Three principles make these conversations more effective:</p><ul><li><strong>Lead with impact, not blame.</strong> "The release date is at risk" lands better than "the dev team is behind." Focus on the business effect and what you are doing about it.</li><li><strong>Come with options, not just problems.</strong> "Here is the situation, and here are the two paths forward" positions you as a problem-solver — not a messenger of bad news.</li><li><strong>Choose the right moment.</strong> Difficult conversations held publicly (in large meetings) trigger defensiveness. One-on-one first. Align privately before you align publicly.</li></ul>', explainSimply: 'Difficult conversations have three rules: say what happened without pointing fingers, bring at least one option for moving forward, and have the conversation privately first. Public bad news creates public defensiveness.' }
              ]
            },
            {
              type: 'quiz',
              label: 'Communication Decisions',
              mentorIntro: 'Three communication scenarios. Think about who you are talking to and what they actually need.',
              questions: [
                { question: 'You need to communicate a 2-week delay to your project sponsor. Which approach is most effective?', options: [ { text: 'Send a detailed email explaining all the technical root causes and the full analysis.', correct: false, feedback: 'Technical detail without a decision-ready summary overwhelms an executive sponsor. They need impact, options, and your recommendation — not a root cause analysis.' }, { text: 'Schedule a short call, lead with the business impact, present two recovery options, and ask for a decision.', correct: true, feedback: 'Correct. Sponsors need impact and options — not technical explanation. Leading with the business consequence and presenting a clear decision shows you are in control and have already thought through the path forward.' }, { text: 'Wait until you have a complete recovery plan before communicating anything.', correct: false, feedback: 'Waiting to communicate a known delay removes the sponsor\'s ability to make an informed decision early. The longer you wait, the fewer options they have.' }, { text: 'Inform the team first, then let them communicate the delay to the sponsor.', correct: false, feedback: 'The TPM owns stakeholder communication. Delegating bad news upward is not appropriate — and risks the sponsor hearing it secondhand, which damages trust more than the delay itself.' } ] },
                { question: 'A resistant stakeholder keeps raising objections in every steering committee meeting, creating friction and slowing decisions. What is the most effective approach?', options: [ { text: 'Prepare stronger arguments for the next meeting to counter their objections publicly.', correct: false, feedback: 'Public debate with a resistant stakeholder usually increases resistance. They become defensive in front of peers and dig in deeper. Winning the argument rarely wins the person.' }, { text: 'Escalate to the project sponsor and ask them to silence the stakeholder.', correct: false, feedback: 'Escalating a stakeholder conflict without trying to resolve it first signals weak leadership. Your sponsor will want to know you tried first.' }, { text: 'Remove them from the steering committee to reduce friction in meetings.', correct: false, feedback: 'Excluding a stakeholder from meetings doesn\'t remove their power or concern — it increases their resistance and removes your ability to monitor and address it.' }, { text: 'Meet with them privately before the next meeting to understand their concern and address it directly — then use their input to strengthen the proposal.', correct: true, feedback: 'Correct. Resistance in public meetings almost always has a private root cause. A one-on-one conversation surfaces the real concern, and incorporating their input converts a critic into a contributor.' } ] },
                { question: 'A technical team member tells you that a stakeholder is sending direct feature requests to the developers, bypassing the Product Owner and sprint planning. What should you do?', options: [ { text: 'Ask the development team to stop responding to the stakeholder directly.', correct: false, feedback: 'This addresses the symptom, not the cause. The stakeholder will find another channel — or escalate. You need to address the behavior directly with the stakeholder.' }, { text: 'Meet with the stakeholder directly, acknowledge their urgency, explain the impact of bypassing the process, and agree on how their requests will be handled through proper channels.', correct: true, feedback: 'Correct. The stakeholder is bypassing the process because they believe it is the fastest way to get results. Address that belief directly — acknowledge the urgency, offer a legitimate fast path (like a backlog addition process), and protect the team from ad-hoc disruption.' }, { text: 'Raise it in the next all-hands meeting as a reminder about the change control process.', correct: false, feedback: 'Public reminders rarely change behavior and can embarrass the stakeholder — increasing resistance. This needs a private, direct conversation.' }, { text: 'Log it as a risk and monitor whether the behavior continues before taking action.', correct: false, feedback: 'The behavior is already happening and already affecting the team. Monitoring without acting allows scope creep to accelerate and erodes team trust in the PM.' } ] }
              ]
            },
            {
              type: 'keyTakeaway',
              label: 'Key Takeaway',
              text: 'Effective stakeholder communication is not about sending more updates. It is about sending the right information to the right person through the right channel at the right moment. Your communication plan should make you predictable — and make stakeholders feel informed without needing to ask.',
              xp: 110,
              mentorNote: 'The best TPMs are never the ones who over-communicate. They are the ones whose stakeholders never have to wonder what is happening. That is the difference between noise and trust.'
            }
          ]
        }
      ]
    },

    practice: [
      {
    id: 'ch-10',
    title: 'Risk Communication to Stakeholders',
    difficulty: 'Advanced',
    tags: ['Risk', 'Stakeholder Communication', 'Leadership'],
    projectContext: {
      project: 'E-commerce Platform Launch',
      status: '3 weeks to launch',
      priority: 'Critical',
      team: 'Engineering Lead, QA Lead, Product Owner, Marketing Director (external stakeholder)'
    },
    context: 'QA has identified a performance issue: the checkout page takes 4.2 seconds to load under peak load simulation (your target is under 2 seconds). The engineering lead says the fix requires 8–12 days of optimization work. You have 21 days until launch. The marketing director has already kicked off a paid campaign and is expecting launch day to remain unchanged.',
    question: 'How do you communicate this risk to the marketing director?',
    skills: ['Stakeholder Communication', 'Risk Management', 'Leadership'],
    competencies: { 'Stakeholder Communication': 12, 'Risk Management': 8, 'Leadership': 7 },
    options: [
      {
        text: 'Don\'t tell the marketing director yet — wait to see if engineering can fix it within the original timeline.',
        correct: false,
        feedback: 'Withholding a known risk that affects a paid campaign and public launch date is a serious stakeholder management failure. If the risk triggers and you hadn\'t disclosed it, your credibility is gone.',
        mentorComment: 'Silence is not a risk strategy. Stakeholders need time to make informed decisions. The earlier you tell them, the more options they have.'
      },
      {
        text: 'Email all stakeholders with the full technical details of the performance bottleneck.',
        correct: false,
        feedback: 'Technical detail without context overwhelms non-technical stakeholders and creates panic. The marketing director needs business impact and options — not stack traces.',
        mentorComment: 'Match your communication to your audience. The marketing director needs to understand what this means for the launch date and the campaign — not how the database is indexed.'
      },
      {
        text: 'Schedule a call with the marketing director. Lead with impact: "We found a performance issue that may affect launch timing. Here are our two scenarios and what each means for the campaign." Present options, not a verdict.',
        correct: true,
        feedback: 'Correct. You\'re being transparent, timely, and business-focused. Presenting scenarios gives the stakeholder agency — and signals that you\'re in control of the situation.',
        mentorComment: 'Risk communication to non-technical stakeholders is about impact and options, not technical root causes. Lead with "here\'s what it means for you" and follow with "here\'s what we\'re doing about it."'
      },
      {
        text: 'Tell the engineering lead to work overtime to fix it and don\'t involve the stakeholder unless the fix fails.',
        correct: false,
        feedback: 'This puts the team under unsustainable pressure and keeps the stakeholder uninformed about a risk that directly affects their campaign investment. Both are leadership failures.',
        mentorComment: 'Protecting stakeholders from bad news by burning out your team is not leadership — it\'s avoidance with consequences. Transparency with options is always the right move.'
      }
    ]
  },
    {
    id: 'ch-11',
    title: 'Stakeholder Conflict on Scope',
    difficulty: 'Advanced',
    tags: ['Stakeholder Communication', 'Scope', 'Leadership'],
    projectContext: {
      project: 'Customer Data Platform — Phase 2',
      status: 'Sprint 5 of 9 · Requirements finalised',
      priority: 'High',
      team: 'VP Engineering (sponsor), Head of Marketing, Product Owner, 4 Devs'
    },
    context: 'The Head of Marketing wants to add a real-time campaign analytics dashboard to the current scope. The VP Engineering (your sponsor) wants to keep the scope locked and meet the Q3 deadline. Both are High Power / High Interest stakeholders and they disagree. They are now sending you conflicting instructions.',
    question: 'What is your most effective next move?',
    skills: ['Stakeholder Management', 'Conflict Resolution', 'Scope Control'],
    competencies: { 'Stakeholder Communication': 12, 'Negotiation': 8, 'Leadership': 7 },
    options: [
      { text: 'Side with the VP Engineering — they are the project sponsor and their decision outranks the Head of Marketing.', correct: false, feedback: 'Taking sides in a stakeholder conflict without facilitation damages the relationship with the losing party and leaves the root disagreement unresolved. Sponsors and key stakeholders need to reach alignment together.', mentorComment: 'Never position yourself as a judge between stakeholders. Your role is to facilitate alignment — not to pick winners.' },
      { text: 'Facilitate a joint conversation between both stakeholders, present the scope, schedule, and cost implications of the addition clearly, and let them make an informed decision together.', correct: true,  feedback: 'Correct. When two high-power stakeholders conflict, the TPM\'s job is to bring them to the same table with the same facts. Present the trade-offs clearly — scope addition vs. deadline risk — and let them own the decision.', mentorComment: 'This is one of the most valuable things a TPM does: turning a stakeholder conflict into a structured decision. The analysis you bring to that meeting is what makes you indispensable.' },
      { text: 'Add the dashboard to a future phase and inform both stakeholders of the decision by email.', correct: false, feedback: 'Deciding the outcome yourself and informing stakeholders by email is not facilitation — it\'s making a scope decision that isn\'t yours to make. High Power stakeholders need to be involved, not informed after the fact.', mentorComment: 'Unilateral scope decisions made by the TPM — even well-intentioned ones — erode stakeholder trust. Facilitation is the right tool here.' },
      { text: 'Escalate to the CEO to resolve the disagreement between the two senior leaders.', correct: false, feedback: 'Escalating a resolvable stakeholder conflict to the CEO without attempting facilitation first signals weak leadership. Exhaust direct facilitation before escalating upward.', mentorComment: 'Save executive escalation for decisions that genuinely cannot be resolved at the project level. This one can.' }
    ]
  },
    {
    id: 'ch-12',
    title: 'The Silent Stakeholder',
    difficulty: 'Intermediate',
    tags: ['Stakeholder Communication', 'Risk', 'Decision-making'],
    projectContext: {
      project: 'Internal HR Portal Redesign',
      status: 'Sprint 7 of 10 · UAT in 3 weeks',
      priority: 'Medium',
      team: 'HR Director (key approver), IT Lead, UX Designer, 2 Devs'
    },
    context: 'The HR Director is the key approver for UAT sign-off and final launch. For the last 4 weeks, they have attended zero sprint reviews, responded to zero emails, and delegated all project interactions to a junior analyst who has no decision-making authority. UAT is 3 weeks away.',
    question: 'How should you handle this?',
    skills: ['Stakeholder Engagement', 'Risk Management', 'Communication'],
    competencies: { 'Stakeholder Communication': 12, 'Risk Management': 7, 'Decision Making': 6 },
    options: [
      { text: 'Continue sending status emails to the HR Director and their analyst. Assume they are busy and will engage when ready.', correct: false, feedback: 'Continuing a channel that has produced zero response for 4 weeks is not a communication strategy. With UAT 3 weeks away, you cannot wait for engagement to happen organically.', mentorComment: 'Email silence is data. Four weeks of it from a key approver 3 weeks before UAT is a red flag — not a reason to wait longer.' },
      { text: 'Proceed with UAT planning without the HR Director and plan to get sign-off at the end.', correct: false, feedback: 'Running UAT without the approver\'s active participation is a major risk. Discovering misalignment at sign-off — after testing is complete — is far more costly than addressing the disengagement now.', mentorComment: 'Approver alignment before UAT is not optional. Finding out they disagree with the outcomes after 3 weeks of testing is a project-stopping event.' },
      { text: 'Request a direct meeting with the HR Director — bypassing the analyst — to understand why they have disengaged and what they need to reengage before UAT.', correct: true,  feedback: 'Correct. Disengagement from a key approver this close to UAT is a risk that needs direct action. A one-on-one conversation surfaces whether there is a concern, a conflict, or simply a capacity issue — and gives you a path to resolve it.', mentorComment: 'Silent stakeholders are not neutral stakeholders. They often have a concern they haven\'t felt safe raising. Your job is to make it safe to raise it — before it surfaces as a veto at sign-off.' },
      { text: 'Escalate immediately to the VP HR and ask them to mandate the HR Director\'s participation.', correct: false, feedback: 'Escalation before a direct conversation is premature and can create political friction. Try to resolve it directly first. If the direct conversation fails, then escalate — with evidence that you tried.', mentorComment: 'Escalation without evidence of direct effort makes you look reactive. One conversation first, then escalate if needed.' }
    ]
  },
    {
    id: 'ch-13',
    title: 'Delivering Bad News Upward',
    difficulty: 'Advanced',
    tags: ['Stakeholder Communication', 'Leadership', 'Escalation'],
    projectContext: {
      project: 'API Gateway Migration — Microservices Transition',
      status: '4 weeks before go-live',
      priority: 'Critical',
      team: 'VP Technology (executive sponsor), Engineering Lead, DevOps, Security Team'
    },
    context: 'Security testing has revealed a critical vulnerability in two microservices that are central to the go-live architecture. The security team estimates 10–14 days to remediate. Your go-live is in 4 weeks. The VP Technology has already communicated the go-live date to the board and to three enterprise clients.',
    question: 'How do you communicate this to the VP Technology?',
    skills: ['Executive Communication', 'Risk Communication', 'Leadership'],
    competencies: { 'Stakeholder Communication': 14, 'Leadership': 8, 'Risk Management': 6 },
    options: [
      { text: 'Send a written report with the full technical details of the vulnerability and let the VP decide next steps independently.', correct: false, feedback: 'A written technical report without a structured conversation puts the VP in an impossible position — they have to interpret a complex security issue alone, under board and client pressure. This is not communication; it is delegation of a problem you should be helping solve.', mentorComment: 'Never drop a critical problem on an executive in writing without a conversation. They need context, options, and your recommendation — not a document to decode alone.' },
      { text: 'Ask the engineering team to work overtime to fix the vulnerability and only inform the VP if the fix takes longer than expected.', correct: false, feedback: 'Hiding a known security risk from the executive sponsor while they continue to make external commitments is a serious leadership failure. The VP needs this information now — not after overtime fails.', mentorComment: 'Executive sponsors are responsible for commitments made at the board and client level. Keeping them uninformed about a risk that affects those commitments removes their ability to manage it. That is not protection — that is liability.' },
      { text: 'Request an urgent meeting with the VP. Lead with the business impact: the timeline is at risk. Present two options — a partial launch with a phased fix, or a full delay with remediation — and give your recommendation.', correct: true,  feedback: 'Correct. Urgent security findings require urgent, direct communication to the executive sponsor. Lead with impact (timeline risk), present options (partial launch vs. full delay), and give your professional recommendation. This is what executive-level TPM communication looks like.', mentorComment: 'This is one of the hardest conversations in a TPM career. The TPMs who handle it well are the ones who come with options and a recommendation — not just a problem. That is the difference between someone who reports and someone who leads.' },
      { text: 'Inform the three enterprise clients directly to manage their expectations before telling the VP.', correct: false, feedback: 'Communicating externally before aligning with your executive sponsor violates the communication hierarchy and puts client relationships at risk. The VP must be informed first.', mentorComment: 'Internal alignment always precedes external communication on sensitive issues. Go upward first, then outward together.' }
    ]
  },
    {
    id: 'ch-14',
    title: 'Managing Stakeholder Expectations at Scale',
    difficulty: 'Advanced',
    tags: ['Stakeholder Communication', 'Agile', 'Leadership'],
    projectContext: {
      project: 'SaaS Platform — Enterprise Feature Release',
      status: 'Sprint 3 of 6 · 3 enterprise clients waiting',
      priority: 'High',
      team: 'Enterprise Sales Lead, Product Owner, 3 client success managers, Dev team'
    },
    context: 'Three enterprise clients were promised specific features in the upcoming release. Midway through the sprint, the engineering team discovers that two of the promised features require significantly more work than estimated. Delivering all three features on time is no longer realistic. The Enterprise Sales Lead is telling you the client relationships depend on delivery as promised.',
    question: 'What is the most effective approach?',
    skills: ['Stakeholder Management', 'Communication Planning', 'Leadership'],
    competencies: { 'Stakeholder Communication': 14, 'Leadership': 7, 'Product Thinking': 6 },
    options: [
      { text: 'Commit to delivering all three features. Ask the team to work overtime to close the gap.', correct: false, feedback: 'Committing to a timeline the team has already identified as unrealistic leads to rushed work, technical debt, and missed deadlines anyway — but now with lower quality and a burned-out team. Overtime is a cost, not a solution.', mentorComment: 'Protecting a deadline by ignoring a team\'s honest assessment of feasibility is one of the most common and damaging mistakes a TPM can make. Reality always wins.' },
      { text: 'Meet with the Product Owner and Enterprise Sales Lead, surface the trade-off clearly — which two features can be delivered on time, which needs more time — and work together to build a communication plan for each client that reflects reality.', correct: true,  feedback: 'Correct. When delivery reality conflicts with external commitments, the answer is not to hide it — it is to align internally on the honest picture and communicate proactively to clients with options. Clients can handle delays. They cannot handle surprises at deadline.', mentorComment: 'Stakeholder trust is built on predictability and honesty — not on always hitting the original date. A client who hears about a risk early and gets a clear plan feels managed. A client who hears about a miss on delivery day feels abandoned.' },
      { text: 'Tell the Enterprise Sales Lead to manage the client expectations independently — that is their job, not the TPM\'s.', correct: false, feedback: 'The TPM owns the delivery timeline and is responsible for ensuring all stakeholders have accurate information. You cannot delegate bad news about delivery to a Sales lead and step back.', mentorComment: 'Delivery credibility is a shared responsibility — but the TPM is its anchor. Own the communication on delivery realities, even when it is uncomfortable.' },
      { text: 'Deliver the two simpler features on time and say nothing about the third until the next sprint review.', correct: false, feedback: 'Delivering partial scope without proactive communication creates the worst possible outcome: clients expecting three features receive two with no warning. That destroys trust far more than an early heads-up would.', mentorComment: 'Silence on a known miss is not neutral. It is a choice to let stakeholders be surprised — and surprise is the enemy of trust.' }
    ]
  }
    ],

    interview: [
          {
      id: 'int-stk-01',
      packageId: 'PKG-STAKEHOLDER',
      question: 'How do you handle conflicting priorities between two senior stakeholders?',
      difficulty: 'Intermediate',
      context: 'The interviewer is assessing political intelligence, facilitation skill, and whether you can surface trade-offs rather than pick sides.',
      evaluatorFocus: 'Surfacing trade-offs rather than making unilateral calls, facilitating alignment between powerful stakeholders without losing credibility with either.',
      star: {
        situation: 'During a SaaS platform rebuild, the VP of Product wanted to prioritize new feature development while the VP of Engineering wanted to address technical debt first. Both were my direct stakeholders with equal authority.',
        task: 'I needed to break the deadlock without choosing a side or allowing the conflict to delay two sprints of work.',
        action: 'I requested a joint session with both VPs and presented a clear analysis of the cost of each path: shipping new features on a fragile foundation vs. the revenue delay of a refactoring sprint. I framed it as a business decision, not a technical one. I also proposed a hybrid approach: one sprint focused on the highest-risk technical debt items while keeping one feature stream moving.',
        result: 'Both VPs aligned on the hybrid approach within 45 minutes. The sprint delivered two debt items and one feature. Feature velocity increased the following quarter because the foundation was stable.',
        keyMessage: 'When two senior stakeholders conflict, your job is not to decide — it is to give them the information they need to decide together. Bring the trade-offs, not your opinion.'
      }
    },
    {
      id: 'int-stk-02',
      packageId: 'PKG-STAKEHOLDER',
      question: 'Tell me about a time you had to manage a resistant stakeholder. What did you do?',
      difficulty: 'Advanced',
      context: 'The interviewer expects a structured account of how you moved someone from resistance to support. Resistance usually has a legitimate root cause.',
      evaluatorFocus: 'Empathy, persistence, and a process that addresses root cause — not just behavior management. Understanding that resistance usually has a legitimate source.',
      star: {
        situation: 'A Head of Operations was consistently resistant to a new incident management platform we were implementing. She raised objections in every steering committee and was influencing other stakeholders against the project.',
        task: 'I needed to move her from resistant to at least neutral — without escalating to her manager and damaging the relationship.',
        action: 'I requested a one-on-one outside the formal meeting structure and started by listening — not presenting. What I learned: her team had been burned by a similar implementation two years earlier that created more work for them, not less. Her resistance was legitimate. I invited her to co-design the onboarding process for her team and included one of her team leads in UAT. I made her team a visible success case in the rollout plan.',
        result: 'She became one of the project\'s strongest internal advocates. At go-live, she voluntarily recorded a short video endorsement. Her team had the fastest adoption rate in the organization.',
        keyMessage: 'Resistance is almost never irrational. Find the concern behind the behavior, address it directly, and involve the person in the solution. That\'s how you convert a critic into a champion.'
      }
    },
    {
      id: 'int-stk-03',
      packageId: 'PKG-STAKEHOLDER',
      question: 'How do you communicate project status to both technical and non-technical stakeholders effectively?',
      difficulty: 'Intermediate',
      context: 'The interviewer wants a concrete system — not a vague commitment to tailoring communication. One status report does not serve all audiences.',
      evaluatorFocus: 'Audience-calibrated communication design, systematic differentiation by stakeholder need, and efficiency — not creating 3 full-time communication streams.',
      star: {
        situation: 'On a cloud migration project, I was reporting to an engineering team that needed technical context, a CFO who cared only about budget and timeline, and a Head of Sales who needed to know when new capabilities would be available for clients.',
        task: 'I needed to keep all three audiences accurately informed without creating 3 separate full-time communication streams.',
        action: 'I built a tiered communication system: a technical weekly sync with engineering covering blockers, dependencies, and sprint progress; a bi-weekly one-page executive summary for the CFO covering budget burn, schedule status, and key decisions needed; and a monthly capabilities update for Sales listing which features were live, in progress, and upcoming. Each used the same underlying data, reframed for what each audience needed to act on.',
        result: 'The CFO stopped requesting ad-hoc updates because the bi-weekly summary answered questions in advance. The Sales team had enough confidence in the timeline to set client expectations accurately. Engineering felt their detail was respected, not filtered out.',
        keyMessage: 'Same project, three audiences, three communication formats. The source of truth is the same. What changes is the lens — and that lens is determined by what each audience needs to do with the information.'
      }
    },
    {
      id: 'int-stk-04',
      packageId: 'PKG-STAKEHOLDER',
      question: 'Tell me about a time you had to deliver bad news to a senior stakeholder. How did you approach it?',
      difficulty: 'Advanced',
      context: 'The interviewer is testing transparency under pressure and skill in managing executive relationships during difficult moments. They want evidence that you came prepared with options.',
      evaluatorFocus: 'Early and honest communication, structured option presentation, protecting the relationship after a difficult conversation, and never showing up with just a problem.',
      star: {
        situation: 'Three weeks before go-live of a payment processing integration, QA discovered a performance issue that would make the checkout flow unacceptably slow under peak load. The executive sponsor had already communicated the launch date to the board and two enterprise clients.',
        task: 'I needed to inform the sponsor immediately, preserve client trust, and present a viable path forward — all within 24 hours.',
        action: 'I requested an urgent meeting the same day. I led with business impact: the go-live date was at risk. Then explained the root cause in one sentence. I presented three options with my recommendation: partial launch excluding the payment flow; a 10-day delay with a client communication plan; or a crunch sprint attempting the fix before the original date. I drafted the client communication before the meeting so the sponsor could see exactly what they would receive.',
        result: 'The sponsor chose the 10-day delay. The client communication I drafted was used with minor edits. Both clients responded positively to the transparency. The project launched on the revised date with no further issues — and the sponsor told me the way I handled the conversation strengthened their confidence in the team.',
        keyMessage: 'Bad news delivered early with a recommendation and a plan is manageable. Bad news delivered at deadline with no options is a crisis. The difference is entirely in how the TPM chooses to act.'
      }
    }
    ]
  },

// ══════════════════════════════════════════════════════════════════════════
  // PACKAGE 5 — Project Planning & Estimation
  // Competencies: Estimation · Scope Management · Project Planning
  // ══════════════════════════════════════════════════════════════════════════
  {
    id: 'PKG-PLANNING',
    name: 'Project Planning & Estimation',
    icon: '📋',
    level: 'Intermediate',
    description: 'Turn ambiguous requirements into credible plans your team will actually commit to.',
    competencies: { 'Estimation': 12, 'Scope Management': 10, 'Project Planning': 10 },

    learn: {
      id: 'T5',
      title: 'Project Planning & Estimation',
      icon: '📋',
      description: 'Turn ambiguous requirements into credible plans your team will actually commit to.',
      level: 'Intermediate',
      experiences: [

        {
          id: 'T5-01',
          title: 'Work Breakdown Structure',
          objective: 'Decompose a project into manageable, estimable work packages.',
          duration: '8 min',
          status: 'available',
          competencies: { 'Scope Management': 10, 'Project Planning': 8 },
          phases: [
            {
              type: 'classify',
              label: 'Challenge',
              title: 'What Belongs in a WBS?',
              instruction: 'A WBS decomposes scope into work packages. Which of these items belong in a WBS for a mobile banking app launch?',
              mentorIntro: 'The WBS is one of the most misunderstood tools in PM. Let\'s test your instincts before the theory.',
              categories: [
                { id: 'yes', label: 'Belongs in WBS', icon: '✅' },
                { id: 'no',  label: 'Does NOT belong', icon: '❌' }
              ],
              items: [
                { text: 'Design and build the user authentication module, including login, biometrics, and password reset flows', correct: 'yes', feedbackCorrect: 'Yes. This is a deliverable with clear scope — it can be assigned, estimated, and tracked as a work package.', feedbackWrong: 'A WBS represents deliverables and outcomes, not activities. This is a concrete deliverable that can be owned and estimated.' },
                { text: 'Hold weekly status meetings with the engineering team every Monday at 10am', correct: 'no', feedbackCorrect: 'Correct. Meetings are project management activities, not deliverables. They belong in a communication plan or schedule, not the WBS.', feedbackWrong: 'WBS items represent deliverables and work packages, not recurring management activities. Meetings belong in the project schedule.' },
                { text: 'Integrate the payment processing API, including test coverage and error handling for declined transactions', correct: 'yes', feedbackCorrect: 'Right. This is a technical deliverable with a clear definition of done. It can be estimated, assigned to a team, and tested.', feedbackWrong: 'API integration with error handling is a concrete technical deliverable with a clear done state. It belongs in the WBS.' },
                { text: 'Motivate the team to stay focused and maintain high morale throughout the project', correct: 'no', feedbackCorrect: 'Correct. Motivation is a leadership activity, not a deliverable. It cannot be estimated or marked done. It stays out of the WBS.', feedbackWrong: 'A WBS contains work packages that can be estimated and completed. Motivation is a behavior, not a deliverable — it has no done state.' },
                { text: 'Conduct security penetration testing on all API endpoints before the production release', correct: 'yes', feedbackCorrect: 'Yes. Security testing is a defined deliverable with clear scope: test all endpoints, document findings, remediate, and sign off.', feedbackWrong: 'Penetration testing has a defined scope (all API endpoints), clear inputs and outputs, and can be estimated and completed. It belongs.' },
                { text: 'Make sure the backend team communicates clearly with the frontend team about API contracts', correct: 'no', feedbackCorrect: 'Correct. Coordination is a process, not a deliverable. It belongs in your communication plan — not in the WBS.', feedbackWrong: 'Communication between teams is an ongoing process, not a deliverable. WBS items need a definition of done. Coordination never ends.' }
              ]
            },
            {
              type: 'reading',
              label: 'Concepts',
              title: 'Work Breakdown Structure',
              mentorIntro: 'You\'ve just sorted real-world items. Now let\'s give you the framework behind the pattern.',
              sections: [
                { heading: 'What a WBS Is', body: 'A Work Breakdown Structure (WBS) is a hierarchical decomposition of a project\'s total scope into progressively smaller components called <em>work packages</em>. Each work package is small enough to be estimated, assigned, and tracked — typically 8 to 80 hours of effort.<br><br>The key rule: the WBS represents <strong>deliverables</strong>, not activities. It answers "what will we produce?" not "what will we do?" A well-built WBS makes scope visible, prevents gaps, and becomes the foundation for your schedule and budget.' },
                { heading: 'The 100% Rule', body: 'Every WBS must satisfy the 100% Rule: the sum of all child work packages must equal 100% of the parent scope — no more, no less. This rule exists to prevent scope gaps (missing work that gets discovered mid-project) and scope overlap (duplicated effort that inflates cost).<br><br>In practice: if you\'re building a mobile banking app and your WBS has Authentication, Payments, Notifications, and Analytics modules — but you forgot onboarding — that\'s a 100% Rule violation. The gap will appear as a surprise task later.' },
                { heading: 'WBS vs. Task List', body: 'New PMs often confuse the WBS with a task list or project schedule. The WBS captures <em>what</em> will be built. The schedule defines <em>when</em> and <em>in what sequence</em>. The task list defines <em>who does what actions</em>.<br><br>Build the WBS first. Use it to derive your schedule and task breakdown. Reversing this order leads to plans that miss scope because they\'re based on what the team thinks they\'ll do, not on what the project actually requires.' }
              ]
            },
            {
              type: 'quiz',
              label: 'Quiz',
              title: 'WBS Quick Check',
              mentorIntro: 'Three questions from real TPM interview conversations.',
              questions: [
                { question: 'A junior PM built a WBS for an API migration project. At the top level they have: "Plan", "Execute", and "Close". What is wrong with this structure?', options: [ { text: 'The WBS has too few levels — it needs at least five', correct: false, feedback: 'The number of levels is not the issue. The WBS can have as few levels as needed to reach estimable work packages.' }, { text: 'The WBS is organized by phases (activities) instead of deliverables — it violates the deliverables-based structure', correct: true, feedback: 'Correct. Plan, Execute, and Close are project phases — process steps. A WBS should be organized by deliverables: API inventory, migrated services, test suite, runbook, etc.' }, { text: 'The WBS should start with the project sponsor\'s name at the top level', correct: false, feedback: 'The top level of the WBS is the project name, not a person\'s name. The WBS represents scope, not responsibility.' }, { text: 'Three top-level items is too few — a minimum of five is required', correct: false, feedback: 'There is no minimum number of top-level items. The issue is that Plan, Execute, and Close are phases, not deliverables.' } ] },
                { question: 'A work package in the WBS is estimated at 200 hours for a two-person team. What is the BEST action?', options: [ { text: 'Accept it — complex deliverables can require 200 hours', correct: false, feedback: 'Work packages should be small enough to track progress. 200 hours creates a long period with no visible progress — a significant risk for planning and oversight.' }, { text: 'Decompose it into smaller work packages of 8 to 80 hours each', correct: true, feedback: 'Correct. The standard guidance is 8–80 hours per work package. 200 hours should be broken into smaller, trackable deliverables.' }, { text: 'Assign it to a larger team to reduce calendar duration', correct: false, feedback: 'Adding more people changes who does the work but doesn\'t make the work package more manageable. The issue is size, not staffing.' }, { text: 'Escalate to the project sponsor before proceeding', correct: false, feedback: 'This doesn\'t require escalation — it requires decomposition. The PM should break the work package into smaller components.' } ] },
                { question: 'Which statement BEST describes the purpose of the 100% Rule in WBS design?', options: [ { text: 'Every work package must be assigned to 100% of the team\'s capacity', correct: false, feedback: 'The 100% Rule refers to scope coverage, not team capacity. It ensures all scope is captured — nothing more and nothing less.' }, { text: 'The WBS must capture 100% of the project\'s scope with no gaps and no overlap between work packages', correct: true, feedback: 'Correct. The 100% Rule ensures completeness. Every work package rolls up to the parent, and every parent represents exactly the sum of its children — no gaps, no duplication.' }, { text: 'The project must be 100% complete before the WBS can be finalized', correct: false, feedback: 'The WBS is built during planning, not after completion. The 100% Rule is about scope coverage, not project status.' }, { text: '100% of the project team must approve the WBS before work begins', correct: false, feedback: 'Team approval of the WBS is good practice but not what the 100% Rule defines. The rule is specifically about scope completeness.' } ] }
              ]
            },
            {
              type: 'keyTakeaway',
              label: 'Takeaway',
              text: 'Build your WBS around deliverables, not activities. If you can\'t estimate it and declare it done, it doesn\'t belong in the WBS.',
              mentorNote: 'In interviews, TPMs who understand the WBS are immediately distinguishable from those who don\'t. It comes up in every planning, scope, and scheduling conversation.',
              xp: 25
            }
          ]
        },

        {
          id: 'T5-02',
          title: 'Estimation Techniques',
          objective: 'Select and apply the right estimation technique for each project context.',
          duration: '9 min',
          status: 'available',
          competencies: { 'Estimation': 12, 'Project Planning': 10 },
          phases: [
            {
              type: 'reading',
              label: 'Concepts',
              title: 'How to Estimate Without Lying',
              mentorIntro: 'Estimation is one of the most asked-about skills in TPM interviews. This is where you build a real answer to "how do you estimate projects?"',
              sections: [
                { heading: 'Why Estimation Is Hard', body: 'Estimation fails for two reasons: <strong>optimism bias</strong> (teams estimate the plan, not reality) and <strong>missing unknowns</strong> (scope that isn\'t visible at planning time). The goal of estimation is not to predict the future with precision — it\'s to create a credible range that enables decisions while accounting for uncertainty.<br><br>As a Technical PM, your job is to select the right technique for the project\'s maturity, gather input from the people doing the work, and communicate estimates with appropriate confidence intervals — not false precision.' },
                { heading: 'Four Core Techniques', body: '<strong>Analogous Estimation</strong> — Use a similar past project as the baseline. Fast, low-effort, useful when you have historical data. Best for early-stage estimates and executive conversations. Accuracy: ±25–50%.<br><br><strong>Parametric Estimation</strong> — Multiply a unit rate by quantity. Example: "API integration averages 3 days per endpoint × 12 endpoints = 36 days." Best when work is repetitive and unit rates are known. Accuracy: ±10–30%.<br><br><strong>Three-Point Estimation (PERT)</strong> — Capture Optimistic (O), Most Likely (M), and Pessimistic (P) estimates. Formula: (O + 4M + P) ÷ 6. Surfaces risk ranges. Best for uncertain or novel work.<br><br><strong>Planning Poker (Relative Sizing)</strong> — Team members estimate user stories as story points using Fibonacci numbers (1, 2, 3, 5, 8, 13). Drives discussion, surfaces disagreement, builds shared understanding. Best for Agile sprint planning.' },
                { heading: 'Estimation Conversations That Work', body: 'The worst estimation conversations start with "How long will this take?" under time pressure with a single answer expected. The best conversations start with: "What do we know? What do we not know? What would need to be true for this to take X weeks?"<br><br>Always separate effort (hours of work) from duration (calendar time). A feature that requires 40 hours of effort from one developer takes 5 days — but if that developer is 50% allocated, it takes 10 calendar days. Stakeholders think in calendar time. Engineers think in effort. Your job is to translate accurately between the two.' }
              ]
            },
            {
              type: 'quiz',
              label: 'Quiz',
              title: 'Estimation Reality Check',
              mentorIntro: 'These scenarios come from real sprint planning and executive briefing contexts.',
              questions: [
                { question: 'During discovery for a new product, the VP asks for a rough timeline. Your team hasn\'t done requirements yet. Which estimation technique is MOST appropriate?', options: [ { text: 'Planning poker — involve the team in the estimate', correct: false, feedback: 'Planning poker requires user stories and some scope clarity. Without requirements, there is nothing to estimate with story points yet.' }, { text: 'Parametric estimation — calculate based on unit rates', correct: false, feedback: 'Parametric estimation requires known quantities (how many APIs, screens, integrations). Without requirements, these quantities are unknown.' }, { text: 'Analogous estimation — use a similar past project as a baseline', correct: true, feedback: 'Correct. When scope is undefined, analogous estimation uses historical data from similar projects to create a rough order of magnitude (ROM) estimate — exactly what an early executive conversation needs.' }, { text: 'Refuse to estimate until requirements are complete', correct: false, feedback: 'Refusing to estimate creates a gap in business planning. A rough estimate with explicit caveats (±50%) is more useful than silence.' } ] },
                { question: 'A developer estimates a feature as: Optimistic 2 days, Most Likely 5 days, Pessimistic 14 days. What is the PERT estimate?', options: [ { text: '5 days (most likely always wins)', correct: false, feedback: 'PERT weights the most likely case but includes all three scenarios. The formula is (O + 4M + P) ÷ 6 = (2 + 20 + 14) ÷ 6 = 6 days.' }, { text: '7 days (average of all three)', correct: false, feedback: 'A simple average would be (2 + 5 + 14) ÷ 3 = 7. But PERT weights the most likely case 4× because it\'s typically more realistic. The answer is 6 days.' }, { text: '6 days', correct: true, feedback: 'Correct. PERT = (O + 4M + P) ÷ 6 = (2 + 4×5 + 14) ÷ 6 = (2 + 20 + 14) ÷ 6 = 36 ÷ 6 = 6 days.' }, { text: '14 days (always use pessimistic to be safe)', correct: false, feedback: 'Always using pessimistic produces chronically bloated estimates. PERT balances all three scenarios with appropriate weighting.' } ] },
                { question: 'A developer says: "This feature will take 3 days." The sprint ends in 4 days. Why might the PM be concerned even though there\'s buffer?', options: [ { text: 'The developer should always pad estimates by 50%', correct: false, feedback: 'Padding estimates without reason creates a culture of hidden buffer. The concern is about what "3 days" actually means.' }, { text: '"3 days" is likely an effort estimate, not a calendar duration — if the developer is 60% allocated to this sprint, 3 hours of effort takes 5 calendar days', correct: true, feedback: 'Correct. Effort ≠ duration. If the developer has meetings, code reviews, and other commitments, 3 days of effort spreads across more calendar days. Always clarify: "Is that 3 developer-days of effort or 3 calendar days?"' }, { text: 'Developers always underestimate by exactly 2×', correct: false, feedback: 'While underestimation is common, it\'s not a fixed multiplier. The real issue is the difference between effort and calendar duration.' }, { text: 'The PM should add a sprint buffer of 20% to all estimates', correct: false, feedback: 'Blanket buffers mask real risks without addressing them. The PM should first clarify effort vs. duration and allocation assumptions.' } ] }
              ]
            },
            {
              type: 'keyTakeaway',
              label: 'Takeaway',
              text: 'Pick the technique that fits the moment. Communicate estimates as ranges, not promises. Always separate effort from calendar duration.',
              mentorNote: 'Every hiring manager has been burned by a PM who gave false precision. Showing you understand estimation ranges and uncertainty will set you apart in interviews.',
              xp: 25
            }
          ]
        }
      ]
    },

    practice: {
      challenges: [
        {
          id: 'pc-plan-01',
          prompt: 'Your team is starting a 6-month platform migration project. An executive asks for an estimate. Requirements gathering hasn\'t started yet. What do you do?',
          choices: [
            { text: 'Say you cannot estimate without requirements and wait until discovery is complete.' },
            { text: 'Provide a rough order of magnitude estimate based on similar past migrations, label it as ±40%, and commit to refining it after discovery.' },
            { text: 'Estimate 6 months based on the timeline the executive mentioned in the kickoff.' },
            { text: 'Use planning poker with the team to estimate the migration immediately.' }
          ],
          correctIndex: 1,
          explanation: 'Early-stage estimates are expected and valuable for business planning. An analogous estimate (based on historical data) with an explicit uncertainty range (±40%) gives the executive a planning baseline while making the current limitations clear. Refusing to estimate or copying the executive\'s number both fail the team.',
          competency: 'Estimation',
          difficulty: 'medium'
        },
        {
          id: 'pc-plan-02',
          prompt: 'During sprint planning, the team selects stories totaling 42 story points. Their 3-sprint average velocity is 30 points. What should you do?',
          choices: [
            { text: 'Accept the commitment — the team is motivated to stretch.' },
            { text: 'Ask the team to remove stories until the commitment aligns with their proven velocity of 30 points.' },
            { text: 'Split the difference and agree on 36 points.' },
            { text: 'Add more developers to the sprint to match the 42-point commitment.' }
          ],
          correctIndex: 1,
          explanation: 'Velocity is the team\'s proven delivery rate. Committing 40% above velocity (42 vs. 30) is a planning failure waiting to happen — it creates deadline pressure, compromises quality, and erodes trust in the sprint process. The right move is to align commitment with sustainable pace. Motivation is not a substitute for capacity.',
          competency: 'Sprint Planning',
          difficulty: 'medium'
        },
        {
          id: 'pc-plan-03',
          prompt: 'A developer gives a 3-point story a "13" during planning poker. Every other developer estimated "3". What is the correct facilitation move?',
          choices: [
            { text: 'Average all estimates and use 4 as the final point value.' },
            { text: 'Override the outlier and use 3 — the majority is right.' },
            { text: 'Ask the developer who estimated 13 to share what risk or complexity they see that others may have missed.' },
            { text: 'Remove the story from the sprint and add it to the backlog for more refinement.' }
          ],
          correctIndex: 2,
          explanation: 'Outlier estimates in planning poker are signals, not noise. The outlier developer likely sees a complexity, dependency, or risk that others missed. Asking them to explain surfaces hidden knowledge and leads to better estimates — and occasionally reveals a story that genuinely needs more refinement before it\'s sprint-ready.',
          competency: 'Estimation',
          difficulty: 'medium'
        },
        {
          id: 'pc-plan-04',
          prompt: 'A stakeholder requests adding a new "small" feature mid-sprint. The dev team says it\'s 2 days of work. There are 3 days left in the sprint. What do you do?',
          choices: [
            { text: 'Add the feature — there are 3 days left and it only takes 2 days.' },
            { text: 'Decline the request — no changes during a sprint, without exception.' },
            { text: 'Discuss with the team: either drop a lower-priority story to make room, or defer the request to next sprint. Protect the current sprint goal.' },
            { text: 'Ask the team to work overtime to fit both the original stories and the new feature.' }
          ],
          correctIndex: 2,
          explanation: 'Mid-sprint scope additions are common but must be managed intentionally. The correct response is to make the tradeoff visible: adding new work means removing existing work unless capacity genuinely exists. Working overtime without tradeoff discussion creates burnout and sets a harmful precedent. The sprint goal must be protected.',
          competency: 'Scope Management',
          difficulty: 'hard'
        },
        {
          id: 'pc-plan-05',
          prompt: 'Your project WBS has 8 top-level deliverables. After two sprints, the team discovers that API error handling — not captured in the WBS — will take 3 weeks. What happened and what do you do next?',
          choices: [
            { text: 'The WBS violated the 100% Rule. Immediately add the missing scope, update the schedule and budget baseline, and communicate the impact to stakeholders.' },
            { text: 'This is normal — all projects have surprises. Absorb the 3 weeks into the existing buffer.' },
            { text: 'The developer is overestimating. Challenge the estimate before updating any baseline.' },
            { text: 'Remove a lower-priority deliverable from the WBS to offset the new scope.' }
          ],
          correctIndex: 0,
          explanation: 'A missing work package is a WBS failure — the 100% Rule was violated during planning. The PM\'s job now is to be transparent: add the scope formally, update the schedule baseline, quantify the cost and timeline impact, and communicate this to stakeholders with a root cause explanation. Absorbing it silently erodes trust when the impact surfaces later.',
          competency: 'Scope Management',
          difficulty: 'hard'
        }
      ]
    },

    interview: {
      questions: [
        {
          id: 'iq-plan-01',
          question: 'Tell me about a time you had to create a project plan with significant uncertainty. How did you handle the estimation?',
          difficulty: 'medium',
          competency: 'Estimation',
          star: {
            situation: 'We were asked to estimate a full data platform migration from a legacy on-premise database to a cloud-based data warehouse. Requirements were still being gathered, and the engineering team had no prior experience with the target technology.',
            task: 'I needed to provide the executive team with a credible planning estimate within one week — without a complete picture of scope — so they could make a budget decision.',
            action: 'I used a combination of analogous and three-point estimation. I found two similar past migrations in our project archive and used them as baselines. For each major component (extraction, transformation, loading, validation, cutover), I asked the engineers for optimistic, most likely, and pessimistic estimates using PERT. I labeled the resulting estimate as a Rough Order of Magnitude (±35%) and included a risk section explaining the four largest unknowns that could push the pessimistic scenario.',
            result: 'The executive team approved a budget range rather than a fixed number, which gave the team planning flexibility. When the actual scope was refined two weeks later, the final estimate landed within 20% of the ROM — well within the stated range. The upfront transparency about uncertainty actually increased the team\'s credibility with leadership.',
            keyMessage: 'Estimation under uncertainty requires selecting the right technique, involving the people doing the work, and communicating ranges — not false precision. Executives who understand the caveats become partners, not critics, when reality diverges from the plan.'
          },
          tips: [
            'Always state the estimation technique you used — it shows PM rigor.',
            'The ROM range (±35%) and the explanation of unknowns are what interviewers are looking for — specificity matters.',
            'The outcome that earned the most points: the executive approved a range, not a fixed number. That\'s a great stakeholder management win inside an estimation story.'
          ]
        },
        {
          id: 'iq-plan-02',
          question: 'Describe a situation where a project scope changed significantly. How did you manage it?',
          difficulty: 'medium',
          competency: 'Scope Management',
          star: {
            situation: 'Three sprints into a six-month SaaS integration project, the Product Owner received feedback from a major enterprise client requesting a real-time sync feature that was not in the original scope. The client represented 30% of projected ARR.',
            task: 'I had to evaluate the scope change impact, make a recommendation to leadership, and manage the team\'s expectation without creating chaos in the current sprint.',
            action: 'I ran a formal change impact analysis: I estimated the feature at 6 weeks of engineering effort, identified which existing backlog items would need to shift, and calculated the effect on the launch date. I presented two options to the steering committee — add the feature and move launch by 5 weeks, or deliver on time without the feature and add it in the next release. I also modeled a third option: descope two lower-priority features and absorb the new request with a 2-week delay. I recommended option three and documented the tradeoffs clearly.',
            result: 'The steering committee chose option three. We delivered with a 12-day delay instead of 5 weeks. The client was satisfied. The team appreciated that I didn\'t just absorb the change silently — I made the tradeoffs visible and got leadership to own the decision.',
            keyMessage: 'Scope changes are not problems — they are decisions. A Technical PM\'s job is to quantify the impact clearly, present options with tradeoffs, and make sure the right people own the decision. Never absorb scope changes silently.'
          },
          tips: [
            'The three-option framing (add feature, don\'t add it, hybrid) is a strong PM move that interviewers notice.',
            'The phrase "make the tradeoffs visible and get leadership to own the decision" is a great line — it shows PM maturity.',
            'Always include what happened to the team\'s capacity. Scope discussions need to connect to delivery.'
          ]
        },
        {
          id: 'iq-plan-03',
          question: 'How do you build a project plan when requirements are not fully defined?',
          difficulty: 'hard',
          competency: 'Project Planning',
          star: {
            situation: 'This comes up constantly in software projects, especially in early-stage product work. Requirements are rarely complete at kickoff. The question is how to plan in a way that enables progress without creating a false sense of certainty.',
            task: 'My approach is to structure the plan in two horizons: a near-term plan with high confidence, and a far-term plan with explicit assumptions.',
            action: 'For the near term — typically the first 4 to 6 weeks — I plan in detail: defined stories, assigned owners, clear acceptance criteria. For the far term, I use rolling wave planning: I define milestones and known decision points rather than individual tasks. I document the assumptions behind the far-term plan explicitly — if any of those assumptions change, the plan changes and we revisit together. I also build in a dedicated discovery or spike sprint early to surface the unknowns that most impact planning.',
            result: 'This approach has worked well in multiple projects. Stakeholders get a credible near-term roadmap without false precision on the far term. Engineers know what they\'re building for the next sprint. And when scope changes, I can show exactly which assumption shifted — which keeps the conversation factual rather than emotional.',
            keyMessage: 'Rolling wave planning is the professional\'s answer to incomplete requirements. Plan with precision where you have knowledge, and with explicit assumptions where you don\'t. The assumptions make the unknowns manageable.'
          },
          tips: [
            'Rolling wave planning is a PMP-recognized term — using it shows technical PM vocabulary.',
            '"Discovery sprint" or "spike sprint" demonstrates Agile fluency.',
            'The key message about explicit assumptions is what separates junior from senior PM thinking.'
          ]
        }
      ]
    }
  },


  // ══════════════════════════════════════════════════════════════════════════
  // PACKAGE 6 — Sprint Planning & Delivery
  // Competencies: Sprint Planning · Delivery Management · Prioritization
  // ══════════════════════════════════════════════════════════════════════════
  {
    id: 'PKG-SPRINT',
    name: 'Sprint Planning & Delivery',
    icon: '⚡',
    level: 'Intermediate',
    description: 'Run sprints that deliver, not just sprints that end.',
    competencies: { 'Sprint Planning': 12, 'Delivery Management': 10, 'Prioritization': 8 },

    learn: {
      id: 'T6',
      title: 'Sprint Planning & Delivery',
      icon: '⚡',
      description: 'Run sprints that deliver, not just sprints that end.',
      level: 'Intermediate',
      experiences: [

        {
          id: 'T6-01',
          title: 'Running Sprint Planning',
          objective: 'Facilitate a sprint planning meeting that produces a credible commitment.',
          duration: '8 min',
          status: 'available',
          competencies: { 'Sprint Planning': 12, 'Delivery Management': 8 },
          phases: [
            {
              type: 'reading',
              label: 'Concepts',
              title: 'Sprint Planning That Actually Works',
              mentorIntro: 'Sprint planning is the most commonly run — and most commonly misrun — meeting in software teams. Let\'s fix that.',
              sections: [
                { heading: 'What Sprint Planning Is For', body: 'Sprint planning has one output: a sprint goal and a set of stories the team <em>genuinely believes</em> they can complete. The keyword is genuinely. A plan that the team doesn\'t believe in isn\'t a plan — it\'s a list of future problems.<br><br>Sprint planning answers two questions: <strong>What will we deliver?</strong> (the sprint goal) and <strong>How will we deliver it?</strong> (the work breakdown and assignments). Both questions need answers before the meeting ends.' },
                { heading: 'Capacity vs. Velocity', body: 'Before the team can commit to a sprint, you need two numbers: <strong>capacity</strong> (how many hours or story points are available this sprint) and <strong>velocity</strong> (how many story points the team has historically completed per sprint).<br><br>Capacity accounts for individual availability: vacations, company holidays, team events, and known meetings. A two-week sprint with a team of 5 developers is not 10 developer-weeks if two people are out for 3 days each.<br><br>Velocity is the team\'s historical rate over the last 3–5 sprints, excluding outliers. It\'s not a target — it\'s a reality check. Committing significantly above velocity without a clear reason is wishful planning.' },
                { heading: 'The Sprint Goal', body: 'The sprint goal is the one sentence that answers: "If we complete everything we committed to, what will be true that wasn\'t true before?" It should be outcome-oriented, not task-oriented.<br><br><em>Bad sprint goal:</em> "Complete stories USER-12, USER-13, API-07, and DB-04."<br><em>Good sprint goal:</em> "Users can create an account and log in for the first time."<br><br>The sprint goal matters when things go wrong mid-sprint. If a dependency blocks API-07, knowing the sprint goal helps the team decide whether to pull in a substitute story or flag the risk — because the question becomes "can we still achieve the goal?"' }
              ]
            },
            {
              type: 'quiz',
              label: 'Quiz',
              title: 'Sprint Planning Check',
              mentorIntro: 'These questions are based on common sprint planning failure patterns.',
              questions: [
                { question: 'It\'s Monday morning. The team has a 2-week sprint starting today. One developer is on vacation for 3 days, and there\'s a company all-hands on Thursday. How should the TPM adjust capacity?', options: [ { text: 'Do not adjust capacity — developers can make up the time.', correct: false, feedback: 'Unaccounted absences are one of the most common sprint planning failures. The capacity calculation must reflect actual availability.' }, { text: 'Subtract the vacation days and the all-hands from the available capacity before selecting stories.', correct: true, feedback: 'Correct. Capacity = total available days minus all known absences. Both the vacation (3 days) and the all-hands (half a day per person) reduce real capacity.' }, { text: 'Add 20% buffer to the sprint timeline instead of calculating individual capacity.', correct: false, feedback: 'Blanket buffers are imprecise. Actual capacity calculation — accounting for real absences — is more accurate and builds more credible commitments.' }, { text: 'Ask the vacationing developer to complete their work before the sprint starts.', correct: false, feedback: 'Pre-loading work before sprints creates untracked effort and burnout. The right move is to reflect the absence in capacity planning.' } ] },
                { question: 'The team\'s sprint goal is "Complete API development and fix the login bug." What is wrong with this sprint goal?', options: [ { text: 'Nothing — sprint goals should list the key deliverables.', correct: false, feedback: 'Listing deliverables is a task list, not a sprint goal. A good sprint goal describes the outcome or user value being created.' }, { text: 'The goal is task-oriented, not outcome-oriented. It describes what the team will do, not what value will be created.', correct: true, feedback: 'Correct. A strong sprint goal describes the user or business outcome: "Developers can authenticate securely via the new API." That\'s testable and meaningful when mid-sprint decisions need to be made.' }, { text: 'Sprint goals should only have one deliverable, not two.', correct: false, feedback: 'The number of deliverables is less important than whether the goal describes an outcome. Two deliverables can coexist in a single coherent sprint goal if they serve the same outcome.' }, { text: 'The sprint goal is too short — it should be at least three sentences.', correct: false, feedback: 'Sprint goals should be concise — one or two sentences. Length is not the problem here; outcome-orientation is.' } ] },
                { question: 'Halfway through the sprint, a developer says the most critical story will not be done in time. What should the TPM do first?', options: [ { text: 'Extend the sprint by 3 days to give the developer more time.', correct: false, feedback: 'Extending sprints undermines the rhythm and predictability of Agile delivery. The right move is to assess impact and make a decision within the sprint.' }, { text: 'Immediately escalate to the Product Owner and re-plan the entire sprint.', correct: false, feedback: 'Full sprint re-planning mid-sprint creates more disruption than it solves. Assess the impact first, then decide on the smallest intervention needed.' }, { text: 'Understand the blocker, assess whether the sprint goal is still achievable, and decide with the team whether to re-scope or flag the risk to stakeholders.', correct: true, feedback: 'Correct. The sprint goal is the anchor. If the goal is still achievable without this story, adjust and continue. If not, communicate transparently — stakeholders prefer early warning over late surprises.' }, { text: 'Ask another developer to pick up the story and work in parallel.', correct: false, feedback: 'Randomly assigning stories mid-sprint can create handoff costs and duplication. Understand the blocker first — it may be a knowledge or dependency issue that the original developer must resolve.' } ] }
              ]
            },
            {
              type: 'keyTakeaway',
              label: 'Takeaway',
              text: 'A sprint commitment means the team believes it. Capacity is calculated, not assumed. The sprint goal is the compass when things go sideways.',
              mentorNote: 'Interviewers ask sprint planning questions to see if you protect the team from overcommitment while keeping delivery moving. Show both sides.',
              xp: 25
            }
          ]
        },

        {
          id: 'T6-02',
          title: 'Delivery Management',
          objective: 'Keep delivery on track, communicate status clearly, and manage blockers before they become crises.',
          duration: '9 min',
          status: 'available',
          competencies: { 'Delivery Management': 12, 'Prioritization': 10 },
          phases: [
            {
              type: 'classify',
              label: 'Challenge',
              title: 'Blocker or Background Noise?',
              instruction: 'Not every problem is a blocker. A TPM who escalates everything loses credibility fast. Which of these situations require immediate escalation?',
              mentorIntro: 'One of the most valuable TPM skills is knowing what to escalate and when. Let\'s calibrate your judgment.',
              categories: [
                { id: 'escalate', label: 'Escalate Now',    icon: '🚨' },
                { id: 'manage',   label: 'Manage Locally',  icon: '🔧' }
              ],
              items: [
                { text: 'A third-party payment API is returning errors for 15% of transactions in the staging environment — the launch is in 4 days', correct: 'escalate', feedbackCorrect: 'Escalate immediately. A 15% error rate 4 days before launch is a go/no-go risk. Engineering, Product, and the release owner all need to know now.', feedbackWrong: 'A 15% error rate on a payment API 4 days before launch is a showstopper risk. This must be escalated immediately — engineering and the release owner need to act now.' },
                { text: 'A developer is having trouble with a linting configuration and has spent 2 hours trying to fix it', correct: 'manage', feedbackCorrect: 'Right call. 2 hours on a dev environment issue doesn\'t need escalation — pair the developer with a senior engineer or DevOps and resolve it locally.', feedbackWrong: 'Linting configuration issues are solvable locally. Pair the developer with a senior engineer. Escalation would be premature — and would waste leadership attention on a minor technical issue.' },
                { text: 'The Product Owner has been unavailable for 5 days and cannot answer story acceptance criteria questions, blocking 3 stories from being merged', correct: 'escalate', feedbackCorrect: 'Yes. 5 days of unavailability blocking 3 stories is a delivery risk that needs stakeholder intervention. The TPM cannot resolve a Product Owner availability issue alone.', feedbackWrong: 'A blocked PO for 5 days affecting 3 stories is a genuine delivery blocker. This requires escalation to whoever owns the PO\'s priorities — it can\'t be resolved without that authority.' },
                { text: 'A QA engineer found 4 low-severity UI inconsistencies (wrong button color, spacing issue) during regression testing', correct: 'manage', feedbackCorrect: 'Correct. Low-severity cosmetic issues are the QA team\'s domain. Log them, triage with the team, and manage them as part of normal sprint work.', feedbackWrong: 'Low-severity cosmetic bugs are normal QA findings. They belong in the bug tracker and sprint backlog — escalation would create noise and undermine your credibility for real escalations.' },
                { text: 'The cloud infrastructure team says the production environment won\'t be ready until 2 weeks after your planned go-live date', correct: 'escalate', feedbackCorrect: 'Escalate. A 2-week infrastructure delay directly affects the launch date — this requires leadership involvement and a decision about options (delay launch, use alternative environment, negotiate earlier delivery).', feedbackWrong: 'A 2-week delay from a dependency team is a launch risk that requires leadership decision-making. The TPM cannot resolve an infrastructure team\'s priorities alone.' }
              ]
            },
            {
              type: 'reading',
              label: 'Concepts',
              title: 'Managing Delivery in Practice',
              mentorIntro: 'You\'ve just practiced the escalation judgment. Now let\'s build the full delivery management picture.',
              sections: [
                { heading: 'The Three Delivery Risks', body: 'Every software delivery faces three recurring risk categories: <strong>scope creep</strong> (more work than planned), <strong>dependency failures</strong> (another team or system doesn\'t deliver on time), and <strong>technical debt emergencies</strong> (legacy system instability that forces unplanned rework).<br><br>A TPM\'s delivery management practice is essentially a system for detecting these three risks early enough to act. Daily standups, burndown charts, and dependency tracking boards all serve this purpose.' },
                { heading: 'Burndown as a Signal', body: 'A sprint burndown chart shows remaining work (story points) over time. Ideal burndown is a straight diagonal line from the total commitment to zero by the last day.<br><br>In practice, three patterns signal risk: a <em>flat line</em> (no progress — likely a blocker), a <em>step function</em> (progress happening in bursts, not continuously — suggests integration delays or handoff bottlenecks), and a <em>burndown that never reaches zero</em> by the third sprint in a row (the team is consistently over-committing).<br><br>Burndown is a signal, not a report card. Use it to ask questions, not make accusations.' },
                { heading: 'Status Communication That Works', body: 'Status reports fail when they describe activity instead of progress. "The team is working on the API integration" tells a stakeholder nothing useful.<br><br>Effective status communication follows a simple structure: <strong>What\'s done</strong> (completed work this period), <strong>What\'s next</strong> (committed work for next period), and <strong>What needs attention</strong> (blockers, risks, decisions needed from stakeholders).<br><br>The "what needs attention" section is where most PMs underdeliver. Be specific: "The vendor API documentation is incomplete. We need a decision by Thursday on whether to build our own mock or delay the integration by one sprint."' }
              ]
            },
            {
              type: 'keyTakeaway',
              label: 'Takeaway',
              text: 'Delivery management is about detecting the right signals early and acting before blockers become crises. Status should inform, not just report.',
              mentorNote: 'TPM interview questions about delivery often come in the form of "tell me about a project that got into trouble." Your answer should show early detection, decisive action, and clear communication — not heroic firefighting.',
              xp: 25
            }
          ]
        }
      ]
    },

    practice: {
      challenges: [
        {
          id: 'pc-sprint-01',
          prompt: 'It\'s day 7 of a 10-day sprint. The burndown chart is completely flat — no points have been burned in 3 days. What do you do first?',
          choices: [
            { text: 'Extend the sprint by 3 days to give the team time to finish.' },
            { text: 'Hold an urgent standup to understand what is blocked, then work to remove the blocker or adjust the sprint scope before the deadline.' },
            { text: 'Tell the team to work the weekend to complete the sprint commitment.' },
            { text: 'Move all incomplete stories to the next sprint without investigating the cause.' }
          ],
          correctIndex: 1,
          explanation: 'A flat burndown for 3 days is a clear signal of a blocker — not a performance problem. The first move is to surface the root cause in an urgent standup. Once you understand the blocker (dependency, ambiguity, technical issue), you can remove it, re-scope the sprint to protect the goal, or escalate if external action is needed. Sprint extensions and weekend work without root cause analysis just delay the same problem.',
          competency: 'Delivery Management',
          difficulty: 'medium'
        },
        {
          id: 'pc-sprint-02',
          prompt: 'The team has a velocity of 32 story points. In sprint planning, they select 50 points, saying they\'re "motivated to push." What do you do?',
          choices: [
            { text: 'Support the team — motivation increases velocity.' },
            { text: 'Reduce the commitment to 32 points aligned with velocity, and document the discussion.' },
            { text: 'Allow 40 points as a compromise between 32 and 50.' },
            { text: 'Agree to 50 points but secretly plan for 32 to be delivered.' }
          ],
          correctIndex: 1,
          explanation: 'Velocity is historical reality, not a ceiling to break through with enthusiasm. Committing 56% above velocity (50 vs. 32) without a structural change (additional developer, reduced meetings, simpler stories) is a predictable failure. The TPM\'s job is to protect the team\'s credibility and the stakeholder\'s expectations by aligning commitment with proven capacity. Compromising at 40 points still creates a likely miss.',
          competency: 'Sprint Planning',
          difficulty: 'medium'
        },
        {
          id: 'pc-sprint-03',
          prompt: 'A high-priority story was not completed last sprint due to a technical blocker. The blocker is now resolved. The PO wants it at the top of next sprint. The team says it needs re-estimation after the blocker discovery. Who is right?',
          choices: [
            { text: 'The PO — the story is already estimated and should keep its original points.' },
            { text: 'The team — the blocker may have changed the scope or complexity; re-estimation is appropriate before committing.' },
            { text: 'The TPM should estimate it unilaterally based on the original estimate.' },
            { text: 'Remove the story and replace it with smaller stories to avoid the controversy.' }
          ],
          correctIndex: 1,
          explanation: 'The team is right. A technical blocker that required investigation can change the scope, reveal hidden complexity, or require a different implementation approach. Re-estimating after a blocker resolution is not renegotiating — it\'s sound engineering judgment. Story points should reflect current knowledge, not original assumptions. The PO can set the priority; the team sets the estimate.',
          competency: 'Sprint Planning',
          difficulty: 'medium'
        },
        {
          id: 'pc-sprint-04',
          prompt: 'An executive asks for a project status update via email. The project is 60% through a 4-month delivery with one known risk: a vendor dependency is 1 week delayed. What is the BEST structure for your response?',
          choices: [
            { text: 'List all completed tasks to show progress.' },
            { text: 'State: overall status (on track / at risk / off track), what\'s done, what\'s next, and call out the vendor risk with the impact and your mitigation plan.' },
            { text: 'Say the project is on track and handle the vendor risk separately to avoid alarm.' },
            { text: 'Send the full burndown chart and let the executive interpret it.' }
          ],
          correctIndex: 1,
          explanation: 'Effective executive status follows a clear structure: current state, progress, forward outlook, and risks. The vendor delay must be named — hiding it is a trust-destroying pattern that makes the eventual impact worse. Executives expect risk transparency paired with a mitigation plan. "At risk: vendor delivery delayed by 1 week. Mitigation: parallel workstream started with internal team. Impact: +3 days on integration testing, no change to launch date." That\'s what a senior PM delivers.',
          competency: 'Delivery Management',
          difficulty: 'medium'
        },
        {
          id: 'pc-sprint-05',
          prompt: 'With 2 days left in the sprint, the team realizes they can complete either the authentication module (5 pts, critical for the sprint goal) or two smaller UI stories (5 pts total, nice-to-have). What should you recommend?',
          choices: [
            { text: 'Complete the two UI stories — they are faster and increase the number of stories closed.' },
            { text: 'Complete the authentication module — the sprint goal takes priority over point count.' },
            { text: 'Split the remaining effort equally between both.' },
            { text: 'Ask the PO which stories they prefer and follow their choice.' }
          ],
          correctIndex: 1,
          explanation: 'The sprint goal is the anchor for all mid-sprint prioritization decisions. If the authentication module is critical to the sprint goal, completing the nice-to-have UI stories instead would mean failing the sprint goal with the same number of points burned — which is a delivery failure, not a delivery. Story count and point totals are metrics; the sprint goal is the outcome that matters.',
          competency: 'Prioritization',
          difficulty: 'hard'
        }
      ]
    },

    interview: {
      questions: [
        {
          id: 'iq-sprint-01',
          question: 'Tell me about a time when a sprint went off track. What happened and how did you handle it?',
          difficulty: 'medium',
          competency: 'Delivery Management',
          star: {
            situation: 'We were in sprint 4 of a 6-sprint project building a financial reporting API. On day 6 of a 10-day sprint, the burndown was completely flat — no stories had been merged in three days.',
            task: 'I needed to quickly diagnose what was happening, protect the sprint goal if possible, and communicate the risk to stakeholders before it became a launch issue.',
            action: 'I pulled the team together outside of the regular standup to do a quick root cause conversation — not a blame session, just a facts-gathering session. The issue was clear within 10 minutes: the API contracts with the data team had not been finalized, and the backend developers were blocked waiting for confirmed field definitions. I had two actions: unblock the data team dependency by getting the two leads in a room that afternoon, and re-scope the sprint — we agreed to defer two stories that were entirely dependent on the unresolved contracts and pull in two independent stories from the backlog that the team could complete. I updated the sprint goal to reflect the adjusted scope and sent a one-paragraph status update to the Product Owner and engineering manager that same afternoon.',
            result: 'We completed the revised sprint goal on time. The deferred stories were completed in sprint 5 without impacting the overall launch date. The data team dependency got a formal API contract review process added to sprint planning for the rest of the project.',
            keyMessage: 'When a sprint goes off track, the job is to diagnose fast, adapt with the team\'s input, and communicate transparently. A sprint miss you see coming and manage is far better than one that surprises stakeholders on the last day.'
          },
          tips: [
            'The 10-minute root cause conversation — not a blame session — is a strong PM detail that shows psychological safety awareness.',
            'Show the two-part response: fix the blocker AND re-scope. Both moves matter.',
            'The process improvement at the end (API contract review in planning) shows learning orientation.'
          ]
        },
        {
          id: 'iq-sprint-02',
          question: 'How do you prioritize what the team works on when everything feels urgent?',
          difficulty: 'hard',
          competency: 'Prioritization',
          star: {
            situation: 'This is a recurring reality in cross-functional product teams. I\'ve handled it most directly in a period where we had a major client escalation, three sprint commitments in flight, and a production bug affecting 5% of users — all at the same time.',
            task: 'I needed to triage across three competing high-priority items and give the team clarity instead of competing demands from different stakeholders.',
            action: 'I used a simple prioritization filter: customer impact, reversibility, and urgency. The production bug affecting 5% of users was the immediate priority — customer-facing, ongoing, and only getting worse. I pulled one engineer from the sprint to address it, documented the sprint scope change, and updated the velocity forecast. The client escalation was urgent but could be managed with a status call that afternoon — I handled that directly rather than pulling engineers in. The sprint commitments were reprioritized by the PO based on which stories unblocked the most downstream work. I visualized all three streams on a single Kanban board so the team had one source of truth instead of receiving competing priority signals from different people.',
            result: 'The production bug was resolved within 4 hours. The client was calmed in the status call and given a concrete timeline. The sprint delivered its goal one day late — a minor impact that the PO accepted given the production issue.',
            keyMessage: 'When everything is urgent, your first job is to give the team one clear priority order, not three competing ones. Use a consistent framework — customer impact, reversibility, urgency — and make the decision visible to everyone.'
          },
          tips: [
            'The three-factor framework (customer impact, reversibility, urgency) is concrete and memorable — interviewers will note it.',
            'Pulling one engineer and documenting the scope change shows accountability without drama.',
            'The Kanban board for visibility is a great operational detail.'
          ]
        },
        {
          id: 'iq-sprint-03',
          question: 'Describe how you run sprint planning. What makes it effective?',
          difficulty: 'easy',
          competency: 'Sprint Planning',
          star: {
            situation: 'I\'ve facilitated sprint planning for teams ranging from 4 to 14 developers across product and technical infrastructure projects. The core practice has stayed consistent across those contexts.',
            task: 'My goal in every sprint planning is the same: leave the meeting with a sprint goal the team genuinely believes in and a backlog commitment that reflects actual capacity.',
            action: 'I start by calculating real capacity — total sprint days minus vacations, holidays, and known commitments like all-hands or external reviews. I share this number with the team before we select stories. Next, the PO presents the prioritized backlog and explains the business context for the top items. We work through stories top to bottom using planning poker: the team estimates, outliers explain their reasoning, and we refine if needed. We stop when the commitment matches capacity. Finally, I facilitate the sprint goal conversation — I ask: "If we complete everything we\'ve selected, what will be true for our users that wasn\'t true before?" That question reliably produces a better goal than "complete these stories." The whole meeting runs in 90 minutes or less for a 2-week sprint.',
            result: 'Teams I\'ve facilitated this way consistently commit to and deliver sprint goals at a higher rate than teams using informal planning. The sprint goal question has become standard practice on two different teams that adopted it after seeing it in action.',
            keyMessage: 'Effective sprint planning produces a commitment the team believes in. The sprint goal question — "what will be true for users that wasn\'t true before?" — is the most reliable way to get there.'
          },
          tips: [
            'Showing the capacity calculation step signals you don\'t just accept whatever the team says.',
            'The sprint goal question is the highlight of this answer — it\'s specific and immediately usable.',
            'The 90-minute timeframe shows you respect the team\'s time and run efficient meetings.'
          ]
        }
      ]
    }
  },


  // ══════════════════════════════════════════════════════════════════════════
  // PACKAGE 7 — Release Management
  // Competencies: Release Management · Delivery Management · Risk
  // ══════════════════════════════════════════════════════════════════════════
  {
    id: 'PKG-DELIVERY',
    name: 'Release Management',
    icon: '🚀',
    level: 'Intermediate',
    description: 'Ship software confidently — from go/no-go decisions to post-release monitoring.',
    competencies: { 'Release Management': 12, 'Delivery Management': 10, 'Risk Management': 8 },

    learn: {
      id: 'T7',
      title: 'Release Management',
      icon: '🚀',
      description: 'Ship software confidently — from go/no-go decisions to post-release monitoring.',
      level: 'Intermediate',
      experiences: [
        {
          id: 'T7-01',
          title: 'Go / No-Go Decisions',
          objective: 'Run a release readiness review and make defensible go/no-go decisions.',
          duration: '8 min',
          status: 'available',
          competencies: { 'Release Management': 12, 'Risk Management': 8 },
          phases: [
            {
              type: 'classify',
              label: 'Challenge',
              title: 'Go or No-Go?',
              instruction: 'You\'re the TPM running a release readiness review for a SaaS platform update. For each finding, decide: is this a Go (proceed with release) or No-Go (block the release)?',
              mentorIntro: 'Go/no-go decisions are high-stakes. False confidence causes incidents. False caution loses business. Let\'s calibrate your judgment.',
              categories: [
                { id: 'go',   label: 'Go — Release',  icon: '✅' },
                { id: 'nogo', label: 'No-Go — Block',  icon: '🛑' }
              ],
              items: [
                { text: 'The payment processing module has a confirmed bug where 3% of transactions fail silently — no error shown to the user', correct: 'nogo', feedbackCorrect: 'Block. Silent failures in payment flows cause financial discrepancies, support escalations, and regulatory risk. This must be fixed before release.', feedbackWrong: 'A 3% silent failure rate in payment processing is a critical defect — it means customers lose money without knowing it. This is a hard No-Go.' },
                { text: 'The user profile photo upload button label reads "Upload Photo" instead of the designed "Add Profile Picture"', correct: 'go', feedbackCorrect: 'Go. This is a cosmetic label mismatch with zero user impact. Log it as a minor defect for the next release cycle.', feedbackWrong: 'A button label mismatch is cosmetic — it does not affect functionality, security, or user trust. Log it for the next sprint. Don\'t block a release for copy.' },
                { text: 'Load testing revealed that the API gateway fails at 1,200 concurrent users — your platform SLA guarantees 99.9% availability up to 1,000 concurrent users', correct: 'go', feedbackCorrect: 'Go — with conditions. You meet your stated SLA (1,000 concurrent users). Document the capacity ceiling, add monitoring alerts, and create a task to expand capacity in the next sprint.', feedbackWrong: 'The SLA is 1,000 concurrent users. The system handles 1,200. You have headroom above your commitment. Release, but monitor closely and plan capacity expansion.' },
                { text: 'Security penetration testing found a medium-severity SQL injection vulnerability in the admin search feature', correct: 'nogo', feedbackCorrect: 'Block. SQL injection — even medium-severity — is an exploitable security defect in production. It must be patched before release.', feedbackWrong: 'SQL injection is an exploitable vulnerability, not a functional defect. Releasing with a known injection attack vector violates standard security practices — block until patched.' },
                { text: 'The runbook for rolling back the release in case of a critical production issue has not been tested', correct: 'nogo', feedbackCorrect: 'Block or postpone. An untested rollback procedure means if the release causes a production incident, you cannot recover reliably. Test the runbook first.', feedbackWrong: 'An untested rollback procedure is a release risk. If production breaks and the rollback fails, you have an outage you can\'t control. The runbook must be verified before go-live.' }
              ]
            },
            {
              type: 'reading',
              label: 'Concepts',
              title: 'Release Management Fundamentals',
              mentorIntro: 'Your instincts just told you what to block and what to release. Here\'s the framework behind those decisions.',
              sections: [
                { heading: 'What Release Management Covers', body: 'Release management is the process of planning, coordinating, and controlling software deployments from development through production. For a Technical PM, it covers four key areas: <strong>release planning</strong> (what goes in the release and when), <strong>readiness assessment</strong> (is the software and the team ready?), <strong>deployment coordination</strong> (who does what, when), and <strong>post-release monitoring</strong> (did the release behave as expected?).<br><br>The TPM owns the release process — not the technical decisions within it. Engineers decide how to fix bugs. The TPM decides whether the current state of the system meets the bar for release.' },
                { heading: 'Deployment Strategies', body: 'How you release is as important as what you release. Three strategies are commonly used in software teams:<br><br><strong>Big Bang</strong> — release everything at once to all users. Simple to plan, high-risk. One critical defect affects everyone.<br><br><strong>Canary Release</strong> — release to a small percentage of users first (5–10%), monitor metrics, then gradually expand. Reduces blast radius. Requires feature flag infrastructure.<br><br><strong>Blue-Green Deployment</strong> — maintain two identical environments (blue = current production, green = new version). Switch traffic to green, keep blue on standby for instant rollback. Near-zero downtime, but doubles infrastructure cost.' },
                { heading: 'The Rollback Plan', body: 'Every release plan must include a rollback plan — a tested procedure for returning to the previous version if the release causes a critical issue. The rollback plan should answer: who initiates a rollback, what triggers the decision, and how long does rollback take.<br><br>The most common mistake: teams write a rollback plan but never test it. An untested rollback plan is not a plan — it\'s a wish. Require a dry-run rollback in staging before every significant release.' }
              ]
            },
            {
              type: 'keyTakeaway',
              label: 'Takeaway',
              text: 'A go/no-go decision is a risk decision. Block for defects that affect user trust, security, or data integrity. Ship imperfection that doesn\'t break those things.',
              mentorNote: 'Interviewers want to see that you protect users and the business — not that you ship at all costs or block out of excessive caution. Show calibrated judgment.',
              xp: 25
            }
          ]
        },

        {
          id: 'T7-02',
          title: 'Feature Flags & Progressive Rollouts',
          objective: 'Use feature flags and progressive rollout strategies to reduce release risk.',
          duration: '7 min',
          status: 'available',
          competencies: { 'Release Management': 10, 'Delivery Management': 8 },
          phases: [
            {
              type: 'reading',
              label: 'Concepts',
              title: 'Shipping Safely with Feature Flags',
              mentorIntro: 'Feature flags are one of the most important tools in modern release management. If you don\'t know them, you\'re missing a key TPM vocabulary item.',
              sections: [
                { heading: 'What Is a Feature Flag?', body: 'A feature flag (also called a feature toggle or feature switch) is a configuration setting that enables or disables a feature in production without deploying new code. The code is shipped, but the feature is "off" until the flag is flipped.<br><br>This separation of <em>deployment</em> (putting code in production) from <em>release</em> (making a feature available to users) is one of the most powerful concepts in modern software delivery. It allows teams to deploy frequently — daily or even multiple times per day — without each deployment being a visible user-facing release.' },
                { heading: 'Why TPMs Care About Feature Flags', body: 'Feature flags give the TPM granular control over release risk. Instead of choosing between "release to everyone" or "release to no one," flags enable: release to internal users first, release to 1% of users and monitor, release to a specific country or customer tier, and instant rollback by flipping a switch — no code deployment required.<br><br>In high-stakes releases (payments, authentication, infrastructure changes), a flag-gated rollout is almost always the right strategy. It transforms a binary release decision into a controlled, reversible process.' },
                { heading: 'Progressive Rollout in Practice', body: 'A progressive rollout releases a feature to increasing percentages of users over time. A common pattern: 1% → 5% → 20% → 50% → 100%, with a monitoring period at each stage.<br><br>At each stage, the TPM monitors key metrics: error rate, response time, support ticket volume, and business-specific signals (conversion rate, transaction success rate). If a metric degrades at any stage, rollout stops and the issue is investigated before proceeding.<br><br>The monitoring criteria — what counts as "healthy" at each stage — must be defined before rollout begins. Defining success after you see the data is not monitoring; it\'s rationalization.' }
              ]
            },
            {
              type: 'quiz',
              label: 'Quiz',
              title: 'Release Strategy Check',
              mentorIntro: 'Four questions on real release decisions a TPM faces.',
              questions: [
                { question: 'Your team ships a new checkout flow with a feature flag set to 5% of users. After 24 hours, the error rate in the new flow is 2.3% vs. 0.4% in the old flow. What should you do?', options: [ { text: 'Continue the rollout — 2.3% is an acceptable error rate.', correct: false, feedback: 'A 5.75× increase in error rate (0.4% → 2.3%) is a clear signal that something is wrong. Continuing the rollout would multiply the impact.' }, { text: 'Pause the rollout, revert the flag to 0%, and investigate the root cause before proceeding.', correct: true, feedback: 'Correct. The 5.75× increase in errors is a monitoring signal triggering a rollback. Feature flags exist precisely for this moment — flip the flag, protect users, investigate.' }, { text: 'Increase the rollout to 20% and monitor for 48 more hours.', correct: false, feedback: 'Expanding a rollout while error rates are elevated multiplies user impact. The signal says stop — act on it.' }, { text: 'Accept the error rate and track the issue for the next release.', correct: false, feedback: 'A 2.3% error rate in checkout is a business and user experience problem today. Do not defer issues with active user impact.' } ] },
                { question: 'What is the key difference between deployment and release in modern software delivery?', options: [ { text: 'Deployment goes to staging; release goes to production.', correct: false, feedback: 'Both deployment and release happen in production. The distinction is about user visibility, not environment.' }, { text: 'Deployment is putting code in production; release is making a feature visible and active for users.', correct: true, feedback: 'Correct. Feature flags decouple deployment from release. Code can be deployed (present in production) before a feature is released (visible to users).' }, { text: 'Deployment requires approval; release does not.', correct: false, feedback: 'Approval requirements vary by organization and are separate from the technical distinction between deployment and release.' }, { text: 'There is no difference — they are the same thing.', correct: false, feedback: 'Treating deployment and release as identical is what leads to high-risk big-bang releases. The decoupling is deliberate and valuable.' } ] },
                { question: 'A blue-green deployment is BEST suited for which type of release?', options: [ { text: 'A minor CSS styling update to the marketing website.', correct: false, feedback: 'Blue-green deployment adds infrastructure cost and complexity. It\'s overkill for a CSS styling update with no functional risk.' }, { text: 'A critical platform API upgrade where immediate rollback capability and near-zero downtime are required.', correct: true, feedback: 'Correct. Blue-green deployment\'s key strengths are instant rollback (just switch traffic back to blue) and near-zero downtime. These matter most for critical, high-traffic infrastructure changes.' }, { text: 'A new feature release to 5% of users as an experiment.', correct: false, feedback: 'Targeted percentage rollouts are the domain of feature flags and canary releases, not blue-green. Blue-green is a binary traffic switch, not a percentage-based strategy.' }, { text: 'A database schema migration that changes 20 table structures.', correct: false, feedback: 'Database schema migrations are complex because the database is shared — blue-green works well for stateless application code but requires careful coordination with database migrations.' } ] }
              ]
            },
            {
              type: 'keyTakeaway',
              label: 'Takeaway',
              text: 'Decouple deployment from release. Feature flags turn binary release decisions into controlled, reversible experiments with defined success criteria.',
              mentorNote: 'Being fluent in feature flags and progressive rollouts immediately signals to interviewers that you\'ve worked in modern, continuous delivery engineering environments.',
              xp: 25
            }
          ]
        }
      ]
    },

    practice: {
      challenges: [
        {
          id: 'pc-del-01',
          prompt: 'Your team is planning to release a new authentication system on Friday at 5pm. The QA lead flags that the rollback procedure has not been tested. The business team is pressuring for the Friday release. What do you do?',
          choices: [
            { text: 'Release on Friday — rollback is only needed if something goes wrong, and the release looks stable.' },
            { text: 'Postpone the release until the rollback procedure is tested, regardless of business pressure.' },
            { text: 'Release on Friday and ask the on-call engineer to figure out rollback if needed.' },
            { text: 'Schedule the release for Monday instead of Friday to allow the weekend for rollback testing.' }
          ],
          correctIndex: 1,
          explanation: 'An authentication system failure affects every user who tries to log in. Without a tested rollback, a critical incident could require hours of recovery. The business pressure to release Friday is real — but the risk of releasing a critical system without a verified recovery path is greater. Postpone, test the rollback, and release Monday with confidence. A responsible TPM chooses the slightly delayed release over the potentially catastrophic one.',
          competency: 'Release Management',
          difficulty: 'hard'
        },
        {
          id: 'pc-del-02',
          prompt: 'You are running a progressive rollout of a new feature. At 10% rollout, all metrics look healthy. The Product Owner asks to jump straight to 100% rollout to capture the market opportunity. What do you say?',
          choices: [
            { text: 'Agree — if 10% is healthy, 100% will be too.' },
            { text: 'Recommend following the planned rollout stages (10% → 25% → 50% → 100%) and explain the risk of skipping to 100% without intermediate validation.' },
            { text: 'Escalate to the engineering manager to make the call.' },
            { text: 'Agree to go to 50% as a compromise.' }
          ],
          correctIndex: 1,
          explanation: 'The staged rollout exists to surface problems that appear at scale — issues that 10% traffic doesn\'t reveal but 50% does (database contention, cache invalidation, edge cases in high-volume paths). Healthy metrics at 10% are a good signal but not a guarantee. Explain the risk clearly, propose an accelerated but staged path (e.g., 10% → 50% → 100% over 24 hours instead of the full 3-day plan), and let the PO make an informed decision.',
          competency: 'Release Management',
          difficulty: 'medium'
        },
        {
          id: 'pc-del-03',
          prompt: 'During a release to production, the error rate spikes to 8% within 5 minutes of deployment. The on-call engineer says they need 2 hours to identify the root cause. What do you do?',
          choices: [
            { text: 'Wait 2 hours for the root cause before making any decision.' },
            { text: 'Initiate an immediate rollback. Root cause analysis can happen on the previous stable version — don\'t investigate in production while users are affected.' },
            { text: 'Reduce traffic to the new version by 50% and monitor while investigating.' },
            { text: 'Send a user-facing maintenance notification and continue investigating.' }
          ],
          correctIndex: 1,
          explanation: 'An 8% error rate is a production incident. The first priority is to restore service, not to understand the cause. Roll back immediately to the stable version — this stops user impact while the team investigates. Root cause analysis happens on the stable system, not in a degraded production environment. Every minute of investigation during a live incident is a minute users are experiencing errors.',
          competency: 'Release Management',
          difficulty: 'hard'
        },
        {
          id: 'pc-del-04',
          prompt: 'The development team wants to release a new payment integration on December 23rd, 2 days before Christmas. The feature is technically ready. What factors should you evaluate before agreeing?',
          choices: [
            { text: 'Technical readiness is the only factor — if the code is ready, release it.' },
            { text: 'Evaluate: on-call coverage over the holiday, rollback readiness, and whether the business value of releasing now outweighs the risk of reduced response capacity during a potential incident.' },
            { text: 'Always defer releases to January to avoid holiday incidents.' },
            { text: 'Ask engineering to work through the holiday to cover any issues.' }
          ],
          correctIndex: 1,
          explanation: 'Technical readiness is necessary but not sufficient. Release timing includes operational readiness: who is on-call, what\'s the incident response capacity, and can the team react quickly if something goes wrong? A payment integration incident on December 24th with minimal on-call coverage is a severe risk. The right move is to evaluate all three factors — technical, operational, and business — and make a decision that the team can stand behind.',
          competency: 'Release Management',
          difficulty: 'medium'
        },
        {
          id: 'pc-del-05',
          prompt: 'You are preparing a release plan for a major API version upgrade. The API is used by 12 internal services and 3 external partners. How do you structure the release?',
          choices: [
            { text: 'Release the new API version and deprecate the old one on the same day.' },
            { text: 'Run both API versions simultaneously for a transition period, communicate the deprecation timeline to all consumers, and release to internal services first before external partners.' },
            { text: 'Ask all 15 consumers to migrate first, then release the new version.' },
            { text: 'Release the new version to external partners first since they are the most important consumers.' }
          ],
          correctIndex: 1,
          explanation: 'API upgrades with multiple consumers require a parallel versioning strategy. Running both versions simultaneously gives consumers time to migrate without being forced to rush. Internal services first allows for rapid iteration on any issues before external partners are affected. External partners have less tolerance for disruption and less visibility into your release process — they need a formal deprecation timeline and migration support. Simultaneous deprecation of the old version on day one is the highest-risk approach.',
          competency: 'Release Management',
          difficulty: 'hard'
        }
      ]
    },

    interview: {
      questions: [
        {
          id: 'iq-del-01',
          question: 'Tell me about a release that didn\'t go as planned. What happened and what did you do?',
          difficulty: 'medium',
          competency: 'Release Management',
          star: {
            situation: 'We were releasing a new real-time notification system for a B2B SaaS platform. The release went through QA and staging without issues. Fifteen minutes into the production deployment, the engineering team\'s error dashboard showed a spike in WebSocket connection failures for approximately 12% of active users.',
            task: 'I was the TPM and the incident response coordinator. I needed to make a rapid rollback-or-investigate decision and manage communication to internal stakeholders while the engineering team worked.',
            action: 'I made the call to rollback immediately — a 12% connection failure rate affecting real-time features in a B2B product was too high to investigate in production. The rollback took 8 minutes and restored normal error rates. While the team investigated on the stable version, I sent a brief internal status message to the Product Owner, Customer Success lead, and Engineering Manager with: what happened, that we had rolled back, and that we expected a root cause within 2 hours. The engineering team found the issue: a race condition in the WebSocket connection handler that only appeared under production load patterns. We fixed it, added a specific load test for that pattern, and re-released 48 hours later — this time with 100% clean metrics.',
            result: 'No external customers were notified because the rollback restored service quickly. The 48-hour delay was communicated internally as a planned postponement for additional testing. The new load test became part of the standard pre-release checklist for all real-time features.',
            keyMessage: 'The best release decision I made that day was to roll back immediately instead of investigating in production. Speed to recovery matters more than speed to root cause when users are affected. The communication to stakeholders — clear, concise, and confident — kept the situation from escalating beyond the engineering team.'
          },
          tips: [
            'The 8-minute rollback time is a strong specific detail — interviewers notice precision.',
            'The internal status message format (what happened, that we rolled back, timeline for update) is a template worth memorizing.',
            'The process improvement (new load test in the checklist) shows you closed the loop.'
          ]
        },
        {
          id: 'iq-del-02',
          question: 'How do you decide whether a bug should block a release?',
          difficulty: 'medium',
          competency: 'Release Management',
          star: {
            situation: 'This is a decision I make regularly, and I\'ve developed a consistent framework for it rather than deciding case-by-case.',
            task: 'The framework I use evaluates each bug against four criteria before making a block/no-block recommendation.',
            action: 'The four criteria are: user impact (does this affect a user-facing workflow?), blast radius (what percentage of users or transactions are affected?), detectability (will users know something went wrong — silent failure vs. visible error?), and reversibility (can we fix this in a hotfix without a full deployment if it surfaces in production?). A bug that scores high on all four — affects a critical user workflow, affects many users, fails silently, and is hard to hotfix — is an automatic block. A cosmetic bug with zero functional impact and a simple hotfix path is not. I document the reasoning in the release notes so the decision is visible and accountable, not a black box.',
            result: 'This framework has reduced the number of ad-hoc escalations around bug severity decisions because teams know the criteria in advance. It also creates a paper trail when a bug slips through — we can revisit why the decision was made and refine the criteria.',
            keyMessage: 'Release blocking decisions should be made with a consistent framework, not case-by-case instinct. User impact, blast radius, detectability, and reversibility are the four criteria that matter most.'
          },
          tips: [
            'The four-criteria framework (user impact, blast radius, detectability, reversibility) is concrete and demonstrates structured thinking.',
            'The paper trail / documentation point shows accountability and process maturity.',
            'Interviewers will often probe for examples — be ready with a specific bug from your experience for each criterion.'
          ]
        },
        {
          id: 'iq-del-03',
          question: 'How do you coordinate a release across multiple teams?',
          difficulty: 'hard',
          competency: 'Release Management',
          star: {
            situation: 'I coordinated a platform-wide release that required synchronized deployment across 5 microservices owned by 3 different engineering teams, with a shared cutover window of 30 minutes on a Saturday morning.',
            task: 'I needed to ensure all teams were ready, the cutover sequence was correct, and everyone knew exactly what to do if something went wrong during the window.',
            action: 'I built a release runbook with three sections: pre-release checklist (every team confirms deployment ready by Friday 5pm), cutover sequence (services deployed in dependency order — database migrations first, then services A, B, C in order, then frontend), and rollback protocol (each team had a pre-written rollback command and a max 10-minute window before I would call a rollback across all services). I ran a readiness call on Friday afternoon where each team lead verbally confirmed their status and walked through their rollback procedure. During the cutover, I was on a shared call bridge with all teams and narrated each step as we went. Every team had a timer showing how much of the 30-minute window remained.',
            result: 'The release completed in 22 minutes with no rollback required. One team had a minor issue with their pre-release health check, which we caught on the readiness call and resolved Friday evening — before the cutover. The runbook became the template for all subsequent platform releases.',
            keyMessage: 'Multi-team releases are coordination problems first and technical problems second. A clear runbook, a verified readiness state, a defined rollback protocol, and real-time communication on a shared call bridge are the conditions that make complex releases predictable.'
          },
          tips: [
            'The three-section runbook structure (checklist, sequence, rollback) is immediately adoptable by interviewers.',
            'Catching the health check issue on the Friday readiness call — not during the cutover — is the key detail showing proactive risk management.',
            'The 22-minute completion in a 30-minute window shows planning precision.'
          ]
        }
      ]
    }
  },


  // ══════════════════════════════════════════════════════════════════════════
  // PACKAGE 8 — Leadership & Decision Making
  // Competencies: Leadership · Decision Making · Conflict Resolution
  // ══════════════════════════════════════════════════════════════════════════
  {
    id: 'PKG-LEADERSHIP',
    name: 'Leadership & Decision Making',
    icon: '🧭',
    level: 'Advanced',
    description: 'Lead teams you don\'t manage and make hard calls that earn trust.',
    competencies: { 'Leadership': 12, 'Decision Making': 10, 'Conflict Resolution': 8 },

    learn: {
      id: 'T8',
      title: 'Leadership & Decision Making',
      icon: '🧭',
      description: 'Lead teams you don\'t manage and make hard calls that earn trust.',
      level: 'Advanced',
      experiences: [
        {
          id: 'T8-01',
          title: 'Influencing Without Authority',
          objective: 'Lead engineering and cross-functional teams without direct management authority.',
          duration: '9 min',
          status: 'available',
          competencies: { 'Leadership': 12, 'Conflict Resolution': 6 },
          phases: [
            {
              type: 'reading',
              label: 'Concepts',
              title: 'The TPM\'s Influence Model',
              mentorIntro: 'Influencing without authority is the defining challenge of the Technical PM role. Let\'s build your toolkit for it.',
              sections: [
                { heading: 'Why Authority Is Not Enough', body: 'Technical Project Managers rarely have direct management authority over engineers, designers, or other PMs. Engineers report to Engineering Managers. Designers report to Design Directors. Yet the TPM is accountable for project outcomes that require all of them.<br><br>This creates the core challenge of the role: <em>you are responsible for outcomes you cannot directly control.</em> Authority-based management fails here. The engineers will comply — and disengage. Influence-based leadership builds commitment, not compliance.' },
                { heading: 'The Four Influence Levers', body: '<strong>Credibility</strong> — When you understand the technical problem well enough to contribute meaningfully, engineers trust your judgment. You don\'t need to write code. You need to understand architecture, tradeoffs, and constraints well enough to ask the right questions.<br><br><strong>Clarity</strong> — You remove ambiguity. Engineers commit to work they understand. When you translate vague requirements into clear acceptance criteria, you create commitment by removing fear.<br><br><strong>Reciprocity</strong> — When you shield the team from interruptions, run better meetings, and absorb administrative overhead so engineers can focus on engineering, they invest more in the project. You serve the team; the team serves the project.<br><br><strong>Coalition</strong> — Build alignment with key voices before the meeting, not during it. A senior engineer who endorses your plan in the room is worth more than your own argument.' },
                { heading: 'When Engineers Push Back', body: 'Engineer pushback is data, not defiance. When an engineer says "that\'s not possible in two weeks," they mean one of three things: the scope is genuinely too large, the timeline doesn\'t account for complexity they can see, or they don\'t trust that the decision-making process will protect them from being blamed if they\'re wrong.<br><br>The right response to pushback is never to override and never to capitulate without understanding. Ask: "Walk me through what makes this hard." Then listen. You will learn something — either a real constraint that changes your plan, or a fear you can address directly.' }
              ]
            },
            {
              type: 'quiz',
              label: 'Quiz',
              title: 'Influence in Practice',
              mentorIntro: 'These scenarios test the judgment a senior TPM applies daily.',
              questions: [
                { question: 'A senior engineer consistently dismisses your timeline estimates in team meetings with comments like "that\'s not realistic." What is the most effective response over time?', options: [ { text: 'Escalate to the engineering manager to address the engineer\'s behavior.', correct: false, feedback: 'Escalating for public disagreement undermines trust and typically makes the dynamic worse. It signals that you rely on authority, not credibility.' }, { text: 'Involve the engineer in the estimation process early, use their input to build the timeline, and ensure their name is on the estimate they contributed to.', correct: true, feedback: 'Correct. When the senior engineer\'s expertise shapes the estimate, they own it. People defend the estimates they built — not the estimates handed to them.' }, { text: 'Ignore the comments and proceed with your estimates.', correct: false, feedback: 'Ignoring consistent dismissal from a senior voice doesn\'t resolve the dynamic — it hardens it. Other engineers notice and begin to question the estimates too.' }, { text: 'Ask the engineer to provide their own timeline instead.', correct: false, feedback: 'This creates an adversarial split between "your estimate" and "their estimate." Collaborative estimation — building one timeline together — is more effective.' } ] },
                { question: 'You need a decision from the Engineering Manager by Thursday to unblock a sprint. They haven\'t responded to two emails. What do you do?', options: [ { text: 'Escalate to the VP of Engineering on Thursday morning.', correct: false, feedback: 'Escalating to the VP without first exhausting direct channels is a relationship-damaging move. Try direct contact first.' }, { text: 'Send a third email on Thursday morning with "URGENT" in the subject line.', correct: false, feedback: 'A third email is unlikely to produce a different result. The medium is the problem, not the content.' }, { text: 'Switch channels — ask for 10 minutes in person or via a quick call, clearly stating the decision needed and the impact of waiting past Thursday.', correct: true, feedback: 'Correct. When email fails, switch channels. A direct conversation — even 10 minutes — with a clear "here\'s what I need, here\'s what happens if I don\'t have it by Thursday" resolves most unresponsive escalations.' }, { text: 'Make the decision yourself and document that the EM was unavailable.', correct: false, feedback: 'Making a decision outside your authority without exhausting escalation options is risky. Document the attempt and escalate up one level if direct contact fails.' } ] },
                { question: 'An engineer says your sprint plan is technically sound but that the team is burned out and needs a lighter sprint. What do you do?', options: [ { text: 'Acknowledge the concern but keep the plan — commitments have been made.', correct: false, feedback: 'Commitments made to stakeholders can be renegotiated. Ignoring a burnout signal to protect a schedule creates a bigger problem: talent loss and quality degradation.' }, { text: 'Listen, discuss with the team, consider reducing the sprint scope, and proactively communicate any impact to stakeholders.', correct: true, feedback: 'Correct. A burned-out team delivering at 60% quality is worse than a lighter sprint with high-quality output. Protecting the team\'s sustainable pace is a leadership decision — communicate it transparently.' }, { text: 'Offer the team a team lunch and keep the sprint as planned.', correct: false, feedback: 'Morale gestures don\'t address capacity problems. If the team is burned out, the solution is capacity relief — not catering.' }, { text: 'Move the lower-priority stories to the next sprint without consulting the team.', correct: false, feedback: 'Re-scoping without team input removes the engineer\'s agency — which is one source of burnout. Include the team in the solution.' } ] }
              ]
            },
            {
              type: 'keyTakeaway',
              label: 'Takeaway',
              text: 'TPM influence comes from credibility, clarity, reciprocity, and coalition — not from authority. Build it before you need it.',
              mentorNote: 'The question "how do you lead without authority?" comes up in almost every senior TPM interview. Your answer should show all four levers in action, not just one.',
              xp: 30
            }
          ]
        },

        {
          id: 'T8-02',
          title: 'Making Hard Calls',
          objective: 'Use structured frameworks to make and defend difficult project decisions.',
          duration: '8 min',
          status: 'available',
          competencies: { 'Decision Making': 12, 'Leadership': 8 },
          phases: [
            {
              type: 'reading',
              label: 'Concepts',
              title: 'Decision Frameworks for Technical PMs',
              mentorIntro: 'Hard decisions are hard because they involve real tradeoffs with real consequences. The goal isn\'t to eliminate discomfort — it\'s to decide clearly and own the outcome.',
              sections: [
                { heading: 'Decide or Escalate?', body: 'The first judgment call is whether a decision is yours to make. A simple filter: <strong>decisions within your scope, authority, and risk tolerance are yours to make.</strong> Decisions that exceed your scope, affect other teams without their input, or carry risk above your stated authority level need to be escalated — not abdicated.<br><br>The difference between escalating and abdicating: escalating means you bring the decision to the right person with your recommendation and the data they need to decide. Abdicating means you hand the problem up without analysis. Good PMs escalate rarely and with precision.' },
                { heading: 'The DACI Framework', body: 'DACI (Driver, Approver, Contributor, Informed) clarifies who does what in a decision:<br><br><strong>Driver</strong> — owns the decision process, gathers input, drives to resolution. Usually the TPM.<br><strong>Approver</strong> — has final authority. Can be the PM, Engineering Manager, or executive depending on scope.<br><strong>Contributors</strong> — provide expertise and input. Engineers, designers, legal, security — whoever has relevant knowledge.<br><strong>Informed</strong> — notified of the decision after it\'s made, but not part of making it.<br><br>Applying DACI before a decision prevents two failure modes: the "too many cooks" meeting where everyone thinks they have a vote, and the "nobody decided" outcome where accountability is diffuse.' },
                { heading: 'When You Are Wrong', body: 'Every senior TPM has made a decision that turned out to be wrong. How you handle that moment determines whether your team trusts you for the next one.<br><br>Three principles for accountability without self-destruction: acknowledge clearly ("this didn\'t work and I made the call"), explain the reasoning at the time ("here\'s what I knew and what I concluded"), and describe what you would do differently ("next time I\'d add a spike to validate the assumption before committing"). This is not weakness — it\'s the leadership behavior that makes teams willing to follow uncertain decisions.' }
              ]
            },
            {
              type: 'quiz',
              label: 'Quiz',
              title: 'Decision Making Under Pressure',
              mentorIntro: 'Situations where the right move isn\'t obvious — and where judgment separates good PMs from great ones.',
              questions: [
                { question: 'The engineering team and the Product Owner disagree on whether to fix a technical debt issue or deliver a new feature in the next sprint. Both argue their case strongly. As the TPM, what do you do?', options: [ { text: 'Side with the Product Owner — product decisions are the PO\'s authority.', correct: false, feedback: 'Defaulting to hierarchy avoids the real issue. Technical debt can affect delivery capacity for the next 6 sprints — that\'s a delivery risk the TPM should evaluate and quantify.' }, { text: 'Quantify the technical debt impact (how many sprints does it slow delivery?), present the tradeoff explicitly to the team, and facilitate a decision that both sides understand.', correct: true, feedback: 'Correct. The TPM\'s job is to make the tradeoff visible — not to pick a side. Quantifying the debt\'s impact (e.g., "this slows every sprint by 15% for the next 6 sprints") transforms an opinion debate into a data decision.' }, { text: 'Defer the decision to the next sprint to avoid the conflict now.', correct: false, feedback: 'Deferring unresolved conflicts doesn\'t resolve them. The same argument will recur next sprint, with less time and more pressure.' }, { text: 'Ask the Engineering Manager to make the call so neither the team nor the PO is frustrated with you.', correct: false, feedback: 'Passing a facilitation problem up the chain is abdicating. The TPM is best positioned to model and quantify this tradeoff.' } ] },
                { question: 'A decision needs to be made today and the Approver in the DACI is on vacation for 3 days. What do you do?', options: [ { text: 'Wait 3 days for the approver to return.', correct: false, feedback: 'If waiting 3 days has no delivery cost, it\'s a reasonable choice. But if there\'s a delivery impact, waiting without action is itself a decision — and a bad one.' }, { text: 'Make the decision yourself and tell the approver when they return.', correct: false, feedback: 'Making a decision outside your authority without a documented escalation attempt creates accountability problems if the decision turns out poorly.' }, { text: 'Identify the approver\'s backup or delegate, brief them on the context and options, and get a decision with documented approval.', correct: true, feedback: 'Correct. Every approver should have a designated backup for exactly this reason. Escalating to the backup with full context and options is the professional move.' }, { text: 'Inform the team that the decision is blocked and pause all related work.', correct: false, feedback: 'Blocking all related work without attempting to route through a backup wastes team capacity. Always try to route the decision before stopping work.' } ] }
              ]
            },
            {
              type: 'keyTakeaway',
              label: 'Takeaway',
              text: 'Decide with a framework, own the outcome, and model accountability when you\'re wrong. Clarity under uncertainty builds team trust faster than being right.',
              mentorNote: 'The DACI framework is worth memorizing — interviewers respond well to PMs who use structured vocabulary for decision governance.',
              xp: 30
            }
          ]
        }
      ]
    },

    practice: {
      challenges: [
        {
          id: 'pc-lead-01',
          prompt: 'Two senior engineers are publicly disagreeing in the sprint planning meeting about the implementation approach for a new feature. The discussion has been going for 20 minutes with no resolution. What do you do?',
          choices: [
            { text: 'Let the debate continue — the team should resolve technical decisions organically.' },
            { text: 'Pick one engineer\'s approach and move on to keep the meeting on track.' },
            { text: 'Timeboxed the discussion: give 5 more minutes, then schedule a separate technical decision session with the two engineers and a staff engineer, and move the story to "needs tech decision" status.' },
            { text: 'Escalate to the Engineering Manager to resolve the disagreement.' }
          ],
          correctIndex: 2,
          explanation: 'A 20-minute unresolved technical debate in a planning meeting is a meeting management failure. The TPM\'s job is to timebox the conversation, acknowledge that this needs more time than planning allows, and create a structured space for the decision. Scheduling a dedicated 30-minute technical decision session with the right people protects both the planning meeting and the quality of the decision.',
          competency: 'Conflict Resolution',
          difficulty: 'medium'
        },
        {
          id: 'pc-lead-02',
          prompt: 'A developer tells you privately that they disagree with the technical direction the team lead chose, and they think it will cause major problems in 3 months. They don\'t want to say it publicly. What do you do?',
          choices: [
            { text: 'Respect the developer\'s privacy and do nothing — it\'s between them and the team lead.' },
            { text: 'Share the developer\'s concern with the team lead without identifying them, and recommend a technical review session.' },
            { text: 'Coach the developer to raise their concern directly, and offer to facilitate a safe technical review where the concern can be raised by the team.' },
            { text: 'Escalate the concern to the Engineering Manager immediately.' }
          ],
          correctIndex: 2,
          explanation: 'A technical concern with a 3-month horizon deserves to be heard — it\'s a risk. The right response is to coach the developer toward raising it through a safe channel (a team retrospective or a technical review) and to create that channel if it doesn\'t exist. Going behind the developer\'s back (option B) violates trust. Doing nothing (option A) ignores a real project risk. Escalating immediately (option D) is premature.',
          competency: 'Leadership',
          difficulty: 'hard'
        },
        {
          id: 'pc-lead-03',
          prompt: 'The project is 3 weeks behind schedule. The executive sponsor asks you in a hallway conversation: "Are we going to make the launch date?" What do you say?',
          choices: [
            { text: '"Yes, we\'re on track." You\'ll figure out the details later.' },
            { text: '"I\'ll send you an updated status report by end of day with our current projection and options."' },
            { text: '"No — we\'re 3 weeks behind and I don\'t know if we can recover."' },
            { text: '"The team is working hard and I\'m confident we\'ll find a way to deliver."' }
          ],
          correctIndex: 1,
          explanation: 'Hallway conversations are not the right venue for a 3-week schedule variance discussion. The right answer buys time for a proper conversation without being evasive: commit to a same-day written update with the real data, options, and your recommendation. Option A is dishonest. Option C is too blunt without context or a path forward. Option D is non-committal and feels like spin to an executive who is already asking.',
          competency: 'Decision Making',
          difficulty: 'medium'
        },
        {
          id: 'pc-lead-04',
          prompt: 'You made a decision in last sprint\'s planning to deprioritize performance optimization work. This sprint, the application response time has degraded significantly and the team is frustrated. How do you handle it?',
          choices: [
            { text: 'Blame the business requirements that forced the deprioritization.' },
            { text: 'Acknowledge the decision you made, explain the reasoning at the time, and immediately reprioritize the performance work with a concrete recovery plan.' },
            { text: 'Say the engineers should have flagged the performance risk more clearly before the decision.' },
            { text: 'Add the performance work to next sprint without addressing the team\'s frustration.' }
          ],
          correctIndex: 1,
          explanation: 'Accountability after a bad call is what separates leaders from managers. The right move: own the decision ("I made the call to defer the performance work"), explain the context ("based on the stakeholder priority at the time"), and present the recovery plan ("it\'s now Sprint priority 1, here\'s the timeline for resolution"). Blame, deflection, and silent correction all erode team trust.',
          competency: 'Leadership',
          difficulty: 'hard'
        },
        {
          id: 'pc-lead-05',
          prompt: 'You are leading a project with no formal authority over the team. A key developer starts missing standups and their velocity drops significantly. Their engineering manager tells you it\'s "being handled internally." What do you do?',
          choices: [
            { text: 'Accept the engineering manager\'s assurance and adjust the sprint plan to account for reduced capacity.' },
            { text: 'Escalate to the VP of Engineering to resolve the developer\'s performance issue.' },
            { text: 'Keep pressuring the developer directly until their output improves.' },
            { text: 'Confront the engineering manager publicly in the next team meeting.' }
          ],
          correctIndex: 0,
          explanation: 'Personnel issues are the Engineering Manager\'s responsibility — not the TPM\'s. Once the EM confirms it\'s being handled, the appropriate TPM response is to: (1) update the capacity plan to reflect actual availability, (2) adjust sprint commitments accordingly, and (3) flag to stakeholders if the capacity impact creates a delivery risk. Attempting to manage the developer directly, escalating over the EM\'s head, or confronting them publicly all violate the trust boundary between project leadership and people management.',
          competency: 'Leadership',
          difficulty: 'hard'
        }
      ]
    },

    interview: {
      questions: [
        {
          id: 'iq-lead-01',
          question: 'Tell me about a time you had to influence a team or person without having direct authority over them.',
          difficulty: 'medium',
          competency: 'Leadership',
          star: {
            situation: 'I was TPM on a platform migration project where a senior backend engineer was consistently pushing back on the proposed timeline, describing it as "unrealistic" in team meetings. I had no authority over them — they reported to the Backend Engineering Manager.',
            task: 'I needed to either get their genuine buy-in for the timeline or update the timeline based on their expert input — without forcing compliance and without allowing the project to drift.',
            action: 'I asked for a 30-minute 1:1 with the engineer. I started the conversation by asking them to walk me through exactly what they thought would take longer and why. Within 10 minutes, they had identified two specific technical risks I hadn\'t accounted for: a database migration that required a full service downtime window, and a legacy caching layer that would need a custom migration tool. Both were real. I added a 2-week buffer for those items, documented the risks explicitly in the project plan, and asked the engineer to review the updated timeline before the next team meeting. In the next meeting, they said the updated plan "looked reasonable." That credibility shift changed the dynamic for the rest of the project.',
            result: 'The project delivered within the revised timeline. The two risks the engineer identified were the only items that required the buffer — validating their expertise. The engineer became one of my strongest advocates in cross-team conversations for the rest of the project.',
            keyMessage: 'Influence starts with listening. I went into that 1:1 expecting to convince someone — and instead learned something real. The best way to win someone\'s commitment is to build a plan together. The 30-minute conversation was worth 3 weeks of friction.'
          },
          tips: [
            'The specific technical details (database migration, caching layer) make this story credible — interviewers can tell when a story is real vs. generic.',
            'The dynamic shift — from "unrealistic" to "looks reasonable" — is the concrete outcome to emphasize.',
            'The key message about listening first is authentic and will resonate with senior interviewers.'
          ]
        },
        {
          id: 'iq-lead-02',
          question: 'Describe a difficult decision you had to make on a project. How did you approach it?',
          difficulty: 'hard',
          competency: 'Decision Making',
          star: {
            situation: 'Three weeks before a major product launch, our security team flagged a medium-severity authentication vulnerability in the new user registration flow. Fixing it properly required 8 days of engineering work. The launch was 15 business days away. The alternative was a temporary mitigation (rate limiting and monitoring) that reduced — but did not eliminate — the risk.',
            task: 'I had to make a recommendation to the executive team: delay the launch, ship with the mitigation, or explore a third path.',
            action: 'I built a decision framework with three scenarios. Scenario A: delay 8 days, fix properly, launch clean. Scenario B: launch with mitigation, fix in the first post-launch sprint. Scenario C: partial launch — release to 10% of users behind a waitlist while the fix was completed, then open to 100% at the original date. I assessed each against four criteria: security risk, business impact, customer trust, and engineering team capacity. I presented all three to the VP of Product and CISO with my recommendation: Scenario C. It preserved the launch date for the business narrative, protected 90% of users during the vulnerability window, and gave engineering 12 days instead of 8 to fix it properly without crunch.',
            result: 'The CISO and VP agreed with Scenario C. We launched to 10% on schedule, fixed the vulnerability in 10 days, and opened to 100% two days before the full launch date. No security incident occurred. The structured decision framework was later adopted by the team as our standard for go/no-go vulnerability triage.',
            keyMessage: 'Hard decisions get easier when you build a framework instead of arguing positions. The three-scenario approach forces you to examine the full solution space — and usually produces an option nobody was considering.'
          },
          tips: [
            'The three-scenario format with four evaluation criteria is a strong analytical framework that interviewers will remember.',
            'Scenario C (partial launch / waitlist) shows creative problem-solving beyond the binary "delay vs. ship."',
            'The CISO\'s agreement is an important detail — it validates the decision through a relevant authority.'
          ]
        },
        {
          id: 'iq-lead-03',
          question: 'Tell me about a time you had to handle conflict within a project team.',
          difficulty: 'medium',
          competency: 'Conflict Resolution',
          star: {
            situation: 'Two of the most experienced engineers on a data platform project were in open conflict over the design of a shared data model. One engineer wanted a normalized schema optimized for storage; the other wanted a denormalized schema optimized for query performance. Both had valid technical arguments. The conflict was affecting team morale — other engineers were uncomfortable in meetings.',
            task: 'I needed to resolve the conflict in a way that produced a technical decision the team could live with and restored the collaborative dynamic.',
            action: 'I called a separate 45-minute session with both engineers and a data architect from another team as a neutral technical voice. I reframed the session explicitly: "We\'re not here to decide who\'s right. We\'re here to decide what\'s right for this use case." I asked each engineer to present their case in terms of measurable tradeoffs — query latency, storage cost, write complexity, and maintenance burden — rather than architecture philosophy. The neutral architect helped quantify the tradeoffs. At the end, I made the call: the denormalized schema for the read-heavy reporting use case, with a documented decision record explaining why. Both engineers accepted the process because they had been heard, the criteria were explicit, and the decision was made with external validation.',
            result: 'The team\'s dynamic improved immediately after the session. The two engineers became collaborative — the tension had come from feeling like their expertise wasn\'t being heard, not from personal animosity. The decision record was referenced three months later when a new engineer joined and asked about the schema design.',
            keyMessage: 'Conflict in technical teams is usually about being heard, not about being right. Creating a structured space where both parties can present their case against explicit criteria — and bringing in neutral expertise — transforms a debate into a decision.'
          },
          tips: [
            'The reframe — "we\'re not deciding who\'s right, we\'re deciding what\'s right for this use case" — is a ready-to-use facilitation line.',
            'The four measurable criteria (latency, storage, write complexity, maintenance) show technical literacy.',
            'The decision record detail shows PM rigor — decisions get documented, not just made.'
          ]
        }
      ]
    }
  },


  // ══════════════════════════════════════════════════════════════════════════
  // PACKAGE 9 — APIs & System Integrations
  // Competencies: API Literacy · Integration Management · Technical Communication
  // ══════════════════════════════════════════════════════════════════════════
  {
    id: 'PKG-TECHNICAL',
    name: 'APIs & System Integrations',
    icon: '🔌',
    level: 'Intermediate',
    description: 'Speak fluently about APIs, integrations, and system dependencies — without writing a line of code.',
    competencies: { 'API Literacy': 12, 'Integration Management': 10, 'Technical Communication': 8 },

    learn: {
      id: 'T9',
      title: 'APIs & System Integrations',
      icon: '🔌',
      description: 'Speak fluently about APIs, integrations, and system dependencies — without writing a line of code.',
      level: 'Intermediate',
      experiences: [
        {
          id: 'T9-01',
          title: 'API Concepts for Project Managers',
          objective: 'Understand what APIs are, how they work, and what questions to ask when a project depends on one.',
          duration: '9 min',
          status: 'available',
          competencies: { 'API Literacy': 12, 'Technical Communication': 6 },
          phases: [
            {
              type: 'reading',
              label: 'Concepts',
              title: 'APIs: What Every PM Must Know',
              mentorIntro: 'APIs come up in almost every software project. You don\'t need to build them — but you need to understand them well enough to manage the risks around them.',
              sections: [
                { heading: 'What Is an API?', body: 'An API (Application Programming Interface) is a defined contract that allows two software systems to communicate. It specifies what requests one system can make to another, what data those requests must include, and what responses to expect.<br><br>A practical analogy: a restaurant menu is an API. It lists what you can order (endpoints), what information you provide (your table number, dietary restrictions), and what you will receive (your meal). The kitchen\'s internal cooking process is invisible to you — just like the internal implementation of an API is invisible to its caller.' },
                { heading: 'REST and the Request-Response Cycle', body: 'Most modern web APIs follow the REST (Representational State Transfer) pattern. In a REST API:<br><br>• A <strong>request</strong> is sent to a specific URL called an <em>endpoint</em> (e.g., /api/v1/users/123)<br>• The request uses an HTTP method: GET (read), POST (create), PUT (update), DELETE (remove)<br>• The response returns data in JSON format, along with a <em>status code</em> (200 = success, 404 = not found, 500 = server error)<br><br>As a PM, these three concepts — endpoint, method, status code — appear in every API integration conversation. When a developer says "the POST to /orders is returning a 422," you should understand: they\'re creating an order, and the server is rejecting the request data as invalid.' },
                { heading: 'API Keys, Rate Limits, and Versioning', body: 'Three API concepts that directly affect project planning:<br><br><strong>API Keys</strong> — credentials that authenticate who is making requests. If a third-party API requires an API key, the team needs to request it (which can take days or weeks from enterprise vendors), and it must be stored securely — never in code repositories.<br><br><strong>Rate Limits</strong> — most APIs cap the number of requests per minute or day. Exceeding the limit returns a 429 (Too Many Requests) error. A PM building a product that calls an external API must understand the rate limits and how they interact with the expected load.<br><br><strong>API Versioning</strong> — APIs change over time. Providers publish versions (v1, v2) and deprecate old ones with notice periods. If your product depends on an API endpoint, you must track deprecation notices and plan migration work before the deadline.' }
              ]
            },
            {
              type: 'quiz',
              label: 'Quiz',
              title: 'API Literacy Check',
              mentorIntro: 'These questions come from real TPM conversations about API dependencies.',
              questions: [
                { question: 'Your team is integrating with a payment provider\'s API. The provider says their API has a rate limit of 100 requests per minute. Your product is expected to process 50 orders per minute at peak. What risk should you flag?', options: [ { text: 'No risk — 50 orders per minute is well within 100 requests per minute.', correct: false, feedback: 'One order may require multiple API calls: create order, charge card, confirm payment, update inventory. 50 orders × 3 calls each = 150 calls per minute — already over the limit.' }, { text: 'The rate limit may be exceeded if each order triggers multiple API calls. Request rate limit documentation from the provider and test under peak load.', correct: true, feedback: 'Correct. Orders often require multiple API calls in sequence. Without knowing the call-per-order ratio, a 100-request limit could fail at 35 orders per minute.' }, { text: 'Rate limits only apply to testing environments — production has no limits.', correct: false, feedback: 'Rate limits apply to production. Enterprise providers often have higher production limits, but they are not unlimited. Always verify.' }, { text: 'Ask the engineering team to cache API responses to reduce call volume.', correct: false, feedback: 'Caching works for GET requests (reading data) but not for transactional POST requests (processing payments). This flag doesn\'t solve a payment processing rate limit problem.' } ] },
                { question: 'A third-party analytics API you depend on announces they are deprecating the v1 API in 90 days. What should you do immediately?', options: [ { text: 'Wait to see if the deadline gets extended — deprecations often do.', correct: false, feedback: 'Planning around hoped-for extensions is poor risk management. Treat the 90-day deadline as real and plan accordingly.' }, { text: 'Add an urgent backlog item for API v2 migration, estimate the engineering effort, and plan the sprint allocation before the deadline.', correct: true, feedback: 'Correct. 90 days sounds like a lot but typically includes discovery, development, testing, and deployment. Add the migration to the backlog immediately, estimate it, and get it scheduled with enough runway.' }, { text: 'Email the analytics provider to ask for a 6-month extension.', correct: false, feedback: 'Requesting an extension is reasonable as a parallel track — but not as a primary strategy. Plan the migration independently of whether the extension is granted.' }, { text: 'Notify the engineering team and let them decide when to migrate.', correct: false, feedback: 'Without PM-driven scheduling, migrations often get deprioritized in favor of feature work — until the deadline is 2 weeks away and the team is scrambling.' } ] },
                { question: 'An engineer says: "The external CRM API is returning a 503 intermittently." What does this most likely mean for the project?', options: [ { text: 'The team\'s API key has expired and needs to be renewed.', correct: false, feedback: 'An expired API key returns a 401 (Unauthorized) or 403 (Forbidden) — not a 503.' }, { text: 'The CRM provider\'s server is temporarily unavailable, causing intermittent failures in any feature that calls it.', correct: true, feedback: 'Correct. HTTP 503 means "Service Unavailable" — the server is temporarily down or overloaded. Features depending on this API will fail intermittently until the provider restores service.' }, { text: 'The team\'s code has a syntax error in the API request.', correct: false, feedback: 'A syntax error in the request would return a 400 (Bad Request) or 422 (Unprocessable Entity) — a client-side error, not a server-side one.' }, { text: 'The team is exceeding the rate limit on the CRM API.', correct: false, feedback: 'Rate limit exceeded returns a 429 (Too Many Requests) — a specific, different error code from 503.' } ] }
              ]
            },
            {
              type: 'keyTakeaway',
              label: 'Takeaway',
              text: 'APIs are contracts. As a TPM, understand the terms: what you can call, how often, what it costs when the other side breaks the contract.',
              mentorNote: 'Being able to discuss endpoints, status codes, rate limits, and versioning fluently signals to engineering teams that you\'re a technical PM — not just a coordinator.',
              xp: 25
            }
          ]
        },

        {
          id: 'T9-02',
          title: 'Managing Integration Projects',
          objective: 'Identify and manage the unique risks in projects that depend on third-party systems.',
          duration: '8 min',
          status: 'available',
          competencies: { 'Integration Management': 12, 'API Literacy': 6 },
          phases: [
            {
              type: 'reading',
              label: 'Concepts',
              title: 'Integration Projects: Where Dependencies Become Risks',
              mentorIntro: 'Integration projects are some of the most complex to manage because your delivery depends on systems and teams outside your control.',
              sections: [
                { heading: 'Why Integration Projects Are Different', body: 'Standard software projects fail because of internal execution problems: unclear requirements, technical complexity, team capacity. Integration projects have all of those risks — plus an external dependency on a third-party system your team cannot change, fix, or accelerate.<br><br>The most common integration failures: the API doesn\'t do what the documentation says it does, the sandbox (test) environment doesn\'t behave like production, the rate limits in the contract are lower than the actual production limits, and the vendor\'s support response time is measured in days, not hours.' },
                { heading: 'API Contract Review', body: 'Before the engineering team begins integration work, the TPM should drive an API contract review session with engineering. The session should answer: Does the API documentation match the actual behavior? (Test in the sandbox.) What are the rate limits and how do they interact with our expected load? What error states does the API return and how do we handle them? What is the vendor\'s SLA for API uptime, and does it match our product\'s SLA commitment to customers?<br><br>An API that looks perfect in documentation and is broken in practice is one of the most expensive surprises in integration projects — and the easiest to catch with a 2-hour spike before committing to a sprint plan.' },
                { heading: 'Building Resilience into Integrations', body: 'Third-party APIs go down. Rate limits get hit. Responses time out. A resilient integration handles all of these states gracefully rather than propagating failures to users.<br><br>Four patterns to discuss with engineering: <strong>Retry logic</strong> (if a request fails, retry with exponential backoff before returning an error), <strong>Circuit breaker</strong> (if the API is consistently failing, stop calling it to prevent cascading load), <strong>Graceful degradation</strong> (if the integration fails, show a reduced experience rather than a broken one), and <strong>Webhook vs. polling</strong> (instead of checking the API every second, use webhooks to receive real-time notifications only when something changes).' }
              ]
            },
            {
              type: 'keyTakeaway',
              label: 'Takeaway',
              text: 'Integration risk lives outside your team. Validate the contract early, plan for the third party to fail, and build graceful degradation before you need it.',
              mentorNote: 'Technical interviewers will probe whether you\'ve managed real integration projects — these patterns (retry, circuit breaker, graceful degradation) are the vocabulary that proves you have.',
              xp: 25
            }
          ]
        }
      ]
    },

    practice: {
      challenges: [
        {
          id: 'pc-tech-01',
          prompt: 'Your team is 2 weeks into integrating a third-party shipping API. The developer reports that the sandbox environment always returns success, but the production API is returning 500 errors for 20% of requests. The vendor says "it\'s a known issue" with no ETA. What do you do?',
          choices: [
            { text: 'Wait for the vendor to fix the issue — it\'s their problem.' },
            { text: 'Escalate to the vendor\'s account manager for a formal SLA response, build a retry mechanism with graceful degradation as a parallel track, and assess the impact on the launch timeline.' },
            { text: 'Launch anyway — 80% success rate is acceptable.' },
            { text: 'Switch to a different shipping API provider immediately.' }
          ],
          correctIndex: 1,
          explanation: 'A 20% error rate on a shipping integration is a launch blocker — customers will not be able to complete orders 1 in 5 times. Three parallel actions are needed: (1) escalate to the vendor for a formal response with timeline, (2) build retry logic and graceful degradation so the 20% isn\'t visible as hard failures, and (3) assess timeline impact and communicate to stakeholders. Switching providers is a major decision that requires its own evaluation — not an immediate reaction.',
          competency: 'Integration Management',
          difficulty: 'hard'
        },
        {
          id: 'pc-tech-02',
          prompt: 'An engineer asks whether the team should use webhooks or polling to receive real-time inventory updates from the supplier\'s API. What factors help you guide this discussion?',
          choices: [
            { text: 'Always use webhooks — they are more modern.' },
            { text: 'Always use polling — it is simpler to implement.' },
            { text: 'Evaluate: Does the supplier\'s API support webhooks? How frequently do inventory changes occur? What is the acceptable latency for receiving updates?' },
            { text: 'Ask the supplier which option they prefer and use that.' }
          ],
          correctIndex: 2,
          explanation: 'Webhooks are ideal for real-time, event-driven updates (inventory changes happen irregularly) but require the supplier to support them and require your system to have a publicly accessible endpoint. Polling is simpler to implement but creates unnecessary load if changes are infrequent. The right choice depends on supplier capability, change frequency, and latency requirements — exactly the three factors in option C. A good TPM facilitates this evaluation rather than defaulting to a preference.',
          competency: 'API Literacy',
          difficulty: 'medium'
        },
        {
          id: 'pc-tech-03',
          prompt: 'Your product calls an external CRM API on every page load to fetch user profile data. The CRM provider announces they are increasing prices by 300% due to excessive API call volume. Engineering says the team can cache the data to reduce calls by 80%. What do you do?',
          choices: [
            { text: 'Accept the price increase — the integration is working.' },
            { text: 'Approve the caching implementation, estimate the cost savings vs. engineering effort, and present the business case to leadership before making a final decision.' },
            { text: 'Switch CRM providers immediately to avoid the price increase.' },
            { text: 'Remove the CRM integration entirely to avoid future pricing risk.' }
          ],
          correctIndex: 1,
          explanation: 'Caching is the right technical solution — an 80% call reduction would likely reduce costs by a similar factor. But approving engineering work requires a business case: how much does the caching work cost in engineering time vs. how much does it save in API costs? Present both numbers to leadership. Switching providers or removing the integration are major decisions requiring their own evaluation — not the first response to a pricing change.',
          competency: 'Integration Management',
          difficulty: 'medium'
        },
        {
          id: 'pc-tech-04',
          prompt: 'During an API contract review, the engineer discovers that the API documentation says the endpoint returns a response in 200ms, but actual sandbox testing shows 2,000ms response times. Your product\'s SLA is 500ms end-to-end. What do you do?',
          choices: [
            { text: 'Accept the 2,000ms — it\'s just the sandbox, production will be faster.' },
            { text: 'Flag this as a critical integration risk: the API response time violates the product SLA. Contact the vendor for a formal SLA commitment, and assess architectural alternatives (caching, async processing) with engineering.' },
            { text: 'Update the product SLA to match the API response time.' },
            { text: 'Ask engineering to optimize the API call to reduce response time.' }
          ],
          correctIndex: 1,
          explanation: 'A 10× gap between documented (200ms) and actual (2,000ms) performance is a significant discrepancy that cannot be dismissed as "sandbox lag." If production behaves similarly, your 500ms SLA is broken on day one. The right response: formally document the discrepancy, request a vendor SLA commitment in writing, and simultaneously explore architectural patterns (caching the API response, making the call asynchronously) that could decouple the API latency from the user-facing response time.',
          competency: 'Integration Management',
          difficulty: 'hard'
        },
        {
          id: 'pc-tech-05',
          prompt: 'A non-technical stakeholder asks: "What does it mean when the engineering team says the external API is down?" How do you explain it?',
          choices: [
            { text: '"It means the engineering team made a coding mistake that broke the connection."' },
            { text: '"It means a system we depend on — owned by another company — is temporarily not responding. Until they fix it, features that use it will not work. Our team cannot fix this directly — we\'re waiting on the provider."' },
            { text: '"It means the internet is not working."' },
            { text: '"It\'s a technical issue — I\'ll have the engineering team explain it."' }
          ],
          correctIndex: 1,
          explanation: 'A TPM\'s job includes translating technical realities into stakeholder-accessible language. Option B is accurate, non-technical, and correctly sets expectations: the problem is external, our team cannot fix it, and affected features are temporarily unavailable. It also implicitly communicates the urgency of the vendor relationship. Deflecting to the engineering team (option D) is a missed opportunity — and signals that you don\'t understand the situation.',
          competency: 'Technical Communication',
          difficulty: 'easy'
        }
      ]
    },

    interview: {
      questions: [
        {
          id: 'iq-tech-01',
          question: 'Tell me about a project where a third-party API or integration caused significant problems. How did you handle it?',
          difficulty: 'medium',
          competency: 'Integration Management',
          star: {
            situation: 'We were building a real-time financial data feature for a FinTech platform, integrating with a major market data provider\'s API. Three weeks before launch, we discovered that the API\'s response time in production averaged 1,800ms — nine times slower than the 200ms stated in the documentation. Our UX required a sub-500ms response.',
            task: 'I needed to evaluate our options, make a recommendation to the engineering and product team, and protect the launch timeline if possible.',
            action: 'I immediately scheduled a call with the vendor\'s technical account manager, presented the performance data, and requested both a formal SLA commitment and an explanation of the discrepancy. Simultaneously, I facilitated a 90-minute session with engineering to evaluate three architectural alternatives: caching the market data with a 15-second refresh interval, making the API call asynchronously and showing a loading state while data fetched, and pre-fetching data for the most common user views. The engineering team recommended the async approach with a skeleton loader — it preserved real-time feel without hard-blocking on the API response. The vendor eventually confirmed the 1,800ms was a known issue affecting their v1 API, which was being resolved in v2 (2 weeks away). We implemented the async approach as our primary strategy and planned the v2 migration as a follow-up sprint.',
            result: 'We launched on time with the async design, which actually received positive user feedback — the skeleton loader felt more responsive than a frozen screen waiting for data. The v2 migration was completed 3 weeks after launch with zero user impact.',
            keyMessage: 'Third-party integrations will disappoint you. The question is whether you discover the problem at sprint planning or at launch. Early API contract validation and parallel architectural thinking are what turn a launch-blocking problem into a manageable engineering tradeoff.'
          },
          tips: [
            'The 90-minute architectural session with three alternatives shows PM initiative — you didn\'t just escalate to the vendor, you also created internal options.',
            'The v2 migration planned as a follow-up sprint shows forward thinking beyond the immediate crisis.',
            'The unexpected positive — users liked the skeleton loader — is a great detail that shows how good decisions sometimes produce better outcomes than the original plan.'
          ]
        },
        {
          id: 'iq-tech-02',
          question: 'How do you communicate technical concepts to non-technical stakeholders?',
          difficulty: 'easy',
          competency: 'Technical Communication',
          star: {
            situation: 'This is a pattern I apply constantly. The clearest example was when I needed to explain to a Chief Commercial Officer why a planned feature would take 6 weeks instead of the 2 she was expecting.',
            task: 'The feature required integration with a third-party payment processor. The CCO did not have a technical background and had publicly committed the feature to a major client based on the original 2-week estimate.',
            action: 'I asked for a 20-minute 1:1 with the CCO. Instead of explaining the technical complexity directly, I used an analogy she could relate to: "Building this integration is like adding a new payment terminal to a restaurant. We\'re not just buying the terminal — we\'re rewiring the POS system, testing every transaction type, training staff, and getting the security audit done before we can run a single live payment. The terminal itself takes a day; the surrounding infrastructure takes six weeks." I then showed her a simple visual with three milestones: contract validation (week 1), development and testing (weeks 2–5), and production readiness (week 6). I also gave her two options: the 6-week full integration or a 2-week partial release with manual processing for the client, which we could automate in the follow-up sprint.',
            result: 'The CCO chose the 2-week partial release for the client and communicated the automation timeline herself. She later said the analogy had helped her explain it internally. The full integration launched on week 6 as planned.',
            keyMessage: 'Technical communication works when it starts from the stakeholder\'s world, not the engineering team\'s. Find an analogy that maps to their experience, make the complexity visible without overwhelming it, and always offer options with tradeoffs — not just a timeline change.'
          },
          tips: [
            'The restaurant terminal analogy is strong and transferable — interviewers may ask you to use a similar approach in a whiteboard exercise.',
            'The two-option framing (6-week full vs. 2-week partial) is the PM move that saved the stakeholder relationship.',
            'The CCO using the analogy internally is concrete evidence of successful communication.'
          ]
        }
      ]
    }
  },


  // ══════════════════════════════════════════════════════════════════════════
  // PACKAGE 10 — DevOps, CI/CD & Production Incidents
  // Competencies: DevOps Fundamentals · CI/CD · Incident Management
  // ══════════════════════════════════════════════════════════════════════════
  {
    id: 'PKG-DEVOPS',
    name: 'DevOps, CI/CD & Production Incidents',
    icon: '⚙️',
    level: 'Intermediate',
    description: 'Understand the systems that ship software and break production — before a crisis requires you to.',
    competencies: { 'DevOps Fundamentals': 12, 'CI/CD': 10, 'Incident Management': 10 },

    learn: {
      id: 'T10',
      title: 'DevOps, CI/CD & Production Incidents',
      icon: '⚙️',
      description: 'Understand the systems that ship software and break production — before a crisis requires you to.',
      level: 'Intermediate',
      experiences: [
        {
          id: 'T10-01',
          title: 'The CI/CD Pipeline',
          objective: 'Understand what happens between a code merge and a production deployment.',
          duration: '9 min',
          status: 'available',
          competencies: { 'CI/CD': 12, 'DevOps Fundamentals': 8 },
          phases: [
            {
              type: 'classify',
              label: 'Challenge',
              title: 'Which Pipeline Stage?',
              instruction: 'A CI/CD pipeline moves code from a developer\'s commit to production through several stages. Match each activity to the stage where it belongs.',
              mentorIntro: 'CI/CD vocabulary comes up constantly in Technical PM interviews. Let\'s build your mental model before diving into concepts.',
              categories: [
                { id: 'ci', label: 'Continuous Integration', icon: '🔨' },
                { id: 'cd', label: 'Continuous Delivery/Deploy', icon: '🚀' }
              ],
              items: [
                { text: 'Running 800 unit tests automatically every time a developer pushes code to the main branch', correct: 'ci', feedbackCorrect: 'Right. Automated test execution on every commit is the core of Continuous Integration — catching bugs at the source before they reach any other environment.', feedbackWrong: 'Automated testing on every code push is Continuous Integration at work. It validates that new code doesn\'t break existing functionality before it moves further in the pipeline.' },
                { text: 'Deploying a tested build automatically to the staging environment after all tests pass', correct: 'cd', feedbackCorrect: 'Correct. Deploying a validated build to a downstream environment (staging, pre-production, or production) is the Continuous Delivery/Deployment phase.', feedbackWrong: 'Deploying to any downstream environment (staging, pre-prod, production) after tests pass is the CD phase. The build is ready — now it moves toward production.' },
                { text: 'A static code analysis tool scanning the new code for security vulnerabilities and code quality issues', correct: 'ci', feedbackCorrect: 'Yes. Static analysis runs as part of the CI process — it validates the code itself before it\'s built and tested in downstream environments.', feedbackWrong: 'Static code analysis (SAST) runs on the code itself, early in the pipeline, before deployment. That\'s a CI-stage activity.' },
                { text: 'Performing a blue-green traffic switch that routes 100% of production traffic from the old version to the new one', correct: 'cd', feedbackCorrect: 'Correct. Blue-green traffic switching is a deployment strategy — it happens in the CD phase when the validated build reaches production.', feedbackWrong: 'Switching production traffic is a deployment activity. That happens at the end of the CD phase, after the build has passed all prior stages.' }
              ]
            },
            {
              type: 'reading',
              label: 'Concepts',
              title: 'CI/CD for Technical PMs',
              mentorIntro: 'Now you have a feel for the stages. Here\'s the conceptual framework that makes all of it make sense.',
              sections: [
                { heading: 'What CI/CD Is and Why It Matters', body: 'CI/CD stands for Continuous Integration / Continuous Delivery (or Deployment). It is the practice of automating the steps between a developer committing code and that code running in production.<br><br>Without CI/CD: developers merge code infrequently, integration problems accumulate, deployments are manual and error-prone, and releases are high-risk events happening once a month. With CI/CD: code merges happen daily, problems are caught immediately, deployments are automated and repeatable, and releases become low-risk routine events.' },
                { heading: 'The Pipeline Stages', body: 'A typical CI/CD pipeline progresses through these stages:<br><br><strong>1. Code Commit</strong> — developer pushes code to a shared branch<br><strong>2. Build</strong> — the code is compiled into an executable artifact<br><strong>3. Unit Tests</strong> — automated tests verify individual components<br><strong>4. Static Analysis</strong> — security and code quality scans<br><strong>5. Integration Tests</strong> — tests verify that components work together<br><strong>6. Staging Deployment</strong> — the artifact is deployed to a production-like environment<br><strong>7. Acceptance Tests</strong> — end-to-end tests simulate real user flows<br><strong>8. Production Deployment</strong> — the artifact is deployed to production, often gated by manual approval<br><br>A failure at any stage stops the pipeline. This is intentional — problems are cheaper to fix early.' },
                { heading: 'What TPMs Care About in CI/CD', body: 'Three CI/CD metrics that affect delivery decisions:<br><br><strong>Build time</strong> — if the pipeline takes 45 minutes per run and developers are waiting, this is a productivity tax. Slow pipelines reduce the team\'s ability to iterate.<br><br><strong>Test coverage</strong> — what percentage of the code is tested by automated tests? Low coverage means more bugs reach production. High coverage with slow tests slows delivery.<br><br><strong>Deployment frequency</strong> — how often does code reach production? Daily deployments reduce batch size and risk. Monthly deployments increase both. This is one of the four DORA metrics used to measure DevOps performance.' }
              ]
            },
            {
              type: 'keyTakeaway',
              label: 'Takeaway',
              text: 'CI/CD turns deployment from a risky event into a routine operation. Every stage is a risk checkpoint — understand them to make better delivery decisions.',
              mentorNote: 'Interviewers who build software teams will immediately know if you understand CI/CD. The four DORA metrics (deployment frequency, lead time, MTTR, change failure rate) are worth knowing cold.',
              xp: 25
            }
          ]
        },

        {
          id: 'T10-02',
          title: 'Production Incidents',
          objective: 'Lead through a production incident — from first alert to blameless postmortem.',
          duration: '10 min',
          status: 'available',
          competencies: { 'Incident Management': 12, 'DevOps Fundamentals': 8 },
          phases: [
            {
              type: 'reading',
              label: 'Concepts',
              title: 'Production Incident Management',
              mentorIntro: 'Production incidents are the highest-stakes moments in software delivery. How a team handles them reveals everything about their culture and leadership.',
              sections: [
                { heading: 'The Incident Lifecycle', body: 'A production incident typically follows five phases:<br><br><strong>1. Detection</strong> — the problem is identified, either by monitoring alerts or user reports. Fast detection requires good observability: logs, metrics, and alerts configured for the right signals.<br><br><strong>2. Assessment</strong> — how severe is it? Who is affected? What is the business impact? This determines the response priority and who needs to be involved.<br><br><strong>3. Containment</strong> — stop the bleeding. This might mean rolling back a deployment, disabling a feature flag, or scaling up infrastructure. The goal is to reduce user impact as fast as possible.<br><br><strong>4. Resolution</strong> — fix the root cause. This takes longer than containment and happens after users are no longer impacted.<br><br><strong>5. Postmortem</strong> — a structured review of what happened, why, and what needs to change to prevent recurrence.' },
                { heading: 'The TPM\'s Role in an Incident', body: 'During an incident, the TPM is the incident coordinator — not the engineer. While engineers diagnose and fix, the TPM owns three things:<br><br><strong>Communication</strong> — internal stakeholders (leadership, Customer Success, Support) and external (status page updates, customer notifications) need timely, accurate, non-technical information about what\'s happening and when it will be resolved.<br><br><strong>Documentation</strong> — maintain a running incident log: timeline of events, actions taken, decisions made. This becomes the raw material for the postmortem.<br><br><strong>Coordination</strong> — make sure the right people are in the incident bridge, prevent the "too many cooks" failure mode, and clear obstacles for the engineers doing the technical work.' },
                { heading: 'The Blameless Postmortem', body: 'A postmortem is not a blame session. It is a structured learning exercise. Blameless postmortems operate on the principle that people made reasonable decisions given what they knew at the time — and that systems, processes, and tooling, not individuals, are the root causes that need to be addressed.<br><br>A postmortem typically covers: timeline of the incident, root cause analysis (the "5 Whys"), contributing factors, business impact (duration, affected users, revenue impact), and action items with owners and deadlines. The action items are what makes a postmortem valuable — insights without commitments are just documentation.' }
              ]
            },
            {
              type: 'quiz',
              label: 'Quiz',
              title: 'Incident Response Check',
              mentorIntro: 'Three scenarios from real production incidents.',
              questions: [
                { question: 'Your platform is experiencing a critical outage. The engineering team says they need 45 minutes to diagnose the root cause before they can fix it. What should the TPM be doing during those 45 minutes?', options: [ { text: 'Wait for the engineering team to finish before communicating anything.', correct: false, feedback: 'Waiting 45 minutes to communicate during a critical outage is too long. Stakeholders and customers need acknowledgment within minutes.' }, { text: 'Send a status page update acknowledging the incident, notify internal stakeholders with a brief impact summary, and maintain a running incident log.', correct: true, feedback: 'Correct. The TPM\'s role during engineering diagnosis is communication and coordination, not technical involvement. Status page update, internal notification, and incident logging all happen in parallel with engineering.' }, { text: 'Ask the engineering team to pause diagnosis and explain the root cause to stakeholders first.', correct: false, feedback: 'Interrupting engineers during diagnosis to explain to stakeholders is counterproductive. The TPM communicates; engineering diagnoses.' }, { text: 'Escalate to the CTO immediately to inform them of the outage.', correct: false, feedback: 'Executive escalation depends on severity and duration. In the first 45 minutes of diagnosis, escalate to your direct manager and let them decide if the CTO needs to know. Don\'t escalate reactively.' } ] },
                { question: 'After a major production incident, the VP of Engineering suggests the team should "figure out who was responsible and make sure it doesn\'t happen again." What is the TPM\'s most effective response?', options: [ { text: 'Support the approach — accountability is important.', correct: false, feedback: 'Blame-focused reviews identify a person to blame, not a system to fix. Individual blame does not produce systemic improvement.' }, { text: 'Propose a blameless postmortem that focuses on the system, process, and tooling gaps that allowed the incident to occur — not on individual error.', correct: true, feedback: 'Correct. Blameless postmortems produce better outcomes: people share information candidly, root causes are identified accurately, and action items address the real problem. Blame creates silence and cover-up behavior.' }, { text: 'Agree with the VP but run a separate blameless postmortem privately.', correct: false, feedback: 'Running parallel processes creates confusion and undermines the team\'s psychological safety. Advocate for the blameless approach directly.' }, { text: 'Skip the postmortem and focus on the next sprint instead.', correct: false, feedback: 'Incidents without postmortems tend to recur. The postmortem is where institutional learning happens — skipping it is skipping the improvement.' } ] },
                { question: 'MTTR stands for Mean Time to Restore. Which situation represents a team with good MTTR performance?', options: [ { text: 'The team has had zero production incidents in the past year.', correct: false, feedback: 'Zero incidents may indicate underreporting, not good MTTR. MTTR measures how fast you recover when incidents occur — not how often.' }, { text: 'When production incidents occur, the team restores service in an average of 12 minutes through automated rollback and fast diagnosis.', correct: true, feedback: 'Correct. Good MTTR is about fast recovery capability: monitoring alerts quickly, diagnostic tooling that surfaces root causes fast, and automated recovery actions like rollback.' }, { text: 'The team deploys to production only once a month to minimize incident frequency.', correct: false, feedback: 'Low deployment frequency reduces incidents in the short term but accumulates risk. Good MTTR is about fast recovery, not avoiding deployments.' }, { text: 'The team resolves incidents during business hours by escalating to a senior engineer.', correct: false, feedback: 'Business-hours-only response with manual escalation is a slow recovery process. Good MTTR requires 24/7 on-call response capability and automated detection.' } ] }
              ]
            },
            {
              type: 'keyTakeaway',
              label: 'Takeaway',
              text: 'During an incident: engineers fix, TPM communicates and coordinates. After an incident: run a blameless postmortem with action items, not a blame session.',
              mentorNote: 'The four DORA metrics (deployment frequency, lead time to change, MTTR, change failure rate) are the language of high-performing engineering teams. Know them.',
              xp: 30
            }
          ]
        }
      ]
    },

    practice: {
      challenges: [
        {
          id: 'pc-devops-01',
          prompt: 'The CI/CD pipeline now takes 52 minutes to complete per commit. Developers are merging less frequently to avoid the wait, which means larger, riskier merges. What should you do?',
          choices: [
            { text: 'Accept it — a thorough pipeline is more important than speed.' },
            { text: 'Ask the engineering team to analyze which stages are slowest and propose optimizations, then prioritize the work in the backlog and set a target pipeline time.' },
            { text: 'Tell developers to merge more frequently despite the wait time.' },
            { text: 'Skip the pipeline for "trusted" developers\' commits to save time.' }
          ],
          correctIndex: 1,
          explanation: 'A 52-minute pipeline is causing behavioral changes that increase risk — less frequent merges mean larger integration deltas and harder conflict resolution. This is a delivery infrastructure problem that belongs in the backlog with clear ownership. Common optimizations: parallel test execution, test suite pruning, caching build dependencies, splitting the pipeline into a fast feedback loop (< 5 min) and a full suite. Set a target (10–15 minutes is typical) and track progress.',
          competency: 'DevOps Fundamentals',
          difficulty: 'medium'
        },
        {
          id: 'pc-devops-02',
          prompt: 'At 2am, the on-call engineer pages you: the payment service is returning 500 errors for 35% of transactions. They haven\'t found the root cause yet. What do you do in the next 10 minutes?',
          choices: [
            { text: 'Wait for the engineer to find the root cause before taking any action.' },
            { text: 'Ask the engineer to roll back the last deployment immediately to restore service, regardless of root cause.' },
            { text: 'Post a status page update acknowledging an incident, notify the on-call Customer Success lead, and ask the engineer: "Is the last deployment the likely cause? If so, initiate rollback while we investigate."' },
            { text: 'Contact the CEO to inform them of the incident.' }
          ],
          correctIndex: 2,
          explanation: 'In the first 10 minutes of a severity-1 incident: (1) acknowledge publicly on the status page, (2) notify the internal stakeholders who need to know immediately (Customer Success, not the CEO yet), and (3) guide the engineer toward the fastest recovery path. If the last deployment is the likely cause, rollback while investigating is almost always faster than finding the root cause first. Recovery before root cause — always.',
          competency: 'Incident Management',
          difficulty: 'hard'
        },
        {
          id: 'pc-devops-03',
          prompt: 'Your team wants to increase deployment frequency from monthly to weekly. The QA team says they can\'t run full regression manually every week. What should you recommend?',
          choices: [
            { text: 'Keep monthly deployments — the QA team\'s capacity limits the frequency.' },
            { text: 'Deploy weekly without regression testing.' },
            { text: 'Invest in automated regression testing as a prerequisite for weekly deployments — and prioritize this in the next sprint as a delivery enabler.' },
            { text: 'Hire more QA engineers to run manual regression weekly.' }
          ],
          correctIndex: 2,
          explanation: 'Manual regression doesn\'t scale with deployment frequency — this is the exact problem that automated testing solves. Higher deployment frequency is a quality improvement (smaller batches, faster feedback) but it requires the investment in automation first. Framing automated regression as a "delivery enabler" — something that unlocks higher frequency deployments, not just a cost — is the right way to prioritize it in the backlog.',
          competency: 'DevOps Fundamentals',
          difficulty: 'medium'
        },
        {
          id: 'pc-devops-04',
          prompt: 'Two weeks after a major production incident, the engineering team has not completed the postmortem action items. A similar incident just occurred. How do you respond?',
          choices: [
            { text: 'Run a new postmortem for the new incident and start fresh.' },
            { text: 'Escalate the missed action items to the Engineering Manager, establish a formal owner and deadline for each item, and add them to the current sprint as priority work.' },
            { text: 'Accept that some incidents are unavoidable and move on.' },
            { text: 'Ask the team to work overtime until the action items are complete.' }
          ],
          correctIndex: 1,
          explanation: 'Unexecuted postmortem action items are a systemic risk — the team identified what needs to change but didn\'t change it, and now the same failure recurred. The right response: treat the action items as sprint-priority work with specific owners and deadlines. Escalate to the Engineering Manager if the items are not being prioritized. A postmortem without completed action items is a documentation exercise, not a learning exercise.',
          competency: 'Incident Management',
          difficulty: 'hard'
        },
        {
          id: 'pc-devops-05',
          prompt: 'The team\'s change failure rate (percentage of deployments causing incidents) is 25% over the last quarter. Industry benchmark is below 15%. What does this signal and what do you recommend?',
          choices: [
            { text: 'The team is deploying too frequently — reduce to monthly to lower the failure rate.' },
            { text: 'The team needs more testing — require manual QA sign-off before every deployment.' },
            { text: 'This signals insufficient test coverage and/or pre-production environment gaps. Recommend a sprint focused on test coverage, pipeline quality gates, and staging environment fidelity.' },
            { text: 'The benchmark is aspirational — 25% is acceptable for a fast-moving team.' }
          ],
          correctIndex: 2,
          explanation: 'A 25% change failure rate means 1 in 4 deployments causes an incident — significantly above the 15% benchmark. Reducing deployment frequency doesn\'t fix the underlying quality problem; it just delays the pain. The root causes are almost always: insufficient automated test coverage, staging environment that doesn\'t reflect production, or missing quality gates in the pipeline. A sprint focused on test coverage and pipeline hardening addresses the root cause. "Fast-moving teams" with 25% failure rates aren\'t fast — they\'re spending time on incident recovery instead of features.',
          competency: 'DevOps Fundamentals',
          difficulty: 'hard'
        }
      ]
    },

    interview: {
      questions: [
        {
          id: 'iq-devops-01',
          question: 'Tell me about a production incident you managed. What was your role and what did you learn?',
          difficulty: 'medium',
          competency: 'Incident Management',
          star: {
            situation: 'Our SaaS platform experienced a Severity-1 outage on a Tuesday morning. The authentication service was failing for 40% of users attempting to log in. The incident lasted 47 minutes from detection to full recovery.',
            task: 'I was the incident coordinator — not an engineer. My job was to manage communication, coordinate the response team, and ensure the postmortem produced real improvements.',
            action: 'Within 5 minutes of the alert, I opened the incident bridge, posted a status page update (acknowledging the incident, impact, and "investigating"), and notified Customer Success and the VP of Engineering with a one-paragraph brief. I designated one engineer as the diagnostic lead to prevent the "too many cooks" problem and asked everyone else to observe on the bridge rather than suggest fixes simultaneously. I maintained a running incident log timestamping every action and decision. At minute 23, the diagnostic lead identified the cause: a misconfigured rate limiting rule that had been deployed 2 hours earlier. We rolled back the configuration. Service restored at minute 47. I ran the postmortem 48 hours later — blameless, structured, with 5 action items all assigned to named owners with 2-week deadlines.',
            result: 'All 5 postmortem action items were completed within 2 weeks. One of them — adding the rate limiting configuration to the automated test suite — directly prevented a recurrence 6 weeks later when a similar misconfiguration was caught in CI before it reached production.',
            keyMessage: 'The TPM\'s value in an incident isn\'t technical — it\'s the coordination, communication, and documentation that lets engineers focus on fixing the problem. The postmortem is where the incident becomes an improvement.'
          },
          tips: [
            'The "too many cooks" detail and the single diagnostic lead assignment show mature incident management thinking.',
            'The specific metric (47 minutes, 40% of users) makes the story credible and concrete.',
            'The follow-up prevention (CI caught the recurrence) is the most compelling outcome — it shows the postmortem actually worked.'
          ]
        },
        {
          id: 'iq-devops-02',
          question: 'How do you explain CI/CD to a non-technical stakeholder?',
          difficulty: 'easy',
          competency: 'DevOps Fundamentals',
          star: {
            situation: 'A CFO was questioning why the engineering team needed to invest time building "deployment automation" instead of delivering features. She didn\'t have a technical background.',
            task: 'I needed to explain the business value of CI/CD investment in terms she would find compelling — without technical jargon.',
            action: 'I used a manufacturing analogy. "Imagine a factory that assembles products by hand at the end of every month. Each assembly takes 2 full days, involves 10 people, and frequently produces defects discovered only after the product ships to customers. Now imagine that same factory with automated assembly lines: products are assembled continuously throughout the month, defects are caught immediately on the line before shipping, and the assembly process takes hours instead of days. CI/CD is the automated assembly line for software. Right now, we deploy once a month — a 2-day manual process that frequently causes customer-facing issues. With CI/CD, we deploy weekly with automated quality checks, and problems are caught before they reach customers." I then showed a 6-month projection: CI/CD investment cost (sprint time) vs. incident reduction, support ticket reduction, and deployment speed improvement.',
            result: 'The CFO approved the CI/CD sprint. She later referenced the factory analogy in a board presentation when explaining the engineering investment strategy.',
            keyMessage: 'The best technical explanations for executives connect technology to business outcomes through an analogy from their world. The factory line analogy worked because it made quality, speed, and cost all visible simultaneously.'
          },
          tips: [
            'The factory assembly line analogy is memorable — interviewers may ask you to use it in a role-play exercise.',
            'The 6-month projection comparing investment vs. operational savings shows business acumen, not just technical literacy.',
            'The CFO reusing the analogy in a board meeting is the ultimate communication success indicator.'
          ]
        }
      ]
    }
  },


  // ══════════════════════════════════════════════════════════════════════════
  // PACKAGE 11 — Technical Debt Management
  // Competencies: Technical Debt · Prioritization · Stakeholder Management
  // ══════════════════════════════════════════════════════════════════════════
  {
    id: 'PKG-TECHDEBT',
    name: 'Technical Debt Management',
    icon: '🏗️',
    level: 'Advanced',
    description: 'Manage technical debt as a business risk — not as a developer complaint.',
    competencies: { 'Technical Debt': 12, 'Prioritization': 10, 'Stakeholder Management': 8 },

    learn: {
      id: 'T11',
      title: 'Technical Debt Management',
      icon: '🏗️',
      description: 'Manage technical debt as a business risk — not as a developer complaint.',
      level: 'Advanced',
      experiences: [
        {
          id: 'T11-01',
          title: 'Understanding Technical Debt',
          objective: 'Define technical debt, identify it in real project contexts, and communicate it to non-technical stakeholders.',
          duration: '9 min',
          status: 'available',
          competencies: { 'Technical Debt': 12, 'Stakeholder Management': 6 },
          phases: [
            {
              type: 'reading',
              label: 'Concepts',
              title: 'Technical Debt: The PM\'s Guide',
              mentorIntro: 'Technical debt is one of the most misunderstood topics in PM-engineering relationships. Get this right and you\'ll immediately earn credibility with engineering teams.',
              sections: [
                { heading: 'What Technical Debt Really Is', body: 'Technical debt is the accumulated cost of engineering shortcuts taken to move faster in the short term. It is not a bug — bugs are unintended failures. Debt is an intentional decision to accept a suboptimal solution now in exchange for short-term speed, with an implicit promise to revisit it later.<br><br>The "debt" metaphor is deliberate: like financial debt, technical debt accrues interest. The longer it goes unaddressed, the more expensive it becomes to work with — slower development, more bugs, higher onboarding cost for new engineers. And like financial debt, some amount of it is reasonable and strategic. The problem is when the interest exceeds your team\'s capacity to pay it.' },
                { heading: 'Four Types of Technical Debt', body: 'Not all technical debt is created equal. Ward Cunningham\'s debt quadrant describes four types:<br><br><strong>Prudent + Deliberate</strong> — "We know a better approach, but we\'re shipping now and will fix it in Q2." Intentional, documented, planned.<br><br><strong>Reckless + Deliberate</strong> — "We don\'t have time for design — just ship it." A warning sign. Creates unstable systems.<br><br><strong>Prudent + Inadvertent</strong> — "We didn\'t know the right approach when we built this. Now we do." Normal organizational learning.<br><br><strong>Reckless + Inadvertent</strong> — "We weren\'t thinking about design at all." The most dangerous type — creates unmaintainable code bases.' },
                { heading: 'Communicating Debt to Stakeholders', body: 'Engineers say: "We need to refactor the authentication service." Stakeholders hear: "The engineers want to rewrite code that already works."<br><br>The translation problem is real. To communicate technical debt effectively to non-technical stakeholders, connect it to three business metrics: <strong>velocity impact</strong> ("Every feature in this module takes 40% longer to build than comparable features elsewhere"), <strong>reliability risk</strong> ("This service is responsible for 60% of our P1 incidents in the past 6 months"), and <strong>cost of delay</strong> ("Not addressing this now means the Q4 platform expansion will require 3× the engineering effort").' }
              ]
            },
            {
              type: 'quiz',
              label: 'Quiz',
              title: 'Technical Debt Check',
              mentorIntro: 'Questions on recognizing and communicating technical debt in real project contexts.',
              questions: [
                { question: 'An engineering team says they need one full sprint to "refactor the payment service." A stakeholder says: "But it\'s working — why fix it?" What is the BEST response from the TPM?', options: [ { text: '"The engineering team says it\'s necessary — we should trust them."', correct: false, feedback: 'While trust is important, this answer doesn\'t help the stakeholder understand the business case. The TPM should translate the technical rationale into business impact.' }, { text: '"The payment service is functioning but is responsible for 45% of our production incidents. Addressing the debt now costs 1 sprint. Leaving it untouched will cost us 2–3 additional sprints in incident response over the next quarter."', correct: true, feedback: 'Correct. This translates the technical debt into business terms the stakeholder can evaluate: incident cost, future velocity impact, and a clear cost-of-delay argument.' }, { text: '"You\'re right — if it\'s working, we should focus on new features."', correct: false, feedback: 'Agreeing with the stakeholder without evaluating the engineering case is a PM failure. Technical debt has real business costs that must be quantified.' }, { text: '"The engineering team is frustrated — we need to give them this sprint to stay motivated."', correct: false, feedback: 'Framing technical debt work as a morale decision undermines the business case. Engineers deserve better advocacy than "they need a win."' } ] },
                { question: 'A team builds a feature quickly by copying and modifying existing code in 8 places instead of creating a shared component. The feature ships on time. How should the TPM classify this?', options: [ { text: 'Not technical debt — the feature shipped on time.', correct: false, feedback: 'Shipping on time doesn\'t eliminate technical debt. The copy-paste approach creates 8 places to update whenever the logic changes, multiplying future maintenance cost.' }, { text: 'Reckless and inadvertent debt — the team didn\'t think about the design.', correct: false, feedback: 'The team likely knew there was a better approach (shared component) but chose speed. That makes this deliberate debt, not inadvertent.' }, { text: 'Prudent and deliberate debt — the team knowingly chose a faster approach to meet the deadline and should document it for future refactoring.', correct: true, feedback: 'Correct. If the team consciously chose speed over the optimal design and documented the decision, this is prudent deliberate debt — acceptable if managed. The critical step is to log it as a known debt item with a refactoring plan.' }, { text: 'Not the TPM\'s concern — technical architecture is the engineering team\'s responsibility.', correct: false, feedback: 'Technical debt is a delivery risk — it slows future velocity and increases incident probability. The TPM is responsible for understanding and communicating that risk.' } ] }
              ]
            },
            {
              type: 'keyTakeaway',
              label: 'Takeaway',
              text: 'Technical debt is a business risk, not a technical complaint. Translate it into velocity impact, reliability risk, and cost of delay — then manage it intentionally.',
              mentorNote: 'The ability to speak about technical debt in business terms is a major differentiator in TPM interviews. Most candidates can name it. Few can quantify it.',
              xp: 30
            }
          ]
        },

        {
          id: 'T11-02',
          title: 'Prioritizing Debt Against Features',
          objective: 'Make data-driven decisions about when to pay down technical debt vs. deliver new features.',
          duration: '8 min',
          status: 'available',
          competencies: { 'Technical Debt': 10, 'Prioritization': 12 },
          phases: [
            {
              type: 'reading',
              label: 'Concepts',
              title: 'The Debt vs. Feature Decision',
              mentorIntro: 'This is one of the most common TPM-PO tensions. Here\'s how to navigate it with data.',
              sections: [
                { heading: 'Why This Decision Is Hard', body: 'New features generate visible business value: new users, new revenue, new capabilities. Technical debt paydown generates invisible business value: fewer future incidents, faster future development, lower future cost. Stakeholders can see features. They cannot see the incidents that don\'t happen and the sprints that don\'t slow down because the debt was paid.<br><br>The PM who can make invisible value visible — through incident data, velocity trends, and cost projections — is the PM who wins this conversation.' },
                { heading: 'The 20% Rule and Other Frameworks', body: 'Several teams use a fixed allocation: 20% of each sprint is reserved for technical debt, regardless of feature demand. This has a key advantage — it makes debt paydown a constant, predictable commitment rather than a "someday" promise.<br><br>An alternative is the debt threshold framework: when debt items cross a severity threshold (e.g., responsible for more than 20% of incidents, or causing more than 15% velocity reduction), they are automatically elevated to sprint priority regardless of competing feature demand.<br><br>Both frameworks share a principle: technical debt must be addressed through a system, not through ad hoc negotiation sprint by sprint. Ad hoc negotiation always loses to feature pressure.' },
                { heading: 'Making the Case', body: 'The most compelling argument for prioritizing debt paydown is historical incident data. "This service caused 7 P1 incidents in the past quarter, each requiring 4–6 hours of engineering time to resolve. That\'s up to 42 hours of reactive work. One 2-sprint refactor would reduce this service\'s incident rate by 80% based on engineering assessment."<br><br>Connect debt to hiring and retention too: engineering teams that work in deeply indebted codebases have higher turnover. The cost of replacing an engineer (3–6 months of productivity loss) is often more than the debt paydown cost.' }
              ]
            },
            {
              type: 'keyTakeaway',
              label: 'Takeaway',
              text: 'Debt paydown is a system decision, not a sprint-by-sprint negotiation. Make invisible costs visible through incident data and velocity impact — then commit to a framework.',
              mentorNote: 'The 20% rule and the debt threshold framework are both real, widely used approaches. Know both for interviews — you will be asked how you balance debt vs. features.',
              xp: 25
            }
          ]
        }
      ]
    },

    practice: {
      challenges: [
        {
          id: 'pc-debt-01',
          prompt: 'The engineering team says the checkout service has accumulated so much technical debt that every new feature takes 3× longer than it should. The Product Owner wants to ship 4 new checkout features next quarter. How do you facilitate this decision?',
          choices: [
            { text: 'Ship the 4 features as planned — the PO has the business priority.' },
            { text: 'Quantify the debt impact: estimate how many sprints the features would take with vs. without debt, present the cost of delay for refactoring vs. the cost of working with debt, and help the PO make an informed tradeoff decision.' },
            { text: 'Defer all 4 features until the debt is resolved.' },
            { text: 'Ask engineering to work faster to deliver both.' }
          ],
          correctIndex: 1,
          explanation: 'This is a tradeoff decision that belongs to the PO — but only after they have the data. If each feature takes 3× longer due to debt, 4 features might take 12 sprints instead of 4. A 2-sprint refactor might reduce that to 5 sprints total. Presenting these numbers transforms the "features vs. debt" debate into a cost-benefit analysis. The PO can then make an informed decision — not an opinion-based one.',
          competency: 'Technical Debt',
          difficulty: 'hard'
        },
        {
          id: 'pc-debt-02',
          prompt: 'An engineer approaches you privately and says: "The codebase is a mess. I\'m thinking of leaving if nothing changes." How do you respond?',
          choices: [
            { text: 'Tell them to raise the issue in the next team retrospective.' },
            { text: 'Acknowledge the concern seriously, ask them to help you quantify the business impact of the debt (incidents, velocity), and commit to bringing it to leadership with a business case — not just as an engineer complaint.' },
            { text: 'Escalate to the Engineering Manager immediately.' },
            { text: 'Tell them that all codebases have some debt and it will improve over time.' }
          ],
          correctIndex: 1,
          explanation: 'An engineer expressing intent to leave is a retention signal that the TPM should take seriously. The right response is two-fold: (1) show the engineer that their concern is being taken seriously with concrete action, and (2) convert the qualitative complaint into quantifiable business impact data. "The codebase is a mess" cannot be prioritized; "debt in the payment service caused 7 P1 incidents costing 40 engineering hours in Q3" can be.',
          competency: 'Technical Debt',
          difficulty: 'medium'
        },
        {
          id: 'pc-debt-03',
          prompt: 'Your team\'s velocity has dropped from 45 points per sprint 6 months ago to 28 points per sprint today. The team and codebase have not changed. What is the most likely explanation and what should you recommend?',
          choices: [
            { text: 'The team has become less motivated — implement a team recognition program.' },
            { text: 'The estimates were inaccurate 6 months ago and are more accurate now.' },
            { text: 'Technical debt is accumulating and increasing the cost of every task. Recommend a velocity trend analysis and a debt audit to identify the highest-impact areas.' },
            { text: 'Velocity naturally fluctuates — this is not a concern.' }
          ],
          correctIndex: 2,
          explanation: 'A 38% velocity reduction over 6 months with a stable team is a classic technical debt signal. As debt accumulates, tasks that used to be straightforward become complex because of dependencies, workarounds, and fragile code. The right response is to analyze: which areas of the codebase are most responsible for the velocity trend? A debt audit correlating with sprint velocity data will show the pattern. Then build the business case for targeted paydown.',
          competency: 'Technical Debt',
          difficulty: 'medium'
        },
        {
          id: 'pc-debt-04',
          prompt: 'The team adopts a "20% of sprint capacity for technical debt" rule. The Product Owner objects: "We\'re behind on the roadmap — we can\'t afford to lose 20% every sprint." How do you respond?',
          choices: [
            { text: 'Agree with the PO — the roadmap comes first.' },
            { text: 'Show the PO historical data: the team is spending more than 20% of capacity on incident response and workarounds caused by the debt. The 20% is a reallocation, not a cost.' },
            { text: 'Compromise on 10% and revisit in 2 sprints.' },
            { text: 'Escalate to the VP of Engineering to override the PO.' }
          ],
          correctIndex: 1,
          explanation: 'The 20% rule is not "giving up" 20% of capacity — it\'s explicitly budgeting for what the team is already spending reactively on debt-related incidents and workarounds. Show the data: if incident response and debt-related slowdown already consumes 25% of capacity, a 20% structured debt allocation actually improves net feature delivery. Data changes the framing from "sacrifice" to "investment."',
          competency: 'Prioritization',
          difficulty: 'hard'
        },
        {
          id: 'pc-debt-05',
          prompt: 'The engineering team wants to rewrite the entire core platform from scratch over 6 months. The current platform has significant debt but still functions. How do you evaluate this proposal?',
          choices: [
            { text: 'Approve it — if engineering says it needs a full rewrite, trust them.' },
            { text: 'Reject it — full rewrites are always too risky.' },
            { text: 'Evaluate carefully: What is the incremental alternative? What is the risk of the rewrite itself? Can the current platform support business needs during the rewrite? Present the rewrite vs. incremental refactoring tradeoffs to leadership.' },
            { text: 'Pilot the rewrite for one module and evaluate results before committing to 6 months.' }
          ],
          correctIndex: 2,
          explanation: 'Full rewrites are one of the highest-risk decisions in software development — they take longer than estimated, deliver no new value during the rewrite period, and frequently reproduce the same architectural mistakes. The TPM should evaluate: (1) what is the specific problem the rewrite solves that incremental refactoring cannot? (2) What is the business risk of a 6-month feature freeze? (3) What happens if the rewrite takes 12 months? Option D (pilot) is reasonable but the primary recommendation should be a thorough evaluation of alternatives before committing.',
          competency: 'Technical Debt',
          difficulty: 'hard'
        }
      ]
    },

    interview: {
      questions: [
        {
          id: 'iq-debt-01',
          question: 'How do you make the case for technical debt work to a Product Owner focused on new features?',
          difficulty: 'hard',
          competency: 'Technical Debt',
          star: {
            situation: 'Our engineering team had identified significant technical debt in the notification service — a system that sends emails, push notifications, and in-app messages. It was responsible for 40% of our production incidents despite being used in every user flow. The Product Owner\'s roadmap was packed with new features and she was skeptical of "refactoring" work.',
            task: 'I needed to build a business case that would shift the PO\'s priority without creating conflict — and that would hold up to scrutiny.',
            action: 'I pulled three months of incident data and traced every P1 and P2 incident to its originating service. The notification service appeared in 40% of them. I calculated the engineering hours spent on each incident: diagnosis, fix, postmortem, and user communication. The total for 3 months: 47 engineering hours — equivalent to 1.5 full sprints of capacity. Then I worked with the lead engineer to estimate the refactoring cost: 1.5 sprints. The math was undeniable: the debt was already costing the team 1.5 sprints per quarter in reactive work. Paying it down would cost 1.5 sprints once. I presented this as: "We\'re already paying for this. The only question is whether we pay it in a way that gets us a better system on the other side."',
            result: 'The PO approved a 2-sprint refactor. The notification service\'s P1 incident rate dropped by 75% in the following quarter. The engineering team went from dreading the service to actively improving it.',
            keyMessage: 'The winning argument for technical debt is not "engineers are unhappy" — it\'s "we\'re already spending the budget. Let\'s spend it on the version that makes us faster." Make the hidden cost visible with data, not sentiment.'
          },
          tips: [
            'The "we\'re already paying for it" framing is powerful — it reframes the debate from spending vs. not spending to spending reactively vs. proactively.',
            'The 47-hour vs. 1.5-sprint comparison is the specific data that makes the case — always quantify.',
            'The 75% incident reduction outcome validates the investment and can be used to justify future debt paydown decisions.'
          ]
        },
        {
          id: 'iq-debt-02',
          question: 'Tell me about a time you had to balance new features against technical improvements. How did you decide?',
          difficulty: 'medium',
          competency: 'Prioritization',
          star: {
            situation: 'Midway through a 6-month product delivery, the engineering team surfaced that the authentication module had been built with an outdated session management approach that created security risk and was significantly slowing new feature development in any area that required user login.',
            task: 'I had to facilitate a prioritization decision between addressing the authentication debt (estimated 3 weeks) and the stakeholder-committed feature roadmap.',
            action: 'I ran a joint session with the PO, Engineering Lead, and Security Lead. I presented two scenarios with honest projections: Scenario A — continue as planned, deliver all features on the committed timeline, but accept 3 security risk items flagged by the Security Lead and a 25% velocity reduction for all authentication-adjacent features in the next quarter. Scenario B — invest 3 weeks now, reduce the authentication-adjacent velocity tax from 25% to near-zero, and resolve the security findings before they became incidents. I was careful not to advocate — I presented the data, including a risk quantification from the Security Lead, and let the stakeholders decide. They chose Scenario B.',
            result: 'The 3-week investment reduced authentication-related development time by an estimated 30% for the next 6 months. One of the security findings we resolved had been exploited in a similar product at a competitor company the following quarter — a risk we had eliminated.',
            keyMessage: 'Balancing debt vs. features is a decision, not a debate. Make both scenarios honest, make both costs visible, and let the stakeholders who own the outcome make the call with complete information.'
          },
          tips: [
            'The two-scenario format (A vs. B with honest projections for both) is a mature PM facilitation approach.',
            'Not advocating — presenting data and letting stakeholders decide — shows the PM\'s role in decision facilitation vs. decision-making.',
            'The competitor security incident detail makes the security risk concrete and memorable.'
          ]
        }
      ]
    }
  },


  // ══════════════════════════════════════════════════════════════════════════
  // PACKAGE 12 — AI for Technical Project Managers
  // Competencies: AI Literacy · AI Project Management · Product Thinking
  // ══════════════════════════════════════════════════════════════════════════
  {
    id: 'PKG-AI',
    name: 'AI for Project Managers',
    icon: '🤖',
    level: 'Intermediate',
    description: 'Lead AI-powered product development with confidence — from LLM concepts to responsible delivery.',
    competencies: { 'AI Literacy': 12, 'AI Project Management': 10, 'Product Thinking': 8 },

    learn: {
      id: 'T12',
      title: 'AI for Project Managers',
      icon: '🤖',
      description: 'Lead AI-powered product development with confidence — from LLM concepts to responsible delivery.',
      level: 'Intermediate',
      experiences: [
        {
          id: 'T12-01',
          title: 'AI Fundamentals for PMs',
          objective: 'Understand how AI and LLMs work at the conceptual level needed to manage AI-powered projects.',
          duration: '10 min',
          status: 'available',
          competencies: { 'AI Literacy': 12, 'Product Thinking': 6 },
          phases: [
            {
              type: 'classify',
              label: 'Challenge',
              title: 'AI Capability or AI Limitation?',
              instruction: 'Understanding what AI can and cannot do is essential for scoping AI features. Classify each statement as a genuine AI capability or a common misconception.',
              mentorIntro: 'Half of AI project failures come from building against what AI can\'t reliably do. Let\'s calibrate your mental model before the theory.',
              categories: [
                { id: 'can',    label: 'Genuine AI Capability',   icon: '✅' },
                { id: 'cannot', label: 'Misconception / Limitation', icon: '⚠️' }
              ],
              items: [
                { text: 'A large language model can summarize a 50-page document and extract the 5 most important points with high reliability', correct: 'can', feedbackCorrect: 'Correct. Text summarization and key point extraction are tasks LLMs perform reliably and consistently across many document types.', feedbackWrong: 'Document summarization is a core strength of LLMs. It\'s one of the most reliable and commercially deployed AI capabilities.' },
                { text: 'An AI system can guarantee 100% factual accuracy in every response, making it suitable for replacing legal or medical reference databases', correct: 'cannot', feedbackCorrect: 'Right. LLMs can hallucinate — generate plausible-sounding but factually incorrect information. They are not suitable as authoritative sources of factual truth without human review.', feedbackWrong: 'LLMs hallucinate — they produce confident-sounding false information. They should not replace authoritative databases for legal or medical reference without rigorous validation and human oversight.' },
                { text: 'An AI model can classify customer support tickets into predefined categories (billing, technical, account) with high accuracy when trained on sufficient labeled examples', correct: 'can', feedbackCorrect: 'Yes. Classification against predefined categories is a well-established AI capability, especially with supervised training on labeled examples.', feedbackWrong: 'Classification tasks — routing tickets to predefined categories based on labeled training data — are one of the most reliable and proven AI capabilities.' },
                { text: 'An AI model can reliably predict a specific user\'s future behavior with complete certainty', correct: 'cannot', feedbackCorrect: 'Correct. AI can identify statistical patterns and probabilities but cannot predict individual human behavior with certainty. Probability-based forecasting, yes; deterministic prediction, no.', feedbackWrong: 'AI models work with probabilities, not certainties. Individual human behavior is too variable for deterministic AI prediction.' },
                { text: 'A generative AI model can draft first-pass product requirements documents, job descriptions, and internal communications that a human then reviews and edits', correct: 'can', feedbackCorrect: 'Yes. Drafting structured text from a prompt is a reliable LLM capability. The PM reviews and edits — the AI drafts the first pass significantly faster than starting from a blank page.', feedbackWrong: 'Drafting first-pass documents — PRDs, job descriptions, communications — is one of the most practical and widely deployed AI PM productivity tools.' }
              ]
            },
            {
              type: 'reading',
              label: 'Concepts',
              title: 'AI Concepts Every PM Must Know',
              mentorIntro: 'You\'ve just tested your mental model. Now let\'s build the vocabulary and concepts you\'ll need in AI product discussions.',
              sections: [
                { heading: 'How Large Language Models Work (For PMs)', body: 'Large Language Models (LLMs) like GPT-4 and Claude are trained on massive text datasets. They learn to predict the most statistically likely next word given a sequence of words — a process that, at massive scale, produces surprisingly capable language generation, reasoning, and summarization.<br><br>Key concept: LLMs do not "know" facts in the way a database knows records. They have learned statistical associations between words and concepts during training. This is why they can sound authoritative while being factually wrong — a phenomenon called <em>hallucination</em>.<br><br>Key concept: LLMs have a <em>context window</em> — the maximum amount of text they can process in one interaction. Everything outside the context window is invisible to the model.' },
                { heading: 'Training vs. Inference', body: 'Two distinct phases of an AI system\'s lifecycle that directly affect project planning:<br><br><strong>Training</strong> — the process of building the model by exposing it to data and adjusting its parameters. Training is compute-intensive, time-consuming, and expensive. Most product teams do not train foundation models from scratch — they use pre-trained models from providers like Anthropic, OpenAI, or Google.<br><br><strong>Fine-tuning</strong> — a lighter form of training that adapts a pre-trained model to a specific domain or task using a smaller, curated dataset. Common in enterprise AI: fine-tuning a general LLM on company-specific documents and terminology.<br><br><strong>Inference</strong> — using the trained model to generate responses. This is what happens every time a user interacts with an AI feature. Inference has per-call costs (API pricing) and latency implications for product design.' },
                { heading: 'Prompt Engineering for PMs', body: 'Prompt engineering is the practice of designing the instructions sent to an AI model to produce reliable, high-quality outputs. It is one of the most leverage-efficient skills for a PM working on AI products.<br><br>Basic principles: Be specific about format ("Return a bullet list of three recommendations"). Provide context ("You are a PM reviewing a product requirements document for clarity"). Use examples ("Here is an example of the output I want: [example]"). Constrain the output ("Do not include implementation suggestions — focus only on user needs").<br><br>For a TPM, prompt engineering matters because it directly affects feature quality: a well-designed prompt produces a reliable, consistent feature. A poorly designed prompt produces an unpredictable one.' }
              ]
            },
            {
              type: 'keyTakeaway',
              label: 'Takeaway',
              text: 'AI is powerful and imprecise. Understand hallucination, context windows, and inference costs before scoping any AI feature. Design with human oversight for high-stakes use cases.',
              mentorNote: 'The ability to scope AI features accurately — knowing what LLMs can and cannot do — is one of the most sought-after skills in Technical PM roles at AI-first companies.',
              xp: 30
            }
          ]
        },

        {
          id: 'T12-02',
          title: 'Managing AI Projects',
          objective: 'Apply PM best practices to the unique risks and challenges of AI-powered product development.',
          duration: '10 min',
          status: 'available',
          competencies: { 'AI Project Management': 12, 'AI Literacy': 6 },
          phases: [
            {
              type: 'reading',
              label: 'Concepts',
              title: 'What Makes AI Projects Different',
              mentorIntro: 'AI projects have a fundamentally different risk profile than traditional software. Understanding the differences is what lets you manage them well.',
              sections: [
                { heading: 'The Non-Deterministic Delivery Problem', body: 'Traditional software features are deterministic: given the same input, the system produces the same output. AI features are not. An LLM may give slightly different responses to the same prompt. A recommendation model\'s output changes as the training data evolves.<br><br>This creates a planning challenge: how do you define "done" for a feature whose output is inherently variable? The answer: define acceptance criteria around statistical performance metrics, not exact outputs. "The model classifies tickets with 92% accuracy on the validation set" is a testable, measurable definition of done. "The model gives good answers" is not.' },
                { heading: 'AI-Specific Risks Every TPM Must Manage', body: '<strong>Model Drift</strong> — AI model performance can degrade over time as the real-world data distribution shifts away from the training data. A model trained on user behavior from 2023 may perform worse on 2025 user behavior. Mitigation: monitor model performance metrics in production and establish a retraining cadence.<br><br><strong>Hallucination</strong> — LLMs generate plausible but false information. Mitigation: human review for high-stakes outputs, retrieval-augmented generation (RAG) to ground responses in verified sources, clear product UX that communicates AI limitations to users.<br><br><strong>Bias and Fairness</strong> — AI models trained on historical data can amplify existing biases. Mitigation: bias audits before launch, diverse evaluation datasets, monitoring for disparate impact across user groups.' },
                { heading: 'Evaluation: The PM\'s Most Important AI Skill', body: 'In traditional software, you test against requirements: does the button turn blue when clicked? In AI, you evaluate against statistical performance: does the model produce acceptable output across a representative sample of inputs?<br><br>Building an evaluation dataset ("evals") is one of the most important — and most underestimated — steps in AI product development. Evals are curated examples of inputs and the expected outputs (or quality criteria) the model should meet. Without evals, you cannot objectively assess whether an AI feature is ready to ship or whether a model update has improved or degraded performance.<br><br>As a PM, your job is to ensure evals are built before development begins — not as an afterthought before launch.' }
              ]
            },
            {
              type: 'quiz',
              label: 'Quiz',
              title: 'AI Project Management Check',
              mentorIntro: 'Real decisions a Technical PM faces when building AI-powered products.',
              questions: [
                { question: 'Your team is building an AI feature that summarizes customer contracts and extracts key dates. A lawyer who reviews contracts says the AI is "pretty good but occasionally misses things." What should you recommend before launch?', options: [ { text: 'Launch the feature — "pretty good" is sufficient for a summarization tool.', correct: false, feedback: 'Missed dates in legal contracts can have serious business consequences. "Pretty good" is not a measurable acceptance criterion for a high-stakes legal use case.' }, { text: 'Require that every AI summary is reviewed by a human before being used for any contractual decision, and add clear UI language indicating the AI output requires human verification.', correct: true, feedback: 'Correct. High-stakes AI use cases require human-in-the-loop design. The AI accelerates the human\'s work — it doesn\'t replace their judgment. Clear UI messaging about AI limitations is a product responsibility.' }, { text: 'Replace the AI summarization with a keyword search tool — it\'s safer.', correct: false, feedback: 'Reverting to keyword search may not be the right technical solution. The question is whether the AI feature has appropriate human oversight for its risk level — not whether to use AI at all.' }, { text: 'Ask the AI team to retrain the model until it achieves 100% accuracy.', correct: false, feedback: '100% accuracy is not achievable for complex, variable tasks like contract analysis. Define a measurable performance threshold and pair it with appropriate human oversight.' } ] },
                { question: 'Six months after launch, the AI recommendation model\'s click-through rate has dropped from 18% to 11%. No code changes were made. What is the most likely cause?', options: [ { text: 'The model was always performing poorly — it just wasn\'t monitored before.', correct: false, feedback: 'The model started at 18% and declined to 11%. This is a change over time, not a constant baseline problem.' }, { text: 'Model drift — the real-world data distribution has shifted away from the training data, degrading model performance.', correct: true, feedback: 'Correct. Model drift occurs when user behavior, product inventory, or other input data evolves differently from the training data. Performance degrades without any code change.' }, { text: 'The recommendation model has a bug introduced in the last deployment.', correct: false, feedback: 'The question states no code changes were made. If performance declined without code changes, the cause is typically model drift, not a code bug.' }, { text: 'The users\' expectations have increased and the model needs more features.', correct: false, feedback: 'Increased user expectations might affect perceived quality, but they don\'t explain a statistically measurable metric drop. Model drift is the more likely technical explanation.' } ] }
              ]
            },
            {
              type: 'keyTakeaway',
              label: 'Takeaway',
              text: 'AI products need statistical definitions of done, human oversight for high-stakes outputs, and ongoing monitoring for model drift. Ship with evals, not just tests.',
              mentorNote: 'The vocabulary of AI PM — hallucination, drift, RAG, fine-tuning, evals — signals that you\'ve actually shipped AI features. Learn it before you need it.',
              xp: 30
            }
          ]
        }
      ]
    },

    practice: {
      challenges: [
        {
          id: 'pc-ai-01',
          prompt: 'A product manager proposes an AI feature: "The LLM will automatically send legal notices to users on behalf of the company." What is the FIRST concern you raise?',
          choices: [
            { text: 'The LLM might be too slow for real-time legal notice delivery.' },
            { text: 'LLMs can hallucinate — automated legal notices generated without human review create legal liability risk. This use case requires human-in-the-loop approval before any notice is sent.' },
            { text: 'The LLM API costs will be too high for sending legal notices at scale.' },
            { text: 'Legal notices need to be stored in the database before sending.' }
          ],
          correctIndex: 1,
          explanation: 'Automated AI generation of legal communications without human review is a high-stakes use case with significant liability risk. A hallucinated or incorrect legal notice could have serious regulatory, financial, and reputational consequences. The first question is not about speed or cost — it\'s about appropriate oversight. This feature requires a human review and approval step before any notice is sent.',
          competency: 'AI Project Management',
          difficulty: 'hard'
        },
        {
          id: 'pc-ai-02',
          prompt: 'The engineering team asks: "What are the acceptance criteria for the AI customer support assistant?" You haven\'t defined them yet. What do you need to define?',
          choices: [
            { text: '"The AI should answer customer questions accurately." That\'s sufficient.' },
            { text: 'Define measurable criteria: response accuracy rate on a validation dataset (e.g., 90% correct), response latency target (e.g., under 2 seconds), hallucination rate threshold (e.g., < 2%), user satisfaction score target, and escalation criteria for when the AI should route to a human agent.' },
            { text: 'Ask engineering to define the acceptance criteria — it\'s a technical decision.' },
            { text: 'Launch and refine based on real user feedback.' }
          ],
          correctIndex: 1,
          explanation: 'AI features require statistical acceptance criteria, not qualitative ones. "Accurate" is not testable — "90% correct answers on a 500-question validation dataset" is. The five criteria in option B are all measurable: accuracy rate (model quality), latency (user experience), hallucination rate (safety), satisfaction score (user outcome), and escalation logic (human oversight). Without these, the engineering team cannot build a testing framework or know when the feature is ready to ship.',
          competency: 'AI Project Management',
          difficulty: 'medium'
        },
        {
          id: 'pc-ai-03',
          prompt: 'A stakeholder says: "We should just use ChatGPT — it\'s the best AI, right?" You need to explain why model selection requires evaluation. What\'s your response?',
          choices: [
            { text: 'Agree — use ChatGPT if it\'s the most well-known model.' },
            { text: '"Different AI models have different strengths depending on the task, context window size, cost per token, latency, and data privacy requirements. We need to evaluate 2–3 candidates on our specific use case with a representative test dataset before committing to any provider."' },
            { text: '"We should build our own custom model to avoid dependency on third parties."' },
            { text: '"ChatGPT is not suitable for enterprise use — we should use an open-source model."' }
          ],
          correctIndex: 1,
          explanation: 'No AI model is universally "the best." Model selection depends on: task-specific performance (which model handles your specific use case best?), context window size, cost per API call, response latency, data privacy requirements (can your data be sent to a third-party API?), and provider reliability. The right answer is a structured evaluation on your specific use case — not a brand preference.',
          competency: 'AI Literacy',
          difficulty: 'medium'
        },
        {
          id: 'pc-ai-04',
          prompt: 'Your team is about to launch an AI feature. The engineer says "we\'ve tested it manually and it works great." What is missing?',
          choices: [
            { text: 'Nothing — manual testing is sufficient for AI features.' },
            { text: 'A formal evaluation dataset (evals): a curated set of representative inputs with expected outputs or quality criteria, tested against the model systematically. Without evals, you cannot measure performance objectively or detect regressions when the model is updated.' },
            { text: 'A code review of the prompt engineering.' },
            { text: 'Approval from the AI ethics team.' }
          ],
          correctIndex: 1,
          explanation: 'Manual testing of AI features is insufficient because it\'s not systematic, not reproducible, and not sensitive to performance regressions. An evaluation dataset (evals) is the AI equivalent of an automated test suite: it defines what "good" looks like, can be run against any model version, and immediately surfaces regressions when the underlying model changes. Building evals before launch is a PM responsibility — not an afterthought.',
          competency: 'AI Project Management',
          difficulty: 'medium'
        },
        {
          id: 'pc-ai-05',
          prompt: 'A non-technical executive asks: "How confident are we that the AI will give correct answers?" What\'s the most honest and useful answer?',
          choices: [
            { text: '"The AI is very accurate — we tested it extensively."' },
            { text: '"Our evaluation shows the AI answers correctly for 94% of inputs in our test dataset. For the remaining 6%, the system escalates to a human agent. We\'re monitoring accuracy in production weekly and will alert if it drops below 90%."' },
            { text: '"AI is never 100% accurate, so we can\'t make any guarantees."' },
            { text: '"I\'ll have the engineering team answer that question."' }
          ],
          correctIndex: 1,
          explanation: 'Executives need a specific, measurable, honest answer — not reassurance and not a disclaimer. Option B gives all three elements: a specific accuracy number (94%), the safety mechanism for the failure cases (human escalation), and an ongoing monitoring commitment (weekly monitoring with a 90% alert threshold). This is the answer of a PM who has actually managed an AI product — not just launched one.',
          competency: 'AI Literacy',
          difficulty: 'medium'
        }
      ]
    },

    interview: {
      questions: [
        {
          id: 'iq-ai-01',
          question: 'Tell me about a project where you worked with AI or machine learning. What were the unique challenges?',
          difficulty: 'medium',
          competency: 'AI Project Management',
          star: {
            situation: 'I was the TPM for a B2B SaaS product that added an AI-powered contract analysis feature. The feature used an LLM to extract key terms, dates, and risk clauses from customer contracts and present them in a structured summary.',
            task: 'My responsibility was to define what "done" meant for an AI feature with inherently variable output, manage the risks around legal content accuracy, and coordinate between the product, engineering, and legal teams.',
            action: 'The first challenge was defining acceptance criteria. I worked with the legal team to create a 200-contract evaluation dataset — contracts representing our customers\' typical document types. For each contract, the legal team labeled the expected extractions. We set a threshold: 93% extraction accuracy and a hallucination rate below 1.5%. These became our launch criteria, not "it looks good." The second challenge was the human-in-the-loop question. Given the legal stakes, I recommended and got approved a two-step flow: the AI generates the summary, a customer-side reviewer sees it with a clear "AI-generated — verify before use" label, and only then can they use it in a contract workflow. The third challenge was model drift: I set up weekly monitoring on a held-out evaluation subset so we would detect performance degradation before users did.',
            result: 'The feature launched with 94.3% accuracy on the evaluation dataset. In the first 3 months, user-reported error rates were below 2% — consistent with our validation performance. The weekly monitoring caught a 4-point accuracy drop 6 weeks after launch when the underlying model was updated by the provider; we caught it and patched the prompt before any user impact.',
            keyMessage: 'AI projects succeed when you define statistical success criteria before development begins, design for human oversight from the start, and build monitoring for model drift before you launch. These three things are the difference between a reliable AI feature and a liability.'
          },
          tips: [
            'The 200-contract evaluation dataset with legal team labeling is a concrete, credible detail that shows real AI PM practice.',
            'The 93% accuracy + 1.5% hallucination rate thresholds show that you build measurable acceptance criteria for AI features.',
            'The weekly monitoring catching the model provider update is the highlight of the outcome — proactive, not reactive.'
          ]
        },
        {
          id: 'iq-ai-02',
          question: 'How do you explain AI capabilities and limitations to a non-technical stakeholder who wants to use AI for everything?',
          difficulty: 'medium',
          competency: 'AI Literacy',
          star: {
            situation: 'A VP of Operations at a previous company became enthusiastic about AI after a conference and proposed using LLMs for three new use cases in a single quarter: automated invoice processing, customer sentiment scoring, and AI-generated legal summaries.',
            task: 'I needed to evaluate all three proposals, communicate the capabilities and limitations honestly, and help the VP make informed decisions without dampening the momentum.',
            action: 'I ran a 30-minute evaluation session with the VP using a simple 2×2 framework: on one axis, AI reliability for that task type (high vs. uncertain). On the other axis, stakes if the AI is wrong (low vs. high). Invoice processing: high reliability for structured data extraction, low stakes per invoice (humans review anyway) — good candidate. Sentiment scoring: reliable for directional signal, low stakes (used for trend analysis, not individual decisions) — good candidate with appropriate caveats. Legal summaries: uncertain reliability for complex legal nuance, high stakes (legal decisions) — requires human-in-the-loop design and a pilot with strict evaluation criteria before any production use. The VP appreciated that I said "yes, yes, and yes — but here\'s what yes means for each one." The most honest answer is not "AI can\'t do that" — it\'s "AI can help here, and here\'s what we need to build for it to do so responsibly."',
            result: 'All three projects were greenlit on a staged basis. Invoice processing and sentiment scoring launched in Q1 with strong results. The legal summary pilot is running in a controlled environment with human review. None of the three produced the risks the original unconstrained proposals would have created.',
            keyMessage: 'The best way to manage AI enthusiasm is not skepticism — it\'s honest scoping. The 2×2 framework (reliability × stakes) gives you a principled way to say yes to AI while ensuring each "yes" comes with the right safeguards.'
          },
          tips: [
            'The reliability × stakes 2×2 framework is memorable and immediately applicable — interviewers will note it.',
            '"Yes, yes, and yes — but here\'s what yes means" is a great line that shows you can enable innovation without creating liability.',
            'The staged launch approach shows pragmatic risk management: highest confidence use cases first, highest risk in controlled pilot.'
          ]
        }
      ]
    }
  },

];

/**
 * CERT_QUESTIONS — Unified certification exam pool.
 * packageId on each question enables competency-aware results breakdown.
 * Pass threshold: 70%.
 */
const CERT_QUESTIONS = [
  {
    id: 'cert-01',
    domain: 'Initiating',
    question: 'A project sponsor asks a TPM to begin work on a new cloud infrastructure project before the project charter is formally signed. What should the TPM do?',
    options: [
      { text: 'Begin work immediately — the sponsor\'s verbal authorization is sufficient.', correct: false, explanation: 'Verbal authorization is not a formal project approval. Without a signed charter, the project lacks official organizational recognition, authority, and resource commitment.' },
      { text: 'Explain that work cannot begin without a signed project charter, and offer to expedite the approval process.', correct: true, explanation: 'The project charter formally authorizes the project and the PM\'s authority to apply organizational resources. Starting without it exposes the team to scope, budget, and authority disputes.' },
      { text: 'Begin work and document the verbal authorization in the project log.', correct: false, explanation: 'Documentation of a verbal authorization doesn\'t replace formal approval. The project remains unauthorized and the PM lacks formal authority to commit resources.' },
      { text: 'Ask the project team to start and request the charter be completed retrospectively.', correct: false, explanation: 'Retroactive chartering undermines the purpose of the approval process and creates accountability gaps. Formal authorization must precede the work.' }
    ]
  ,
  packageId: 'PKG-FUNDAMENTALS' },
  {
    id: 'cert-02',
    domain: 'Planning',
    question: 'Which document defines the detailed scope of work, exclusions, deliverables, assumptions, and constraints for a project?',
    options: [
      { text: 'The project charter', correct: false, explanation: 'The project charter provides high-level scope and authorizes the project. Detailed scope definition belongs to the scope statement, created during Planning.' },
      { text: 'The work breakdown structure (WBS)', correct: false, explanation: 'The WBS decomposes scope into deliverable-oriented work packages. The scope statement defines what is in and out of scope at the narrative level.' },
      { text: 'The project scope statement', correct: true, explanation: 'The project scope statement is the Planning artifact that defines detailed scope: what is included, what is excluded, deliverables, acceptance criteria, assumptions, and constraints. It is the reference point for all scope decisions.' },
      { text: 'The requirements traceability matrix', correct: false, explanation: 'The RTM traces requirements from source to deliverable. Scope definition is the project scope statement.' }
    ]
  ,
  packageId: 'PKG-FUNDAMENTALS' },
  {
    id: 'cert-03',
    domain: 'Risk Management',
    question: 'A previously identified risk on a software project has materialized. What is the correct next action?',
    options: [
      { text: 'Update the risk register to reflect the new probability score.', correct: false, explanation: 'Once a risk becomes an issue, it moves from the risk register to the issue log. Updating probability is for risks that haven\'t occurred yet.' },
      { text: 'Activate the planned risk response and update the issue log.', correct: true, explanation: 'When a risk materializes, it becomes an issue. The planned risk response (mitigation, contingency plan) should be activated immediately, and the situation documented in the issue log, not the risk register.' },
      { text: 'Escalate immediately to the project sponsor.', correct: false, explanation: 'Escalation may be appropriate depending on severity, but the first action is always to activate the planned response if one exists.' },
      { text: 'Re-assess the risk during the next project status meeting.', correct: false, explanation: 'A materialized risk is an active issue requiring immediate response — not a deferred agenda item.' }
    ]
  ,
  packageId: 'PKG-RISK' },
  {
    id: 'cert-04',
    domain: 'Agile',
    question: 'In a Scrum project, who is responsible for ordering the product backlog to maximize the value delivered?',
    options: [
      { text: 'The Scrum Master', correct: false, explanation: 'The Scrum Master facilitates the process and removes impediments. Backlog ordering is a product decision, not a process facilitation decision.' },
      { text: 'The development team', correct: false, explanation: 'The team estimates effort and selects work for sprints, but backlog ordering — prioritization by value — belongs to the Product Owner.' },
      { text: 'The Product Owner', correct: true, explanation: 'The Product Owner is accountable for the product backlog, its contents, and its ordering. They represent the business and are responsible for maximizing the value of the work the team delivers.' },
      { text: 'The project sponsor', correct: false, explanation: 'The sponsor funds and champions the project but does not manage day-to-day backlog decisions. The Product Owner holds that accountability.' }
    ]
  ,
  packageId: 'PKG-AGILE' },
  {
    id: 'cert-05',
    domain: 'Scope Management',
    question: 'A stakeholder requests an addition to the project scope after the scope baseline has been established. What is the correct process?',
    options: [
      { text: 'Accept the change — stakeholders always have the right to add requirements.', correct: false, explanation: 'Accepting scope changes without evaluation violates scope management. Every change must go through change control regardless of who requests it.' },
      { text: 'Reject the change — scope cannot be modified after the baseline is set.', correct: false, explanation: 'Scope baselines can be changed — but only through a formal change control process. Reflexive rejection is as incorrect as reflexive acceptance.' },
      { text: 'Submit a formal change request and evaluate impact on schedule, cost, and quality.', correct: true, explanation: 'All scope changes after baseline must go through integrated change control. The TPM evaluates impact across all knowledge areas and presents the analysis before any approval or rejection.' },
      { text: 'Add the requirement to a future project backlog without informing the stakeholder.', correct: false, explanation: 'Silent deferral is a transparency failure. The stakeholder deserves a response through formal change control, not a quiet redirect.' }
    ]
  ,
  packageId: 'PKG-FUNDAMENTALS' },
  {
    id: 'cert-06',
    domain: 'Stakeholder Management',
    question: 'A key stakeholder is consistently late to project status meetings and has not reviewed deliverables on time. What is the most appropriate first response?',
    options: [
      { text: 'Escalate to the project sponsor immediately.', correct: false, explanation: 'Escalation before direct engagement is premature. Strong TPMs address engagement issues directly before involving senior leadership.' },
      { text: 'Remove the stakeholder from the distribution list to reduce friction.', correct: false, explanation: 'Disengaging a stakeholder increases risk. They may resurface later with objections that derail the project.' },
      { text: 'Schedule a one-on-one conversation to understand the stakeholder\'s constraints and renegotiate their involvement format.', correct: true, explanation: 'Engagement issues often stem from format or timing mismatches, not disinterest. A direct conversation to understand constraints and adjust the communication approach is the most effective first step.' },
      { text: 'Continue with the project and document the stakeholder\'s non-participation.', correct: false, explanation: 'Documentation without action doesn\'t resolve the issue. A disengaged stakeholder is a project risk that requires proactive management.' }
    ]
  ,
  packageId: 'PKG-STAKEHOLDER' },
  {
    id: 'cert-07',
    domain: 'Schedule Management',
    question: 'Which schedule network analysis technique involves calculating the longest path through a project network to determine the minimum project duration?',
    options: [
      { text: 'Resource leveling', correct: false, explanation: 'Resource leveling adjusts the schedule to address resource constraints — it doesn\'t calculate the minimum project duration.' },
      { text: 'Critical path method (CPM)', correct: true, explanation: 'CPM identifies the longest sequence of dependent activities (the critical path), which determines the shortest possible project duration. Any delay on the critical path extends the project end date.' },
      { text: 'Monte Carlo simulation', correct: false, explanation: 'Monte Carlo simulation uses statistical modeling to assess schedule risk and probability of completion by a given date. It doesn\'t define the minimum duration.' },
      { text: 'Fast-tracking', correct: false, explanation: 'Fast-tracking is a schedule compression technique that overlaps sequential activities. It\'s used after the critical path is identified.' }
    ]
  ,
  packageId: 'PKG-FUNDAMENTALS' },
  {
    id: 'cert-08',
    domain: 'Quality Management',
    question: 'During a software project\'s testing phase, the team discovers a recurring defect pattern caused by inconsistent coding standards across teams. What quality tool is most appropriate for identifying root causes?',
    options: [
      { text: 'Control chart', correct: false, explanation: 'Control charts monitor process stability over time. They\'re useful for detecting when a process is out of control, but not for diagnosing root causes.' },
      { text: 'Pareto chart', correct: false, explanation: 'A Pareto chart identifies which defect categories are most frequent (80/20 principle), but the root cause analysis requires going deeper than frequency counting.' },
      { text: 'Cause-and-effect diagram (Ishikawa/fishbone)', correct: true, explanation: 'The fishbone diagram is specifically designed for root cause analysis. It maps potential causes across categories (people, process, tools, environment) to identify the source of a defect pattern.' },
      { text: 'Scatter diagram', correct: false, explanation: 'A scatter diagram shows correlation between two variables. It\'s useful for hypothesis testing, not root cause identification.' }
    ]
  ,
  packageId: 'PKG-FUNDAMENTALS' },
  {
    id: 'cert-09',
    domain: 'Communications Management',
    question: 'A project team of 7 members grows to 10 members. How many more communication channels does this create?',
    options: [
      { text: '9 more channels', correct: false, explanation: 'Communication channels = n(n-1)/2. For 7: 21. For 10: 45. The difference is 24 — not 9.' },
      { text: '21 more channels', correct: false, explanation: 'This is the number of channels with 7 members, not the difference. For 10 members: 45 channels. For 7: 21. Difference = 24.' },
      { text: '24 more channels', correct: true, explanation: 'Formula: n(n-1)/2. With 7 members: 7×6/2 = 21 channels. With 10 members: 10×9/2 = 45 channels. Difference: 45 - 21 = 24. This illustrates why communication complexity grows exponentially with team size.' },
      { text: '3 more channels', correct: false, explanation: 'Adding 3 people doesn\'t create 3 channels — each new member connects to all existing members. The growth is n(n-1)/2.' }
    ]
  ,
  packageId: 'PKG-STAKEHOLDER' },
  {
    id: 'cert-10',
    domain: 'Integration Management',
    question: 'During project execution, a team member identifies an opportunity to improve a process that would require changes to cost, schedule, and scope. What is the correct action?',
    options: [
      { text: 'Implement the improvement immediately — process improvements benefit the project.', correct: false, explanation: 'Even beneficial changes must go through change control if they affect the project baseline. Unauthorized changes undermine scope management and create tracking issues.' },
      { text: 'Document the improvement and implement it at the end of the project.', correct: false, explanation: 'Deferring a beneficial improvement without evaluation may be unnecessary. The correct approach is to evaluate it through change control.' },
      { text: 'Ignore it — only the project sponsor can initiate process changes.', correct: false, explanation: 'Any team member can identify and submit a change request. The change control process evaluates and approves it — the idea can come from anyone.' },
      { text: 'Submit a change request, evaluate the impact across all affected areas, and present it to the change control board for approval.', correct: true, explanation: 'All changes to the project baseline — including beneficial process improvements — must go through integrated change control. The TPM evaluates impact holistically and presents the analysis for formal decision.' }
    ]
  ,
  packageId: 'PKG-FUNDAMENTALS' },
  {
    id: 'cq-11',
    domain: 'Risk Management',
    question: 'A project manager identifies a risk that has a 30% probability of occurring and would result in a $50,000 cost overrun. What is the Expected Monetary Value (EMV) of this risk?',
    options: [
      { text: '$15,000', correct: true },
      { text: '$50,000', correct: false },
      { text: '$35,000', correct: false },
      { text: '$20,000', correct: false }
    ],
    explanation: 'EMV = Probability × Impact. 30% × $50,000 = $15,000. EMV is used in decision tree analysis to quantify risks and opportunities in monetary terms, enabling objective comparison and prioritization.'
  ,
  packageId: 'PKG-RISK' },
  {
    id: 'cq-12',
    domain: 'Risk Management',
    question: 'Which risk response strategy is most appropriate when a vendor\'s SLA guarantees compensation if their service causes project delays?',
    options: [
      { text: 'Mitigate', correct: false },
      { text: 'Avoid', correct: false },
      { text: 'Transfer', correct: true },
      { text: 'Accept', correct: false }
    ],
    explanation: 'Transfer shifts the financial consequence of a risk to a third party — in this case, the vendor through the SLA. The risk itself is not eliminated, but the financial impact is transferred. Insurance, contracts, and warranties are all Transfer mechanisms.'
  ,
  packageId: 'PKG-RISK' },
  {
    id: 'cq-13',
    domain: 'Risk Management',
    question: 'A TPM updates the risk register and discovers that a previously identified risk has been triggered. What should the TPM do FIRST?',
    options: [
      { text: 'Remove the risk from the register since it is no longer a risk.', correct: false },
      { text: 'Activate the documented risk response plan and update the register status.', correct: true },
      { text: 'Escalate the situation to the project sponsor immediately before taking any action.', correct: false },
      { text: 'Conduct a new risk identification session to find related risks.', correct: false }
    ],
    explanation: 'When a risk triggers, the first action is to execute the pre-planned response — not to re-analyze or immediately escalate. The risk register status should be updated to "Triggered." Escalation may follow based on the severity, but the response plan should activate first.'
  ,
  packageId: 'PKG-RISK' },
  {
    id: 'cq-14',
    domain: 'Risk Management',
    question: 'Which of the following BEST describes a residual risk?',
    options: [
      { text: 'A risk that was accepted without any response plan.', correct: false },
      { text: 'A new risk created as a result of implementing a risk response.', correct: false },
      { text: 'The risk that remains after a risk response has been implemented.', correct: true },
      { text: 'A risk that is too small to document in the register.', correct: false }
    ],
    explanation: 'A residual risk is the remaining exposure after the risk response has been applied. For example, after implementing a mitigation that reduces probability from High to Low, the residual risk is the Low-probability remainder. Residual risks should still be documented and monitored.'
  ,
  packageId: 'PKG-RISK' },
  {
    id: 'cq-15',
    domain: 'Risk Management',
    question: 'During sprint planning, a developer says: "I\'m not confident about the third-party API integration — we\'ve never used it before." The TPM\'s BEST response is to:',
    options: [
      { text: 'Reassure the developer and proceed with the plan.', correct: false },
      { text: 'Log it as a technical risk, assign the developer as owner, and add a spike to validate the integration.', correct: true },
      { text: 'Remove the integration from the sprint until it can be fully tested.', correct: false },
      { text: 'Escalate to the Product Owner and ask them to de-prioritize the feature.', correct: false }
    ],
    explanation: 'Technical uncertainty is a risk. The appropriate response is to log it, assign ownership, and add a spike (a short research or validation task) to the sprint. This surfaces the unknown early, gives the team data to plan with, and avoids a mid-sprint blocker.'
  ,
  packageId: 'PKG-RISK' },
  {
    id: 'cq-16',
    domain: 'Stakeholder Management',
    question: 'A high-power, low-interest stakeholder has started sending frequent emails and attending meetings they previously ignored. What does this MOST LIKELY indicate?',
    options: [
      { text: 'The stakeholder wants to take over the project.', correct: false },
      { text: 'The stakeholder has become aware of an issue or risk that concerns them.', correct: true },
      { text: 'The project is behind schedule and the stakeholder wants updates.', correct: false },
      { text: 'The stakeholder relationship has improved naturally over time.', correct: false }
    ],
    explanation: 'A sudden increase in engagement from a previously disengaged high-power stakeholder often signals they have become aware of a concern — a risk, a rumor, or a business impact. The TPM should proactively reach out to understand their concern and address it directly before it escalates.'
  ,
  packageId: 'PKG-STAKEHOLDER' },
  {
    id: 'cq-17',
    domain: 'Stakeholder Management',
    question: 'Which stakeholder engagement approach is MOST appropriate for a stakeholder with HIGH power and HIGH interest in the project?',
    options: [
      { text: 'Monitor — keep them informed with periodic updates.', correct: false },
      { text: 'Keep Satisfied — meet their needs without involving them in decisions.', correct: false },
      { text: 'Manage Closely — engage frequently, involve in key decisions, address concerns proactively.', correct: true },
      { text: 'Keep Informed — provide regular updates but limit decision-making involvement.', correct: false }
    ],
    explanation: 'High Power + High Interest = Manage Closely. These stakeholders have both the authority to impact the project and the motivation to use it. They should be actively engaged in decision-making and kept informed in real time — not just through status reports.'
  ,
  packageId: 'PKG-STAKEHOLDER' },
  {
    id: 'cq-18',
    domain: 'Risk Management',
    question: 'A project manager performs a risk reassessment and finds that the probability of a key risk has increased from Low to High. What should happen to the risk response plan?',
    options: [
      { text: 'The response plan remains unchanged — risk responses are fixed at identification.', correct: false },
      { text: 'The risk should be removed from the register since it is now more of an issue.', correct: false },
      { text: 'The response plan should be reviewed and escalated if the new risk level exceeds the previously accepted threshold.', correct: true },
      { text: 'A new risk should be created instead of updating the existing one.', correct: false }
    ],
    explanation: 'Risk registers are living documents. When the risk profile changes, the response plan must be reassessed. If the new level (High probability) exceeds what was previously accepted, the response should be escalated — potentially from Accept to Mitigate or Avoid. Always update the register to reflect current reality.'
  ,
  packageId: 'PKG-RISK' },
  {
    id: 'cq-19',
    domain: 'Risk Management',
    question: 'What is the PRIMARY purpose of a risk trigger in a risk response plan?',
    options: [
      { text: 'To automatically notify the project sponsor when a risk occurs.', correct: false },
      { text: 'To define the specific condition or event that signals a risk is about to occur or has occurred, activating the response plan.', correct: true },
      { text: 'To measure the probability that a risk will occur.', correct: false },
      { text: 'To document who is responsible for managing the risk.', correct: false }
    ],
    explanation: 'A trigger (also called a risk symptom or warning sign) is the condition that tells you to activate the response plan. For example: "If the vendor hasn\'t confirmed delivery by Day 15, activate the backup supplier." Triggers remove ambiguity about when to act — which is critical under pressure.'
  ,
  packageId: 'PKG-RISK' },
  {
    id: 'cq-20',
    domain: 'Integration Management',
    question: 'A project is significantly over budget and behind schedule. The sponsor asks the project manager to present options. Which tool BEST supports this decision?',
    options: [
      { text: 'Risk register', correct: false },
      { text: 'Stakeholder register', correct: false },
      { text: 'Earned Value Analysis (EVA)', correct: true },
      { text: 'Work Breakdown Structure (WBS)', correct: false }
    ],
    explanation: 'Earned Value Analysis provides objective cost and schedule performance data through metrics like CPI (Cost Performance Index) and SPI (Schedule Performance Index). It quantifies the current variance and projects future performance — giving the sponsor the factual basis needed to evaluate recovery options, re-scope, or reset expectations.'
  ,
  packageId: 'PKG-FUNDAMENTALS' },
  { id: 'cq-21', domain: 'Stakeholder Management', question: 'A stakeholder who was previously classified as Low Power / Low Interest has been promoted to Director and now has budget approval authority. What should the project manager do FIRST?', options: [ { text: 'Continue with the same engagement strategy — their interest level has not changed.', correct: false }, { text: 'Update the stakeholder register and revise the engagement strategy to reflect the new power level.', correct: true }, { text: 'Escalate to the project sponsor to inform them of the stakeholder change.', correct: false }, { text: 'Schedule a formal kickoff meeting with the stakeholder to restart the relationship from scratch.', correct: false } ], explanation: 'The stakeholder register is a living document. When power or interest changes, the register and engagement strategy must be updated immediately. A newly promoted stakeholder with budget authority shifts from Monitor to Keep Satisfied or Manage Closely, depending on their interest level.' ,
  packageId: 'PKG-STAKEHOLDER' },
  { id: 'cq-22', domain: 'Stakeholder Management', question: 'A project manager notices that a key stakeholder has become less responsive and is delegating all communications to a junior team member. Which is the MOST appropriate next step?', options: [ { text: 'Continue communicating with the junior team member and assume the stakeholder will re-engage when needed.', correct: false }, { text: 'Escalate to the stakeholder\'s manager and request their active participation.', correct: false }, { text: 'Schedule a direct conversation with the stakeholder to understand their level of engagement and any concerns they may have.', correct: true }, { text: 'Remove the stakeholder from the communication plan until they re-engage.', correct: false } ], explanation: 'Stakeholder disengagement is a risk, not a convenience. Before escalating or assuming, the PM should have a direct conversation to understand whether the stakeholder has a concern, a capacity issue, or has simply lost interest. This information determines the appropriate response.' ,
  packageId: 'PKG-STAKEHOLDER' },
  { id: 'cq-23', domain: 'Stakeholder Management', question: 'Which of the following BEST describes the purpose of a stakeholder communication plan?', options: [ { text: 'To define what information each stakeholder group needs, when they need it, and through which channel it will be delivered.', correct: true }, { text: 'To document the project scope, schedule, and budget for all stakeholders.', correct: false }, { text: 'To assign communication responsibilities to individual team members.', correct: false }, { text: 'To establish a weekly meeting cadence for all project participants.', correct: false } ], explanation: 'A communication plan answers: who needs what information, when, and how. Its purpose is to make stakeholder communication predictable and purposeful — reducing ad-hoc requests and ensuring no stakeholder is surprised by project developments.' ,
  packageId: 'PKG-STAKEHOLDER' },
  { id: 'cq-24', domain: 'Communications Management', question: 'A project manager needs to communicate a technical architecture decision to both an engineering team and a non-technical executive sponsor. What is the MOST effective approach?', options: [ { text: 'Send the same detailed technical report to both audiences to ensure consistency.', correct: false }, { text: 'Summarize only the key decision for both audiences to keep communication brief.', correct: false }, { text: 'Let the engineering team communicate with the executive sponsor directly to save time.', correct: false }, { text: 'Tailor the communication to each audience — technical detail for the engineering team, business impact and recommendation for the executive sponsor.', correct: true } ], explanation: 'Effective communication adapts to the audience. Engineers need technical context to implement and maintain the decision. Executive sponsors need to understand the business impact and what (if anything) they need to decide or approve. Same decision, different lenses.' ,
  packageId: 'PKG-STAKEHOLDER' },
  { id: 'cq-25', domain: 'Stakeholder Management', question: 'During a project status meeting, a stakeholder begins arguing that the project approach is fundamentally wrong and should be reconsidered. Which is the BEST initial response?', options: [ { text: 'Defend the current approach with technical evidence and data.', correct: false }, { text: 'Acknowledge the concern, take it offline, and schedule a dedicated session to explore it properly.', correct: true }, { text: 'Ask the project sponsor to address the stakeholder directly.', correct: false }, { text: 'Note the concern in the meeting minutes and continue the meeting as planned.', correct: false } ], explanation: 'Public disagreements rarely resolve well in a meeting setting — they create defensiveness and derail the agenda. Acknowledging the concern and taking it offline signals respect for the stakeholder while protecting the meeting\'s purpose. A dedicated session gives the concern the proper time and attention it deserves.' ,
  packageId: 'PKG-STAKEHOLDER' },
  { id: 'cq-26', domain: 'Stakeholder Management', question: 'A project manager learns that a stakeholder has been giving direct instructions to developers outside of the sprint planning process. What should the project manager do?', options: [ { text: 'Ask the developers to ignore any instructions that did not come through official channels.', correct: false }, { text: 'Escalate to senior leadership immediately to stop the behavior.', correct: false }, { text: 'Meet with the stakeholder to understand their urgency, explain the impact on the team, and agree on a process for handling their requests through proper channels.', correct: true }, { text: 'Accept the situation — stakeholders with authority have the right to direct the team.', correct: false } ], explanation: 'Bypassed processes usually reflect a stakeholder who believes the formal channel is too slow. The right response is to address both the behavior and the root cause: have a direct conversation, understand their urgency, and offer a legitimate fast-track path while protecting the team from unplanned disruption.' ,
  packageId: 'PKG-STAKEHOLDER' },
  { id: 'cq-27', domain: 'Communications Management', question: 'What is the PRIMARY benefit of identifying stakeholders early in a project?', options: [ { text: 'It allows the project manager to involve key stakeholders in shaping requirements and expectations before commitments are made.', correct: true }, { text: 'It reduces the number of status meetings required during the project.', correct: false }, { text: 'It ensures that all stakeholders have the same level of technical knowledge.', correct: false }, { text: 'It allows the project manager to build the project schedule with input from all parties.', correct: false } ], explanation: 'Early stakeholder identification allows the PM to involve the right people in shaping requirements, setting expectations, and surfacing concerns before decisions are locked in. Stakeholders identified late often become resistant because they feel excluded — and their concerns become more costly to address.' ,
  packageId: 'PKG-STAKEHOLDER' },
  { id: 'cq-28', domain: 'Stakeholder Management', question: 'A stakeholder who is classified as Resistant on the engagement spectrum wants to attend all project meetings. How should the project manager respond?', options: [ { text: 'Decline the request — resistant stakeholders can create friction in meetings.', correct: false }, { text: 'Accept the request without any follow-up — participation may naturally increase their engagement.', correct: false }, { text: 'Accept the request and use the opportunity to better understand their concerns and move them toward a more supportive position.', correct: true }, { text: 'Escalate the situation to the sponsor before making a decision.', correct: false } ], explanation: 'A resistant stakeholder who wants to participate is showing a form of engagement. The right response is to welcome the participation and use it strategically — listen for their specific concerns, address them directly, and involve them in solutions where appropriate. Active participation often moves resistant stakeholders toward neutral or supportive.' ,
  packageId: 'PKG-STAKEHOLDER' },
  { id: 'cq-29', domain: 'Stakeholder Management', question: 'Which stakeholder engagement level requires the MOST active involvement from the project manager?', options: [ { text: 'Neutral — they are unbiased and require regular reinforcement to maintain their position.', correct: false }, { text: 'Resistant — they actively oppose the project and require direct engagement to understand and address their concerns.', correct: true }, { text: 'Unaware — they need to be informed about the project before any engagement can begin.', correct: false }, { text: 'Supportive — they are already aligned and should be leveraged to influence others.', correct: false } ], explanation: 'Resistant stakeholders require the most active engagement because their opposition can block decisions, delay approvals, and influence others negatively. Understanding their concern and addressing it directly — not escalating or excluding them — is the most effective path to moving them toward a more supportive position.' ,
  packageId: 'PKG-STAKEHOLDER' },
  { id: 'cq-30', domain: 'Communications Management', question: 'A project manager is creating a communication plan for a project with 15 stakeholders across 4 groups. What is the MOST important factor in designing the plan?', options: [ { text: 'Ensuring every stakeholder receives the same information to avoid confusion.', correct: false }, { text: 'Maximizing the frequency of updates to keep all stakeholders fully informed.', correct: false }, { text: 'Minimizing the number of communication formats to simplify management.', correct: false }, { text: 'Matching the content, frequency, and channel of communication to the specific needs of each stakeholder group.', correct: true } ], explanation: 'A communication plan serves its audience — not its author. The most effective plans are differentiated by stakeholder group: executives get impact summaries, technical teams get detail, operational teams get what affects their work. Same project, different lenses. Standardizing across audiences creates noise for some and gaps for others.' ,
  packageId: 'PKG-STAKEHOLDER' },
  // ── PKG-PLANNING ─────────────────────────────────────────────────────────
  { id: 'cq-31', domain: 'Project Planning', question: 'A project manager creates a WBS where the top-level items are: "Plan", "Execute", and "Monitor and Control". What is the PRIMARY problem with this WBS?', options: [ { text: 'The WBS has too few levels to be useful for planning.', correct: false }, { text: 'The WBS is organized by project phases rather than deliverables, violating the deliverables-based structure.', correct: true }, { text: 'The WBS does not include a closing phase.', correct: false }, { text: 'The WBS should only have one top-level item.', correct: false } ], explanation: 'A WBS should represent deliverables — the products, services, or results the project will produce. Organizing by phases (Plan, Execute, Monitor) describes process, not deliverables. A correct WBS would have items like: Authentication Module, Payment Integration, Admin Dashboard — things the team will actually build.',
  packageId: 'PKG-PLANNING' },
  { id: 'cq-32', domain: 'Estimation', question: 'A TPM uses Three-Point Estimation. The Optimistic estimate is 5 days, the Most Likely is 10 days, and the Pessimistic is 21 days. What is the PERT estimate?', options: [ { text: '11 days', correct: true }, { text: '10 days (most likely always wins)', correct: false }, { text: '12 days (simple average)', correct: false }, { text: '21 days (always use pessimistic for safety)', correct: false } ], explanation: 'PERT formula: (O + 4M + P) ÷ 6 = (5 + 4×10 + 21) ÷ 6 = (5 + 40 + 21) ÷ 6 = 66 ÷ 6 = 11 days. The formula weights the Most Likely estimate four times to reflect that it is the most realistic scenario. PERT produces more reliable estimates than simple averages.',
  packageId: 'PKG-PLANNING' },
  { id: 'cq-33', domain: 'Scope Management', question: 'Midway through a sprint, a stakeholder requests a "small" feature addition. The development team estimates 3 days of work. The sprint ends in 4 days. What should the TPM do FIRST?', options: [ { text: 'Add the feature — there is available time in the sprint.', correct: false }, { text: 'Reject the request — scope cannot change during a sprint.', correct: false }, { text: 'Evaluate the tradeoff with the team: adding the new feature may require removing an existing story to protect the sprint goal.', correct: true }, { text: 'Ask the developer to work overtime to fit both.', correct: false } ], explanation: 'Mid-sprint scope additions require a conscious tradeoff. Adding 3 days of new work does not automatically fit within a 4-day window — the team has other commitments in flight. The correct first action is to make the tradeoff visible: adding the new feature likely means removing an existing story. The sprint goal must be protected.',
  packageId: 'PKG-PLANNING' },
  // ── PKG-SPRINT ────────────────────────────────────────────────────────────
  { id: 'cq-34', domain: 'Sprint Planning', question: 'A Scrum team\'s 3-sprint rolling average velocity is 28 story points. During sprint planning, the team selects 42 points. What is the MOST appropriate action?', options: [ { text: 'Accept the 42-point commitment — teams should stretch to grow.', correct: false }, { text: 'Reduce the commitment to align with the team\'s proven velocity of 28 points.', correct: true }, { text: 'Split the difference and commit to 35 points.', correct: false }, { text: 'Add more developers to the sprint to close the capacity gap.', correct: false } ], explanation: 'Velocity is the team\'s proven delivery rate, not a ceiling to be broken with motivation. Committing 50% above velocity (42 vs. 28) without a structural change is a predictable failure. The TPM\'s job is to protect the team\'s credibility and stakeholder expectations by aligning commitment with sustainable pace.',
  packageId: 'PKG-SPRINT' },
  { id: 'cq-35', domain: 'Delivery Management', question: 'On day 7 of a 10-day sprint, the burndown chart shows no progress for 3 consecutive days. What does this MOST LIKELY indicate?', options: [ { text: 'The team is working on tasks not tracked in the project management tool.', correct: false }, { text: 'The team is blocked by a dependency, technical issue, or unclear acceptance criteria that has not been escalated.', correct: true }, { text: 'The sprint commitment was too aggressive.', correct: false }, { text: 'The velocity calculation for this sprint is incorrect.', correct: false } ], explanation: 'A flat burndown for 3 days is a strong signal of a blocker — something preventing the team from closing stories. The TPM should immediately convene a focused session to identify the blocker: a dependency, technical uncertainty, unavailable reviewer, or unclear acceptance criteria. A flat burndown is a signal to act, not wait.',
  packageId: 'PKG-SPRINT' },
  // ── PKG-DELIVERY ─────────────────────────────────────────────────────────
  { id: 'cq-36', domain: 'Release Management', question: 'During a release readiness review, a security team flags a medium-severity SQL injection vulnerability in the admin search feature. The release is scheduled for tomorrow. What is the BEST course of action?', options: [ { text: 'Release as planned — medium severity does not require a delay.', correct: false }, { text: 'Block the release and fix the vulnerability before deployment to production.', correct: true }, { text: 'Release with monitoring enabled to detect any exploitation attempts.', correct: false }, { text: 'Patch the vulnerability in the first post-release hotfix.', correct: false } ], explanation: 'SQL injection is an exploitable vulnerability regardless of severity classification. Releasing with a known injection attack vector creates immediate legal, regulatory, and reputational risk. Security vulnerabilities involving user input and database interaction must be patched before production deployment.',
  packageId: 'PKG-DELIVERY' },
  { id: 'cq-37', domain: 'Release Management', question: 'A team uses a canary release, deploying to 5% of users. After 24 hours, the error rate in the new version is 4.1% vs. 0.3% in the previous version. What should the TPM recommend?', options: [ { text: 'Proceed with full rollout — 4.1% error rate is within acceptable limits.', correct: false }, { text: 'Expand the canary to 25% and observe for another 48 hours.', correct: false }, { text: 'Pause the rollout, revert the feature flag to 0%, and investigate the root cause before proceeding.', correct: true }, { text: 'Notify affected users and continue the rollout as planned.', correct: false } ], explanation: 'A 13× increase in error rate (0.3% → 4.1%) is a clear rollback signal. The canary strategy exists precisely to catch this pattern before it affects all users. Reverting the flag immediately protects 95% of users while engineering investigates without the pressure of an active production incident.',
  packageId: 'PKG-DELIVERY' },
  // ── PKG-LEADERSHIP ───────────────────────────────────────────────────────
  { id: 'cq-38', domain: 'Leadership', question: 'A Technical PM has no direct management authority over the engineering team. A senior engineer consistently dismisses timeline estimates in team meetings. What is the MOST effective long-term response?', options: [ { text: 'Escalate to the engineering manager to address the behavior.', correct: false }, { text: 'Ignore the comments and proceed with the original estimates.', correct: false }, { text: 'Involve the engineer in building the estimates so their expertise shapes the timeline and they share ownership of it.', correct: true }, { text: 'Ask the engineer to provide their own alternative timeline.', correct: false } ], explanation: 'Influence without authority is the defining challenge of the TPM role. When a senior engineer dismisses estimates, the most effective response is to bring them into the process: use their expertise to build the estimate, making them a co-owner of the timeline they help create. People defend estimates they built — not estimates handed to them.',
  packageId: 'PKG-LEADERSHIP' },
  { id: 'cq-39', domain: 'Decision Making', question: 'In the DACI framework, who is responsible for owning the decision-making process, gathering input from contributors, and driving the decision to resolution?', options: [ { text: 'The Approver — they have final authority.', correct: false }, { text: 'The Driver — they own the process and drive to resolution.', correct: true }, { text: 'The Contributors — they have the most relevant expertise.', correct: false }, { text: 'The Informed — they receive the final decision.', correct: false } ], explanation: 'In DACI (Driver, Approver, Contributor, Informed), the Driver owns the process: they gather input from contributors, facilitate the discussion, and drive to a conclusion. The Approver has final authority on the decision itself. A Technical PM is typically the Driver for project-related decisions.',
  packageId: 'PKG-LEADERSHIP' },
  // ── PKG-TECHNICAL ────────────────────────────────────────────────────────
  { id: 'cq-40', domain: 'API Literacy', question: 'A developer reports that an external payment API is returning HTTP 429 errors. What does this indicate and what is the appropriate response?', options: [ { text: '429 means the API server is down. Pause all payment processing.', correct: false }, { text: '429 means Too Many Requests — implement request throttling or batching to stay within the rate limit.', correct: true }, { text: '429 means the API key has expired. Request a new key from the provider.', correct: false }, { text: '429 means the request payload is malformed. Review the API documentation.', correct: false } ], explanation: 'HTTP 429 (Too Many Requests) indicates the application is exceeding the API provider\'s rate limit. The response is to implement throttling (limit requests per unit time), exponential backoff (wait progressively longer before retrying), or request batching. Rate limits must be understood before integration work begins.',
  packageId: 'PKG-TECHNICAL' },
  { id: 'cq-41', domain: 'Technical Communication', question: 'A TPM needs to communicate a critical API dependency risk to both the engineering team and a non-technical Chief Commercial Officer. What is the BEST approach?', options: [ { text: 'Send the same detailed technical report to both audiences for consistency.', correct: false }, { text: 'Tailor the communication: technical details for the engineering team; business impact, timeline risk, and recommended action for the CCO.', correct: true }, { text: 'Let the engineering team communicate directly with the CCO for technical accuracy.', correct: false }, { text: 'Send a brief email to both stating the risk will be addressed.', correct: false } ], explanation: 'Effective technical communication adapts to the audience. The engineering team needs technical context to implement mitigations. The CCO needs to understand business impact — which features are at risk, what the timeline implication is, and what decision is needed from them. Same risk, two different communication needs.',
  packageId: 'PKG-TECHNICAL' },
  // ── PKG-DEVOPS ───────────────────────────────────────────────────────────
  { id: 'cq-42', domain: 'DevOps Fundamentals', question: 'Which of the four DORA metrics measures the ability of a team to recover from a production failure?', options: [ { text: 'Deployment Frequency — how often the team deploys to production.', correct: false }, { text: 'Lead Time for Changes — time from code commit to production.', correct: false }, { text: 'Mean Time to Restore (MTTR) — average time to recover from a production incident.', correct: true }, { text: 'Change Failure Rate — percentage of deployments causing incidents.', correct: false } ], explanation: 'MTTR (Mean Time to Restore) measures how quickly a team recovers from production failures. It reflects the quality of monitoring, incident response processes, and rollback capabilities. High-performing teams achieve MTTR under 1 hour. The four DORA metrics (Deployment Frequency, Lead Time, MTTR, Change Failure Rate) define DevOps delivery performance.',
  packageId: 'PKG-DEVOPS' },
  { id: 'cq-43', domain: 'Incident Management', question: 'During a production incident, the TPM\'s PRIMARY role is to:', options: [ { text: 'Diagnose the root cause alongside the engineering team.', correct: false }, { text: 'Coordinate communication with internal stakeholders and maintain the incident log while engineering resolves the issue.', correct: true }, { text: 'Make the technical decision about whether to roll back the release.', correct: false }, { text: 'Contact affected customers directly to manage their expectations.', correct: false } ], explanation: 'During a production incident, engineers diagnose and fix. The TPM coordinates: managing communication to internal stakeholders (leadership, Customer Success), maintaining a running incident log for the postmortem, and removing obstacles for the engineering team. The TPM does not diagnose, does not make technical recovery decisions, and does not contact customers directly.',
  packageId: 'PKG-DEVOPS' },
  // ── PKG-TECHDEBT ─────────────────────────────────────────────────────────
  { id: 'cq-44', domain: 'Technical Debt', question: 'The engineering team reports that a core service is responsible for 45% of all production incidents last quarter. The Product Owner wants to focus exclusively on new features. What should the TPM recommend?', options: [ { text: 'Support the Product Owner — new features generate revenue; technical debt does not.', correct: false }, { text: 'Quantify the debt\'s business cost (engineering hours on incidents) and compare it to the refactoring cost, then present the tradeoff to the Product Owner.', correct: true }, { text: 'Override the Product Owner and schedule the refactoring unilaterally.', correct: false }, { text: 'Accept the situation — all legacy services have high incident rates.', correct: false } ], explanation: 'Technical debt is a business risk that must be communicated in business terms. Translating "this service has a lot of debt" into "this service cost 47 engineering hours in incident response last quarter — equivalent to a full sprint" gives the Product Owner the data to make an informed tradeoff decision. The TPM facilitates; the PO decides.',
  packageId: 'PKG-TECHDEBT' },
  { id: 'cq-45', domain: 'Technical Debt', question: 'A team implements a "20% of sprint capacity for technical debt" rule. The Product Owner says this reduces feature output. What is the STRONGEST business argument for maintaining the rule?', options: [ { text: 'Engineers are happier when they can work on clean code.', correct: false }, { text: 'The 20% allocation replaces reactive incident response time the team already spends — it is a reallocation, not an additional cost.', correct: true }, { text: 'Technical debt will eventually cause the product to stop working.', correct: false }, { text: 'Industry best practices recommend 20% for technical debt.', correct: false } ], explanation: 'Teams already spend similar capacity reactively on incident response, workarounds, and debugging caused by debt. Structured debt allocation replaces unpredictable reactive spending with planned, productive improvement work. It is a reallocation of existing cost, not new spending — and it makes the team more predictable over time.',
  packageId: 'PKG-TECHDEBT' },
  // ── PKG-AI ───────────────────────────────────────────────────────────────
  { id: 'cq-46', domain: 'AI Literacy', question: 'A product team wants to use an LLM to automatically send legally binding contract amendments to customers without human review. What is the PRIMARY risk that should block this design?', options: [ { text: 'LLMs are too slow for real-time contract generation.', correct: false }, { text: 'LLMs can hallucinate — generating plausible but factually incorrect legal content — creating legal and regulatory liability without human review.', correct: true }, { text: 'LLMs cannot generate text in formal legal language.', correct: false }, { text: 'The LLM API costs would be too high at scale.', correct: false } ], explanation: 'LLM hallucination — generating confident but incorrect content — is the primary risk for high-stakes automated AI outputs. Legal documents sent without human review could contain incorrect terms, dates, or obligations that create legal liability. The correct design is human-in-the-loop: AI drafts, human reviews and approves, then the document is sent.',
  packageId: 'PKG-AI' },
  { id: 'cq-47', domain: 'AI Project Management', question: 'Six months after an AI recommendation model launches, its click-through rate drops from 19% to 11% with no code changes. What is the MOST LIKELY cause?', options: [ { text: 'The model has a bug introduced by the latest infrastructure update.', correct: false }, { text: 'Model drift — real-world data distribution has shifted away from the training data, degrading performance over time.', correct: true }, { text: 'Users have become bored with the recommendations.', correct: false }, { text: 'The evaluation dataset was too small and the model was never accurate.', correct: false } ], explanation: 'Model drift occurs when the real-world data distribution evolves differently from the training data. User behavior, content inventory, and market conditions change over time. Without retraining, the model\'s predictions become less accurate. The absence of code changes rules out a software bug. Monitoring for drift and establishing a retraining cadence is a core AI PM responsibility.',
  packageId: 'PKG-AI' },
];
